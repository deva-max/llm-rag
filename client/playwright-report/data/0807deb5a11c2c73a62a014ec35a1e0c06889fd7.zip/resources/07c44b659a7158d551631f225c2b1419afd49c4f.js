import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/Navigation.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/Navigation.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { MessageSquare, Globe, Search, Brain, Settings, Database, Sparkles, CheckCircle2, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
export const Navigation = ({
  activeTab,
  onSelectTab,
  configStatus
}) => {
  const tabs = [
    { id: "chat", label: "RAG & Memory Chat", icon: MessageSquare },
    { id: "ingest", label: "Firecrawl Web Crawler", icon: Globe },
    { id: "tavily", label: "Tavily AI Search", icon: Search },
    { id: "memories", label: "Memory Explorer", icon: Brain },
    { id: "kafka", label: "Kafka Event Stream", icon: Database },
    { id: "settings", label: "Settings & Supabase SQL", icon: Settings }
  ];
  const totalServicesConfigured = configStatus ? [configStatus.supabaseConfigured, configStatus.openaiConfigured, configStatus.firecrawlConfigured, configStatus.tavilyConfigured].filter(Boolean).length : 0;
  return /* @__PURE__ */ jsxDEV("header", { className: "glass-card", style: { borderRadius: 0, borderTop: 0, borderLeft: 0, borderRight: 0, marginBottom: "24px" }, children: /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1400px", margin: "0 auto", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "12px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: {
        width: "42px",
        height: "42px",
        borderRadius: "12px",
        background: "var(--primary-gradient)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: "var(--shadow-glow)"
      }, children: /* @__PURE__ */ jsxDEV(Sparkles, { size: 24, color: "#fff" }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/Navigation.tsx",
        lineNumber: 64,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/Navigation.tsx",
        lineNumber: 54,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { style: { fontSize: "20px", fontWeight: "700", margin: 0, display: "flex", alignItems: "center", gap: "8px" }, children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gradient", children: "Memory & Context RAG" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/Navigation.tsx",
            lineNumber: 68,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "badge badge-indigo", children: "FreeAcademy Module" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/Navigation.tsx",
            lineNumber: 69,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/Navigation.tsx",
          lineNumber: 67,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "12px", color: "var(--text-muted)", margin: 0 }, children: "React + Express (TS) • Supabase pgvector • Firecrawl • Tavily • Zod" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/Navigation.tsx",
          lineNumber: 71,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/Navigation.tsx",
        lineNumber: 66,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/Navigation.tsx",
      lineNumber: 53,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { style: { display: "flex", gap: "8px", background: "rgba(13, 21, 39, 0.7)", padding: "6px", borderRadius: "12px", border: "1px solid var(--border-color)" }, children: tabs.map((tab) => {
      const Icon = tab.icon;
      const isActive = activeTab === tab.id;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          id: `tab-${tab.id}`,
          onClick: () => onSelectTab(tab.id),
          style: {
            background: isActive ? "var(--primary-gradient)" : "transparent",
            color: isActive ? "#ffffff" : "var(--text-muted)",
            border: "none",
            borderRadius: "8px",
            padding: "8px 16px",
            fontSize: "13px",
            fontWeight: "600",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "8px",
            transition: "all 0.2s ease",
            boxShadow: isActive ? "0 4px 12px rgba(99, 102, 241, 0.3)" : "none"
          },
          children: [
            /* @__PURE__ */ jsxDEV(Icon, { size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/Navigation.tsx",
              lineNumber: 103,
              columnNumber: 17
            }, this),
            tab.label
          ]
        },
        tab.id,
        true,
        {
          fileName: "C:/node/llm/client/src/views/Navigation.tsx",
          lineNumber: 83,
          columnNumber: 15
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/node/llm/client/src/views/Navigation.tsx",
      lineNumber: 78,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "10px" }, children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        onClick: () => onSelectTab("settings"),
        style: {
          display: "flex",
          alignItems: "center",
          gap: "6px",
          fontSize: "12px",
          padding: "6px 12px",
          borderRadius: "20px",
          background: totalServicesConfigured === 4 ? "rgba(16, 185, 129, 0.15)" : "rgba(245, 158, 11, 0.15)",
          border: totalServicesConfigured === 4 ? "1px solid rgba(16, 185, 129, 0.3)" : "1px solid rgba(245, 158, 11, 0.3)",
          color: totalServicesConfigured === 4 ? "#6ee7b7" : "#fcd34d",
          cursor: "pointer"
        },
        title: "Click to manage API Credentials",
        children: [
          totalServicesConfigured === 4 ? /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 14 }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/Navigation.tsx",
            lineNumber: 128,
            columnNumber: 46
          }, this) : /* @__PURE__ */ jsxDEV(AlertCircle, { size: 14 }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/Navigation.tsx",
            lineNumber: 128,
            columnNumber: 75
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            totalServicesConfigured,
            "/4 API Keys Active"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/Navigation.tsx",
            lineNumber: 129,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/node/llm/client/src/views/Navigation.tsx",
        lineNumber: 112,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "C:/node/llm/client/src/views/Navigation.tsx",
      lineNumber: 111,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/Navigation.tsx",
    lineNumber: 50,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/node/llm/client/src/views/Navigation.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
};
_c = Navigation;
var _c;
$RefreshReg$(_c, "Navigation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/Navigation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/Navigation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENZOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUNaLFNBQVNBLGVBQWVDLE9BQU9DLFFBQVFDLE9BQU9DLFVBQVVDLFVBQVVDLFVBQVVDLGNBQWNDLG1CQUFtQjtBQVF0RyxhQUFNQyxhQUF3Q0EsQ0FBQztBQUFBLEVBQ3BEQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFDSixRQUFNQyxPQUFPO0FBQUEsSUFDWCxFQUFFQyxJQUFJLFFBQW1CQyxPQUFPLHFCQUFxQkMsTUFBTWhCLGNBQWM7QUFBQSxJQUN6RSxFQUFFYyxJQUFJLFVBQXFCQyxPQUFPLHlCQUF5QkMsTUFBTWYsTUFBTTtBQUFBLElBQ3ZFLEVBQUVhLElBQUksVUFBcUJDLE9BQU8sb0JBQW9CQyxNQUFNZCxPQUFPO0FBQUEsSUFDbkUsRUFBRVksSUFBSSxZQUF1QkMsT0FBTyxtQkFBbUJDLE1BQU1iLE1BQU07QUFBQSxJQUNuRSxFQUFFVyxJQUFJLFNBQW9CQyxPQUFPLHNCQUFzQkMsTUFBTVgsU0FBUztBQUFBLElBQ3RFLEVBQUVTLElBQUksWUFBdUJDLE9BQU8sMkJBQTJCQyxNQUFNWixTQUFTO0FBQUEsRUFBQztBQUdqRixRQUFNYSwwQkFBMEJMLGVBQzVCLENBQUNBLGFBQWFNLG9CQUFvQk4sYUFBYU8sa0JBQWtCUCxhQUFhUSxxQkFBcUJSLGFBQWFTLGdCQUFnQixFQUFFQyxPQUFPQyxPQUFPLEVBQUVDLFNBQ2xKO0FBRUosU0FDRSx1QkFBQyxZQUFPLFdBQVUsY0FBYSxPQUFPLEVBQUVDLGNBQWMsR0FBR0MsV0FBVyxHQUFHQyxZQUFZLEdBQUdDLGFBQWEsR0FBR0MsY0FBYyxPQUFPLEdBQ3pILGlDQUFDLFNBQUksT0FBTyxFQUFFQyxVQUFVLFVBQVVDLFFBQVEsVUFBVUMsU0FBUyxhQUFhQyxTQUFTLFFBQVFDLFlBQVksVUFBVUMsZ0JBQWdCLGlCQUFpQkMsVUFBVSxRQUFRQyxLQUFLLE9BQU8sR0FHOUs7QUFBQSwyQkFBQyxTQUFJLE9BQU8sRUFBRUosU0FBUyxRQUFRQyxZQUFZLFVBQVVHLEtBQUssT0FBTyxHQUMvRDtBQUFBLDZCQUFDLFNBQUksT0FBTztBQUFBLFFBQ1ZDLE9BQU87QUFBQSxRQUNQQyxRQUFRO0FBQUEsUUFDUmQsY0FBYztBQUFBLFFBQ2RlLFlBQVk7QUFBQSxRQUNaUCxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLGdCQUFnQjtBQUFBLFFBQ2hCTSxXQUFXO0FBQUEsTUFDYixHQUNFLGlDQUFDLFlBQVMsTUFBTSxJQUFJLE9BQU0sVUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQyxLQVZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLE9BQU8sRUFBRUMsVUFBVSxRQUFRQyxZQUFZLE9BQU9aLFFBQVEsR0FBR0UsU0FBUyxRQUFRQyxZQUFZLFVBQVVHLEtBQUssTUFBTSxHQUM3RztBQUFBLGlDQUFDLFVBQUssV0FBVSxpQkFBZ0Isb0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsVUFBSyxXQUFVLHNCQUFxQixrQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxhQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsT0FBTyxFQUFFSyxVQUFVLFFBQVFFLE9BQU8scUJBQXFCYixRQUFRLEVBQUUsR0FBRSxtRkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUUsU0FBUyxRQUFRSSxLQUFLLE9BQU9HLFlBQVkseUJBQXlCUixTQUFTLE9BQU9QLGNBQWMsUUFBUW9CLFFBQVEsZ0NBQWdDLEdBQzNKaEMsZUFBS2lDLElBQUksQ0FBQ0MsUUFBUTtBQUNqQixZQUFNQyxPQUFPRCxJQUFJL0I7QUFDakIsWUFBTWlDLFdBQVd2QyxjQUFjcUMsSUFBSWpDO0FBQ25DLGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLElBQUksT0FBT2lDLElBQUlqQyxFQUFFO0FBQUEsVUFDakIsU0FBUyxNQUFNSCxZQUFZb0MsSUFBSWpDLEVBQUU7QUFBQSxVQUNqQyxPQUFPO0FBQUEsWUFDTDBCLFlBQVlTLFdBQVcsNEJBQTRCO0FBQUEsWUFDbkRMLE9BQU9LLFdBQVcsWUFBWTtBQUFBLFlBQzlCSixRQUFRO0FBQUEsWUFDUnBCLGNBQWM7QUFBQSxZQUNkTyxTQUFTO0FBQUEsWUFDVFUsVUFBVTtBQUFBLFlBQ1ZDLFlBQVk7QUFBQSxZQUNaTyxRQUFRO0FBQUEsWUFDUmpCLFNBQVM7QUFBQSxZQUNUQyxZQUFZO0FBQUEsWUFDWkcsS0FBSztBQUFBLFlBQ0xjLFlBQVk7QUFBQSxZQUNaVixXQUFXUSxXQUFXLHVDQUF1QztBQUFBLFVBQy9EO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUNkRixJQUFJaEM7QUFBQUE7QUFBQUE7QUFBQUEsUUFwQkFnQyxJQUFJakM7QUFBQUEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bc0JBO0FBQUEsSUFFSixDQUFDLEtBN0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFbUIsU0FBUyxRQUFRQyxZQUFZLFVBQVVHLEtBQUssT0FBTyxHQUMvRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUyxNQUFNMUIsWUFBWSxVQUFVO0FBQUEsUUFDckMsT0FBTztBQUFBLFVBQ0xzQixTQUFTO0FBQUEsVUFDVEMsWUFBWTtBQUFBLFVBQ1pHLEtBQUs7QUFBQSxVQUNMSyxVQUFVO0FBQUEsVUFDVlYsU0FBUztBQUFBLFVBQ1RQLGNBQWM7QUFBQSxVQUNkZSxZQUFZdkIsNEJBQTRCLElBQUksNkJBQTZCO0FBQUEsVUFDekU0QixRQUFRNUIsNEJBQTRCLElBQUksc0NBQXNDO0FBQUEsVUFDOUUyQixPQUFPM0IsNEJBQTRCLElBQUksWUFBWTtBQUFBLFVBQ25EaUMsUUFBUTtBQUFBLFFBQ1Y7QUFBQSxRQUNBLE9BQU07QUFBQSxRQUVMakM7QUFBQUEsc0NBQTRCLElBQUksdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QixJQUFNLHVCQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBLFVBQ3BGLHVCQUFDLFVBQU1BO0FBQUFBO0FBQUFBLFlBQXdCO0FBQUEsZUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQTtBQUFBO0FBQUEsTUFqQm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsT0FqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1GQSxLQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUZBO0FBRUo7QUFBQ21DLEtBMUdZM0M7QUFBcUMsSUFBQTJDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIk1lc3NhZ2VTcXVhcmUiLCJHbG9iZSIsIlNlYXJjaCIsIkJyYWluIiwiU2V0dGluZ3MiLCJEYXRhYmFzZSIsIlNwYXJrbGVzIiwiQ2hlY2tDaXJjbGUyIiwiQWxlcnRDaXJjbGUiLCJOYXZpZ2F0aW9uIiwiYWN0aXZlVGFiIiwib25TZWxlY3RUYWIiLCJjb25maWdTdGF0dXMiLCJ0YWJzIiwiaWQiLCJsYWJlbCIsImljb24iLCJ0b3RhbFNlcnZpY2VzQ29uZmlndXJlZCIsInN1cGFiYXNlQ29uZmlndXJlZCIsIm9wZW5haUNvbmZpZ3VyZWQiLCJmaXJlY3Jhd2xDb25maWd1cmVkIiwidGF2aWx5Q29uZmlndXJlZCIsImZpbHRlciIsIkJvb2xlYW4iLCJsZW5ndGgiLCJib3JkZXJSYWRpdXMiLCJib3JkZXJUb3AiLCJib3JkZXJMZWZ0IiwiYm9yZGVyUmlnaHQiLCJtYXJnaW5Cb3R0b20iLCJtYXhXaWR0aCIsIm1hcmdpbiIsInBhZGRpbmciLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZmxleFdyYXAiLCJnYXAiLCJ3aWR0aCIsImhlaWdodCIsImJhY2tncm91bmQiLCJib3hTaGFkb3ciLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvciIsImJvcmRlciIsIm1hcCIsInRhYiIsIkljb24iLCJpc0FjdGl2ZSIsImN1cnNvciIsInRyYW5zaXRpb24iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOYXZpZ2F0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBUYWJUeXBlLCBDb25maWdTdGF0dXMgfSBmcm9tICdAL3R5cGVzJ1xuaW1wb3J0IHsgTWVzc2FnZVNxdWFyZSwgR2xvYmUsIFNlYXJjaCwgQnJhaW4sIFNldHRpbmdzLCBEYXRhYmFzZSwgU3BhcmtsZXMsIENoZWNrQ2lyY2xlMiwgQWxlcnRDaXJjbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmludGVyZmFjZSBOYXZpZ2F0aW9uUHJvcHMge1xuICBhY3RpdmVUYWI6IFRhYlR5cGVcbiAgb25TZWxlY3RUYWI6ICh0YWI6IFRhYlR5cGUpID0+IHZvaWRcbiAgY29uZmlnU3RhdHVzOiBDb25maWdTdGF0dXMgfCBudWxsXG59XG5cbmV4cG9ydCBjb25zdCBOYXZpZ2F0aW9uOiBSZWFjdC5GQzxOYXZpZ2F0aW9uUHJvcHM+ID0gKHtcbiAgYWN0aXZlVGFiLFxuICBvblNlbGVjdFRhYixcbiAgY29uZmlnU3RhdHVzXG59KSA9PiB7XG4gIGNvbnN0IHRhYnMgPSBbXG4gICAgeyBpZDogJ2NoYXQnIGFzIFRhYlR5cGUsIGxhYmVsOiAnUkFHICYgTWVtb3J5IENoYXQnLCBpY29uOiBNZXNzYWdlU3F1YXJlIH0sXG4gICAgeyBpZDogJ2luZ2VzdCcgYXMgVGFiVHlwZSwgbGFiZWw6ICdGaXJlY3Jhd2wgV2ViIENyYXdsZXInLCBpY29uOiBHbG9iZSB9LFxuICAgIHsgaWQ6ICd0YXZpbHknIGFzIFRhYlR5cGUsIGxhYmVsOiAnVGF2aWx5IEFJIFNlYXJjaCcsIGljb246IFNlYXJjaCB9LFxuICAgIHsgaWQ6ICdtZW1vcmllcycgYXMgVGFiVHlwZSwgbGFiZWw6ICdNZW1vcnkgRXhwbG9yZXInLCBpY29uOiBCcmFpbiB9LFxuICAgIHsgaWQ6ICdrYWZrYScgYXMgVGFiVHlwZSwgbGFiZWw6ICdLYWZrYSBFdmVudCBTdHJlYW0nLCBpY29uOiBEYXRhYmFzZSB9LFxuICAgIHsgaWQ6ICdzZXR0aW5ncycgYXMgVGFiVHlwZSwgbGFiZWw6ICdTZXR0aW5ncyAmIFN1cGFiYXNlIFNRTCcsIGljb246IFNldHRpbmdzIH1cbiAgXVxuXG4gIGNvbnN0IHRvdGFsU2VydmljZXNDb25maWd1cmVkID0gY29uZmlnU3RhdHVzXG4gICAgPyBbY29uZmlnU3RhdHVzLnN1cGFiYXNlQ29uZmlndXJlZCwgY29uZmlnU3RhdHVzLm9wZW5haUNvbmZpZ3VyZWQsIGNvbmZpZ1N0YXR1cy5maXJlY3Jhd2xDb25maWd1cmVkLCBjb25maWdTdGF0dXMudGF2aWx5Q29uZmlndXJlZF0uZmlsdGVyKEJvb2xlYW4pLmxlbmd0aFxuICAgIDogMFxuXG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJnbGFzcy1jYXJkXCIgc3R5bGU9e3sgYm9yZGVyUmFkaXVzOiAwLCBib3JkZXJUb3A6IDAsIGJvcmRlckxlZnQ6IDAsIGJvcmRlclJpZ2h0OiAwLCBtYXJnaW5Cb3R0b206ICcyNHB4JyB9fT5cbiAgICAgIDxkaXYgc3R5bGU9e3sgbWF4V2lkdGg6ICcxNDAwcHgnLCBtYXJnaW46ICcwIGF1dG8nLCBwYWRkaW5nOiAnMTZweCAyNHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgZmxleFdyYXA6ICd3cmFwJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgIFxuICAgICAgICB7LyogQnJhbmQgSGVhZGVyICovfVxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzEycHgnIH19PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3tcbiAgICAgICAgICAgIHdpZHRoOiAnNDJweCcsXG4gICAgICAgICAgICBoZWlnaHQ6ICc0MnB4JyxcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzEycHgnLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogJ3ZhcigtLXByaW1hcnktZ3JhZGllbnQpJyxcbiAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLFxuICAgICAgICAgICAgYm94U2hhZG93OiAndmFyKC0tc2hhZG93LWdsb3cpJ1xuICAgICAgICAgIH19PlxuICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezI0fSBjb2xvcj1cIiNmZmZcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDEgc3R5bGU9e3sgZm9udFNpemU6ICcyMHB4JywgZm9udFdlaWdodDogJzcwMCcsIG1hcmdpbjogMCwgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmFkaWVudFwiPk1lbW9yeSAmIENvbnRleHQgUkFHPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiYWRnZS1pbmRpZ29cIj5GcmVlQWNhZGVteSBNb2R1bGU8L3NwYW4+XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxMnB4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScsIG1hcmdpbjogMCB9fT5cbiAgICAgICAgICAgICAgUmVhY3QgKyBFeHByZXNzIChUUykg4oCiIFN1cGFiYXNlIHBndmVjdG9yIOKAoiBGaXJlY3Jhd2wg4oCiIFRhdmlseSDigKIgWm9kXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUYWIgU2VsZWN0aW9uICovfVxuICAgICAgICA8bmF2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnOHB4JywgYmFja2dyb3VuZDogJ3JnYmEoMTMsIDIxLCAzOSwgMC43KScsIHBhZGRpbmc6ICc2cHgnLCBib3JkZXJSYWRpdXM6ICcxMnB4JywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWJvcmRlci1jb2xvciknIH19PlxuICAgICAgICAgIHt0YWJzLm1hcCgodGFiKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBJY29uID0gdGFiLmljb25cbiAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlVGFiID09PSB0YWIuaWRcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgICBpZD17YHRhYi0ke3RhYi5pZH1gfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0VGFiKHRhYi5pZCl9XG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGlzQWN0aXZlID8gJ3ZhcigtLXByaW1hcnktZ3JhZGllbnQpJyA6ICd0cmFuc3BhcmVudCcsXG4gICAgICAgICAgICAgICAgICBjb2xvcjogaXNBY3RpdmUgPyAnI2ZmZmZmZicgOiAndmFyKC0tdGV4dC1tdXRlZCknLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxuICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzhweCAxNnB4JyxcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTNweCcsXG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiAnNjAwJyxcbiAgICAgICAgICAgICAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgICAgICBnYXA6ICc4cHgnLFxuICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogJ2FsbCAwLjJzIGVhc2UnLFxuICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBpc0FjdGl2ZSA/ICcwIDRweCAxMnB4IHJnYmEoOTksIDEwMiwgMjQxLCAwLjMpJyA6ICdub25lJ1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8SWNvbiBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICB7dGFiLmxhYmVsfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIClcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9uYXY+XG5cbiAgICAgICAgey8qIEludGVncmF0aW9uIFN0YXR1cyBCYWRnZSAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcxMHB4JyB9fT5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdFRhYignc2V0dGluZ3MnKX1cbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgIGdhcDogJzZweCcsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAnMTJweCcsXG4gICAgICAgICAgICAgIHBhZGRpbmc6ICc2cHggMTJweCcsXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzIwcHgnLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB0b3RhbFNlcnZpY2VzQ29uZmlndXJlZCA9PT0gNCA/ICdyZ2JhKDE2LCAxODUsIDEyOSwgMC4xNSknIDogJ3JnYmEoMjQ1LCAxNTgsIDExLCAwLjE1KScsXG4gICAgICAgICAgICAgIGJvcmRlcjogdG90YWxTZXJ2aWNlc0NvbmZpZ3VyZWQgPT09IDQgPyAnMXB4IHNvbGlkIHJnYmEoMTYsIDE4NSwgMTI5LCAwLjMpJyA6ICcxcHggc29saWQgcmdiYSgyNDUsIDE1OCwgMTEsIDAuMyknLFxuICAgICAgICAgICAgICBjb2xvcjogdG90YWxTZXJ2aWNlc0NvbmZpZ3VyZWQgPT09IDQgPyAnIzZlZTdiNycgOiAnI2ZjZDM0ZCcsXG4gICAgICAgICAgICAgIGN1cnNvcjogJ3BvaW50ZXInXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgdGl0bGU9XCJDbGljayB0byBtYW5hZ2UgQVBJIENyZWRlbnRpYWxzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7dG90YWxTZXJ2aWNlc0NvbmZpZ3VyZWQgPT09IDQgPyA8Q2hlY2tDaXJjbGUyIHNpemU9ezE0fSAvPiA6IDxBbGVydENpcmNsZSBzaXplPXsxNH0gLz59XG4gICAgICAgICAgICA8c3Bhbj57dG90YWxTZXJ2aWNlc0NvbmZpZ3VyZWR9LzQgQVBJIEtleXMgQWN0aXZlPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gIClcbn1cbiJdLCJmaWxlIjoiQzovbm9kZS9sbG0vY2xpZW50L3NyYy92aWV3cy9OYXZpZ2F0aW9uLnRzeCJ9