import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { createBrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=90a7bf15";
import App from "/src/App.tsx";
import { ChatTab } from "/src/views/ChatTab.tsx?t=1787502751007";
import { IngestTab } from "/src/views/IngestTab.tsx";
import { TavilyTab } from "/src/views/TavilyTab.tsx";
import { MemoriesTab } from "/src/views/MemoriesTab.tsx";
import { KafkaTab } from "/src/views/KafkaTab.tsx";
import { SettingsTab } from "/src/views/SettingsTab.tsx";
export const appRouter = createBrowserRouter(
  [
    {
      path: "/",
      element: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
        fileName: "C:/node/llm/client/src/router/app.router.tsx",
        lineNumber: 13,
        columnNumber: 12
      }, this),
      children: [
        { path: "/", element: /* @__PURE__ */ jsxDEV(ChatTab, {}, void 0, false, {
          fileName: "C:/node/llm/client/src/router/app.router.tsx",
          lineNumber: 15,
          columnNumber: 25
        }, this) },
        { path: "ingest", element: /* @__PURE__ */ jsxDEV(IngestTab, {}, void 0, false, {
          fileName: "C:/node/llm/client/src/router/app.router.tsx",
          lineNumber: 16,
          columnNumber: 30
        }, this) },
        { path: "tavily", element: /* @__PURE__ */ jsxDEV(TavilyTab, {}, void 0, false, {
          fileName: "C:/node/llm/client/src/router/app.router.tsx",
          lineNumber: 17,
          columnNumber: 30
        }, this) },
        { path: "memories", element: /* @__PURE__ */ jsxDEV(MemoriesTab, {}, void 0, false, {
          fileName: "C:/node/llm/client/src/router/app.router.tsx",
          lineNumber: 18,
          columnNumber: 32
        }, this) },
        { path: "kafka", element: /* @__PURE__ */ jsxDEV(KafkaTab, {}, void 0, false, {
          fileName: "C:/node/llm/client/src/router/app.router.tsx",
          lineNumber: 19,
          columnNumber: 29
        }, this) },
        { path: "settings", element: /* @__PURE__ */ jsxDEV(SettingsTab, {}, void 0, false, {
          fileName: "C:/node/llm/client/src/router/app.router.tsx",
          lineNumber: 20,
          columnNumber: 32
        }, this) }
      ]
    }
  ]
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWWE7QUFaYixTQUFTQSwyQkFBMkI7QUFDcEMsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFFckIsYUFBTUMsWUFBWVI7QUFBQUEsRUFBb0I7QUFBQSxJQUMzQztBQUFBLE1BQ0VTLE1BQU07QUFBQSxNQUNOQyxTQUFTLHVCQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFDYkMsVUFBVTtBQUFBLFFBQ1IsRUFBRUYsTUFBTSxLQUFLQyxTQUFTLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFRLEVBQUk7QUFBQSxRQUNsQyxFQUFFRCxNQUFNLFVBQVVDLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVUsRUFBSTtBQUFBLFFBQ3pDLEVBQUVELE1BQU0sVUFBVUMsU0FBUyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVSxFQUFJO0FBQUEsUUFDekMsRUFBRUQsTUFBTSxZQUFZQyxTQUFTLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWSxFQUFJO0FBQUEsUUFDN0MsRUFBRUQsTUFBTSxTQUFTQyxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEVBQUk7QUFBQSxRQUN2QyxFQUFFRCxNQUFNLFlBQVlDLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZLEVBQUk7QUFBQSxNQUFDO0FBQUEsSUFFbEQ7QUFBQSxFQUFDO0FBQ0YiLCJuYW1lcyI6WyJjcmVhdGVCcm93c2VyUm91dGVyIiwiQXBwIiwiQ2hhdFRhYiIsIkluZ2VzdFRhYiIsIlRhdmlseVRhYiIsIk1lbW9yaWVzVGFiIiwiS2Fma2FUYWIiLCJTZXR0aW5nc1RhYiIsImFwcFJvdXRlciIsInBhdGgiLCJlbGVtZW50IiwiY2hpbGRyZW4iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXBwLnJvdXRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQnJvd3NlclJvdXRlciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgQXBwIGZyb20gJ0AvQXBwJ1xuaW1wb3J0IHsgQ2hhdFRhYiB9IGZyb20gJ0Avdmlld3MvQ2hhdFRhYidcbmltcG9ydCB7IEluZ2VzdFRhYiB9IGZyb20gJ0Avdmlld3MvSW5nZXN0VGFiJ1xuaW1wb3J0IHsgVGF2aWx5VGFiIH0gZnJvbSAnQC92aWV3cy9UYXZpbHlUYWInXG5pbXBvcnQgeyBNZW1vcmllc1RhYiB9IGZyb20gJ0Avdmlld3MvTWVtb3JpZXNUYWInXG5pbXBvcnQgeyBLYWZrYVRhYiB9IGZyb20gJ0Avdmlld3MvS2Fma2FUYWInXG5pbXBvcnQgeyBTZXR0aW5nc1RhYiB9IGZyb20gJ0Avdmlld3MvU2V0dGluZ3NUYWInXG5cbmV4cG9ydCBjb25zdCBhcHBSb3V0ZXIgPSBjcmVhdGVCcm93c2VyUm91dGVyKFtcbiAge1xuICAgIHBhdGg6ICcvJyxcbiAgICBlbGVtZW50OiA8QXBwIC8+LFxuICAgIGNoaWxkcmVuOiBbXG4gICAgICB7IHBhdGg6ICcvJywgZWxlbWVudDogPENoYXRUYWIgLz4gfSxcbiAgICAgIHsgcGF0aDogJ2luZ2VzdCcsIGVsZW1lbnQ6IDxJbmdlc3RUYWIgLz4gfSxcbiAgICAgIHsgcGF0aDogJ3RhdmlseScsIGVsZW1lbnQ6IDxUYXZpbHlUYWIgLz4gfSxcbiAgICAgIHsgcGF0aDogJ21lbW9yaWVzJywgZWxlbWVudDogPE1lbW9yaWVzVGFiIC8+IH0sXG4gICAgICB7IHBhdGg6ICdrYWZrYScsIGVsZW1lbnQ6IDxLYWZrYVRhYiAvPiB9LFxuICAgICAgeyBwYXRoOiAnc2V0dGluZ3MnLCBlbGVtZW50OiA8U2V0dGluZ3NUYWIgLz4gfVxuICAgIF1cbiAgfVxuXSlcbiJdLCJmaWxlIjoiQzovbm9kZS9sbG0vY2xpZW50L3NyYy9yb3V0ZXIvYXBwLnJvdXRlci50c3gifQ==