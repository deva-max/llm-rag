import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/IngestTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/IngestTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=90a7bf15";
import { ApiOperations } from "/src/operations/api.operation.ts";
import { HttpErrorResponse } from "/src/utils/errors.ts";
import { Globe, FileText, Database, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
export const IngestTab = () => {
  _s();
  const { creds } = useOutletContext();
  const [activeSubTab, setActiveSubTab] = useState("url");
  const [url, setUrl] = useState("https://freeacademy.ai/lessons/memory-and-context-rag");
  const [chunkSize, setChunkSize] = useState(500);
  const [textTitle, setTextTitle] = useState("");
  const [textContent, setTextContent] = useState("");
  const [textSourceUrl, setTextSourceUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState(null);
  const [docStats, setDocStats] = useState(null);
  const loadStats = async () => {
    try {
      const stats = await ApiOperations.fetchDocuments();
      setDocStats(stats);
    } catch (e) {
      console.warn("Failed to load doc stats:", e);
    }
  };
  useEffect(() => {
    loadStats();
  }, []);
  const handleIngestUrl = async (e) => {
    e.preventDefault();
    if (!url.trim() || isLoading) return;
    setIsLoading(true);
    setStatusMessage(null);
    try {
      const res = await ApiOperations.ingestUrl(url, chunkSize);
      setStatusMessage({
        type: "success",
        text: `Successfully scraped page via Firecrawl! Title: "${res.data.title}" • Generated ${res.data.totalChunks} vector chunks.`
      });
      setUrl("");
      loadStats();
    } catch (err) {
      const message = err instanceof HttpErrorResponse ? err.message : "Firecrawl web ingestion failed";
      setStatusMessage({
        type: "error",
        text: message
      });
    } finally {
      setIsLoading(false);
    }
  };
  const handleIngestText = async (e) => {
    e.preventDefault();
    if (!textTitle.trim() || !textContent.trim() || isLoading) return;
    setIsLoading(true);
    setStatusMessage(null);
    try {
      const res = await ApiOperations.ingestText(textTitle, textContent, textSourceUrl || "", chunkSize);
      setStatusMessage({
        type: "success",
        text: `Successfully created document: "${res.data.title}" • Generated ${res.data.totalChunks} vector chunks.`
      });
      setTextTitle("");
      setTextContent("");
      setTextSourceUrl("");
      loadStats();
    } catch (err) {
      const message = err instanceof HttpErrorResponse ? err.message : "Text document ingestion failed";
      setStatusMessage({
        type: "error",
        text: message
      });
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1200px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "24px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "20px", fontWeight: "700", margin: "0 0 6px 0", display: "flex", alignItems: "center", gap: "10px" }, children: [
          /* @__PURE__ */ jsxDEV(Globe, { color: "var(--accent-cyan)" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 118,
            columnNumber: 13
          }, this),
          "Firecrawl Web Ingestion & RAG Vector Loader"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "13px", color: "var(--text-muted)", margin: 0 }, children: "Scrape clean markdown content from any website using **Firecrawl**, split into semantic chunks, generate 1536-dim embeddings, and index into **Supabase pgvector**." }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 121,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(13, 21, 39, 0.8)", border: "1px solid var(--border-color)", borderRadius: "12px", padding: "12px 20px", textAlign: "center" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "22px", fontWeight: "800", color: "#67e8f9" }, children: docStats?.totalDocuments || 0 }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 129,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-muted)" }, children: "Documents" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 130,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 128,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(13, 21, 39, 0.8)", border: "1px solid var(--border-color)", borderRadius: "12px", padding: "12px 20px", textAlign: "center" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "22px", fontWeight: "800", color: "#a5b4fc" }, children: docStats?.totalChunks || 0 }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 133,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-muted)" }, children: "Vector Chunks" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 134,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 132,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 400px", gap: "24px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "12px", marginBottom: "20px", borderBottom: "1px solid var(--border-color)", paddingBottom: "12px" }, children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveSubTab("url"),
              style: {
                background: activeSubTab === "url" ? "rgba(6, 182, 212, 0.2)" : "transparent",
                border: activeSubTab === "url" ? "1px solid rgba(6, 182, 212, 0.4)" : "none",
                color: activeSubTab === "url" ? "#67e8f9" : "var(--text-muted)",
                borderRadius: "8px",
                padding: "8px 16px",
                fontSize: "13px",
                fontWeight: "600",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              },
              children: [
                /* @__PURE__ */ jsxDEV(Globe, { size: 16 }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                  lineNumber: 162,
                  columnNumber: 15
                }, this),
                " Firecrawl URL Scrape"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 146,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveSubTab("text"),
              style: {
                background: activeSubTab === "text" ? "rgba(99, 102, 241, 0.2)" : "transparent",
                border: activeSubTab === "text" ? "1px solid rgba(99, 102, 241, 0.4)" : "none",
                color: activeSubTab === "text" ? "#a5b4fc" : "var(--text-muted)",
                borderRadius: "8px",
                padding: "8px 16px",
                fontSize: "13px",
                fontWeight: "600",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              },
              children: [
                /* @__PURE__ */ jsxDEV(FileText, { size: 16 }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                  lineNumber: 180,
                  columnNumber: 15
                }, this),
                " Raw Document Text"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 164,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 145,
          columnNumber: 11
        }, this),
        statusMessage && /* @__PURE__ */ jsxDEV("div", { style: {
          padding: "12px 16px",
          borderRadius: "8px",
          marginBottom: "20px",
          background: statusMessage.type === "success" ? "rgba(16, 185, 129, 0.15)" : "rgba(239, 68, 68, 0.15)",
          border: statusMessage.type === "success" ? "1px solid rgba(16, 185, 129, 0.3)" : "1px solid rgba(239, 68, 68, 0.3)",
          color: statusMessage.type === "success" ? "#6ee7b7" : "#fca5a5",
          fontSize: "13px"
        }, children: statusMessage.text }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 186,
          columnNumber: 11
        }, this),
        activeSubTab === "url" ? /* @__PURE__ */ jsxDEV("form", { onSubmit: handleIngestUrl, style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "13px", fontWeight: "600", marginBottom: "8px", color: "var(--text-main)" }, children: "Target Web Page URL to Scrape (Firecrawl):" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 202,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "url",
                placeholder: "https://example.com/article",
                value: url,
                onChange: (e) => setUrl(e.target.value),
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                lineNumber: 205,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 201,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "13px", fontWeight: "600", marginBottom: "8px", color: "var(--text-main)" }, children: "Chunk Character Limit (Semantic Window):" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 217,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "number",
                min: 100,
                max: 2e3,
                value: chunkSize,
                onChange: (e) => setChunkSize(Number(e.target.value))
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                lineNumber: 220,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "11px", color: "var(--text-dim)", marginTop: "4px", display: "block" }, children: "Recommended: 500 characters per chunk for high similarity precision." }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 229,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 216,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "submit", disabled: isLoading, style: { marginTop: "8px" }, children: [
            isLoading ? /* @__PURE__ */ jsxDEV(Sparkles, { className: "animate-spin", size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 235,
              columnNumber: 30
            }, this) : /* @__PURE__ */ jsxDEV(Globe, { size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 235,
              columnNumber: 80
            }, this),
            isLoading ? "Crawling & Vectorizing..." : "Scrape & Ingest via Firecrawl"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 234,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 200,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleIngestText, style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "13px", fontWeight: "600", marginBottom: "8px" }, children: "Document Title:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 242,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                placeholder: "e.g. FreeAcademy RAG Module Architecture Notes",
                value: textTitle,
                onChange: (e) => setTextTitle(e.target.value),
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                lineNumber: 245,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 241,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "13px", fontWeight: "600", marginBottom: "8px" }, children: "Source URL (Optional):" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 256,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                placeholder: "https://freeacademy.ai/lessons/memory-and-context-rag",
                value: textSourceUrl,
                onChange: (e) => setTextSourceUrl(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                lineNumber: 259,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 255,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "13px", fontWeight: "600", marginBottom: "8px" }, children: "Raw Document Content:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 269,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                className: "glass-input",
                style: { width: "100%", minHeight: "160px", resize: "vertical" },
                placeholder: "Paste lesson markdown, article text, or manual facts here...",
                value: textContent,
                onChange: (e) => setTextContent(e.target.value),
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
                lineNumber: 272,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 268,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "submit", disabled: isLoading, children: [
            isLoading ? /* @__PURE__ */ jsxDEV(Sparkles, { className: "animate-spin", size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 283,
              columnNumber: 30
            }, this) : /* @__PURE__ */ jsxDEV(FileText, { size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 283,
              columnNumber: 80
            }, this),
            isLoading ? "Processing Vectors..." : "Vectorize Document"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 282,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 240,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "16px", fontWeight: "700", margin: 0, display: "flex", alignItems: "center", gap: "8px" }, children: [
          /* @__PURE__ */ jsxDEV(Database, { size: 18, color: "var(--primary)" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 294,
            columnNumber: 13
          }, this),
          "Ingested Documents (",
          docStats?.documents?.length || 0,
          ")"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 293,
          columnNumber: 11
        }, this),
        !docStats?.documents || docStats.documents.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { color: "var(--text-dim)", fontSize: "12px", textAlign: "center", padding: "30px 0" }, children: "No documents ingested yet. Submit a URL above!" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 299,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "10px", maxHeight: "400px", overflowY: "auto" }, children: docStats.documents.map(
          (doc) => /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(13, 21, 39, 0.7)", border: "1px solid var(--border-color)", borderRadius: "10px", padding: "12px" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: "600", fontSize: "13px", color: "var(--text-main)", marginBottom: "4px" }, children: doc.title }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 306,
              columnNumber: 19
            }, this),
            doc.source_url && /* @__PURE__ */ jsxDEV("a", { href: doc.source_url, target: "_blank", rel: "noreferrer", style: { fontSize: "11px", color: "#67e8f9", textDecoration: "none", display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: [
              doc.source_url,
              " ↗"
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 310,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "10px", color: "var(--text-dim)", marginTop: "6px" }, children: [
              "Added: ",
              new Date(doc.created_at).toLocaleDateString()
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
              lineNumber: 314,
              columnNumber: 19
            }, this)
          ] }, doc.id, true, {
            fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
            lineNumber: 305,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
          lineNumber: 303,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
        lineNumber: 292,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
      lineNumber: 139,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/IngestTab.tsx",
    lineNumber: 112,
    columnNumber: 5
  }, this);
};
_s(IngestTab, "AZpyniIVwRTTMpNK+Nc47X5z+Ig=", false, function() {
  return [useOutletContext];
});
_c = IngestTab;
var _c;
$RefreshReg$(_c, "IngestTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/IngestTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/IngestTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0dZOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxHWixTQUFnQkEsVUFBVUMsaUJBQWlCO0FBQzNDLFNBQVNDLHdCQUF3QjtBQUVqQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLE9BQU9DLFVBQVVDLFVBQVVDLGdCQUF3RTtBQUVyRyxhQUFNQyxZQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsTUFBTSxJQUFJVCxpQkFBNEM7QUFDOUQsUUFBTSxDQUFDVSxjQUFjQyxlQUFlLElBQUliLFNBQXlCLEtBQUs7QUFHdEUsUUFBTSxDQUFDYyxLQUFLQyxNQUFNLElBQUlmLFNBQVMsdURBQXVEO0FBQ3RGLFFBQU0sQ0FBQ2dCLFdBQVdDLFlBQVksSUFBSWpCLFNBQVMsR0FBRztBQUc5QyxRQUFNLENBQUNrQixXQUFXQyxZQUFZLElBQUluQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0IsYUFBYUMsY0FBYyxJQUFJckIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3NCLGVBQWVDLGdCQUFnQixJQUFJdkIsU0FBUyxFQUFFO0FBRXJELFFBQU0sQ0FBQ3dCLFdBQVdDLFlBQVksSUFBSXpCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMwQixlQUFlQyxnQkFBZ0IsSUFBSTNCLFNBQTZELElBQUk7QUFDM0csUUFBTSxDQUFDNEIsVUFBVUMsV0FBVyxJQUFJN0IsU0FBK0IsSUFBSTtBQUVuRSxRQUFNOEIsWUFBWSxZQUFZO0FBQzVCLFFBQUk7QUFDRixZQUFNQyxRQUFRLE1BQU01QixjQUFjNkIsZUFBZTtBQUNqREgsa0JBQVlFLEtBQUs7QUFBQSxJQUNuQixTQUFTRSxHQUFHO0FBQ1ZDLGNBQVFDLEtBQUssNkJBQTZCRixDQUFDO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUFoQyxZQUFVLE1BQU07QUFDZDZCLGNBQVU7QUFBQSxFQUNaLEdBQUcsRUFBRTtBQUVMLFFBQU1NLGtCQUFrQixPQUFPSCxNQUF1QjtBQUNwREEsTUFBRUksZUFBZTtBQUNqQixRQUFJLENBQUN2QixJQUFJd0IsS0FBSyxLQUFLZCxVQUFXO0FBRTlCQyxpQkFBYSxJQUFJO0FBQ2pCRSxxQkFBaUIsSUFBSTtBQUVyQixRQUFJO0FBQ0YsWUFBTVksTUFBTSxNQUFNcEMsY0FBY3FDLFVBQVUxQixLQUFLRSxTQUFTO0FBQ3hEVyx1QkFBaUI7QUFBQSxRQUNmYyxNQUFNO0FBQUEsUUFDTkMsTUFBTSxvREFBb0RILElBQUlJLEtBQUtDLEtBQUssaUJBQWlCTCxJQUFJSSxLQUFLRSxXQUFXO0FBQUEsTUFDL0csQ0FBQztBQUNEOUIsYUFBTyxFQUFFO0FBQ1RlLGdCQUFVO0FBQUEsSUFDWixTQUFTZ0IsS0FBSztBQUNaLFlBQU1DLFVBQVVELGVBQWUxQyxvQkFBb0IwQyxJQUFJQyxVQUFVO0FBQ2pFcEIsdUJBQWlCO0FBQUEsUUFDZmMsTUFBTTtBQUFBLFFBQ05DLE1BQU1LO0FBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDdEIsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU11QixtQkFBbUIsT0FBT2YsTUFBdUI7QUFDckRBLE1BQUVJLGVBQWU7QUFDakIsUUFBSSxDQUFDbkIsVUFBVW9CLEtBQUssS0FBSyxDQUFDbEIsWUFBWWtCLEtBQUssS0FBS2QsVUFBVztBQUUzREMsaUJBQWEsSUFBSTtBQUNqQkUscUJBQWlCLElBQUk7QUFFckIsUUFBSTtBQUNGLFlBQU1ZLE1BQU0sTUFBTXBDLGNBQWM4QyxXQUFXL0IsV0FBV0UsYUFBYUUsaUJBQWlCLElBQUlOLFNBQVM7QUFDakdXLHVCQUFpQjtBQUFBLFFBQ2ZjLE1BQU07QUFBQSxRQUNOQyxNQUFNLG1DQUFtQ0gsSUFBSUksS0FBS0MsS0FBSyxpQkFBaUJMLElBQUlJLEtBQUtFLFdBQVc7QUFBQSxNQUM5RixDQUFDO0FBQ0QxQixtQkFBYSxFQUFFO0FBQ2ZFLHFCQUFlLEVBQUU7QUFDakJFLHVCQUFpQixFQUFFO0FBQ25CTyxnQkFBVTtBQUFBLElBQ1osU0FBU2dCLEtBQUs7QUFDWixZQUFNQyxVQUFVRCxlQUFlMUMsb0JBQW9CMEMsSUFBSUMsVUFBVTtBQUNqRXBCLHVCQUFpQjtBQUFBLFFBQ2ZjLE1BQU07QUFBQSxRQUNOQyxNQUFNSztBQUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ3RCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFeUIsVUFBVSxVQUFVQyxRQUFRLFVBQVVDLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FHeEc7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLFNBQVMsUUFBUUgsU0FBUyxRQUFRSSxZQUFZLFVBQVVDLGdCQUFnQixpQkFBaUJDLFVBQVUsUUFBUUosS0FBSyxPQUFPLEdBQzFKO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFSyxVQUFVLFFBQVFDLFlBQVksT0FBT1QsUUFBUSxhQUFhQyxTQUFTLFFBQVFJLFlBQVksVUFBVUYsS0FBSyxPQUFPLEdBQ3hIO0FBQUEsaUNBQUMsU0FBTSxPQUFNLHdCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlDO0FBQUE7QUFBQSxhQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsT0FBTyxFQUFFSyxVQUFVLFFBQVFFLE9BQU8scUJBQXFCVixRQUFRLEVBQUUsR0FBRSxtTEFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxTQUFTLFFBQVFFLEtBQUssT0FBTyxHQUN6QztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFUSxZQUFZLHlCQUF5QkMsUUFBUSxpQ0FBaUNDLGNBQWMsUUFBUVQsU0FBUyxhQUFhVSxXQUFXLFNBQVMsR0FDMUo7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRU4sVUFBVSxRQUFRQyxZQUFZLE9BQU9DLE9BQU8sVUFBVSxHQUFJakMsb0JBQVVzQyxrQkFBa0IsS0FBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxVQUN0Ryx1QkFBQyxTQUFJLE9BQU8sRUFBRVAsVUFBVSxRQUFRRSxPQUFPLG9CQUFvQixHQUFHLHlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLGFBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVDLFlBQVkseUJBQXlCQyxRQUFRLGlDQUFpQ0MsY0FBYyxRQUFRVCxTQUFTLGFBQWFVLFdBQVcsU0FBUyxHQUMxSjtBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFTixVQUFVLFFBQVFDLFlBQVksT0FBT0MsT0FBTyxVQUFVLEdBQUlqQyxvQkFBVWlCLGVBQWUsS0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUc7QUFBQSxVQUNuRyx1QkFBQyxTQUFJLE9BQU8sRUFBRWMsVUFBVSxRQUFRRSxPQUFPLG9CQUFvQixHQUFHLDZCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLGFBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVULFNBQVMsUUFBUWUscUJBQXFCLGFBQWFiLEtBQUssT0FBTyxHQUczRTtBQUFBLDZCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRUMsU0FBUyxPQUFPLEdBR25EO0FBQUEsK0JBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUUsS0FBSyxRQUFRYyxjQUFjLFFBQVFDLGNBQWMsaUNBQWlDQyxlQUFlLE9BQU8sR0FDckk7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNekQsZ0JBQWdCLEtBQUs7QUFBQSxjQUNwQyxPQUFPO0FBQUEsZ0JBQ0xpRCxZQUFZbEQsaUJBQWlCLFFBQVEsMkJBQTJCO0FBQUEsZ0JBQ2hFbUQsUUFBUW5ELGlCQUFpQixRQUFRLHFDQUFxQztBQUFBLGdCQUN0RWlELE9BQU9qRCxpQkFBaUIsUUFBUSxZQUFZO0FBQUEsZ0JBQzVDb0QsY0FBYztBQUFBLGdCQUNkVCxTQUFTO0FBQUEsZ0JBQ1RJLFVBQVU7QUFBQSxnQkFDVkMsWUFBWTtBQUFBLGdCQUNaVyxRQUFRO0FBQUEsZ0JBQ1JuQixTQUFTO0FBQUEsZ0JBQ1RJLFlBQVk7QUFBQSxnQkFDWkYsS0FBSztBQUFBLGNBQ1A7QUFBQSxjQUVBO0FBQUEsdUNBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0I7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQWhCckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNekMsZ0JBQWdCLE1BQU07QUFBQSxjQUNyQyxPQUFPO0FBQUEsZ0JBQ0xpRCxZQUFZbEQsaUJBQWlCLFNBQVMsNEJBQTRCO0FBQUEsZ0JBQ2xFbUQsUUFBUW5ELGlCQUFpQixTQUFTLHNDQUFzQztBQUFBLGdCQUN4RWlELE9BQU9qRCxpQkFBaUIsU0FBUyxZQUFZO0FBQUEsZ0JBQzdDb0QsY0FBYztBQUFBLGdCQUNkVCxTQUFTO0FBQUEsZ0JBQ1RJLFVBQVU7QUFBQSxnQkFDVkMsWUFBWTtBQUFBLGdCQUNaVyxRQUFRO0FBQUEsZ0JBQ1JuQixTQUFTO0FBQUEsZ0JBQ1RJLFlBQVk7QUFBQSxnQkFDWkYsS0FBSztBQUFBLGNBQ1A7QUFBQSxjQUVBO0FBQUEsdUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFoQnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWlCQTtBQUFBLGFBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQ0E7QUFBQSxRQUdDNUIsaUJBQ0MsdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFDVjZCLFNBQVM7QUFBQSxVQUNUUyxjQUFjO0FBQUEsVUFDZEksY0FBYztBQUFBLFVBQ2ROLFlBQVlwQyxjQUFjZSxTQUFTLFlBQVksNkJBQTZCO0FBQUEsVUFDNUVzQixRQUFRckMsY0FBY2UsU0FBUyxZQUFZLHNDQUFzQztBQUFBLFVBQ2pGb0IsT0FBT25DLGNBQWNlLFNBQVMsWUFBWSxZQUFZO0FBQUEsVUFDdERrQixVQUFVO0FBQUEsUUFDWixHQUNHakMsd0JBQWNnQixRQVRqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdEOUIsaUJBQWlCLFFBQ2hCLHVCQUFDLFVBQUssVUFBVXdCLGlCQUFpQixPQUFPLEVBQUVnQixTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxPQUFPLEdBQzlGO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFRixTQUFTLFNBQVNPLFVBQVUsUUFBUUMsWUFBWSxPQUFPUSxjQUFjLE9BQU9QLE9BQU8sbUJBQW1CLEdBQUUsMERBQXhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRVcsT0FBTyxPQUFPO0FBQUEsZ0JBQ3ZCLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBTzFEO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ21CLE1BQU1sQixPQUFPa0IsRUFBRXdDLE9BQU9DLEtBQUs7QUFBQSxnQkFDdEMsVUFBUTtBQUFBO0FBQUEsY0FQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVTtBQUFBLGVBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFdEIsU0FBUyxTQUFTTyxVQUFVLFFBQVFDLFlBQVksT0FBT1EsY0FBYyxPQUFPUCxPQUFPLG1CQUFtQixHQUFFLHdEQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVXLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0wsS0FBSztBQUFBLGdCQUNMLEtBQUs7QUFBQSxnQkFDTCxPQUFPeEQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDaUIsTUFBTWhCLGFBQWEwRCxPQUFPMUMsRUFBRXdDLE9BQU9DLEtBQUssQ0FBQztBQUFBO0FBQUEsY0FQdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT3dEO0FBQUEsWUFFeEQsdUJBQUMsVUFBSyxPQUFPLEVBQUVmLFVBQVUsUUFBUUUsT0FBTyxtQkFBbUJlLFdBQVcsT0FBT3hCLFNBQVMsUUFBUSxHQUFFLG9GQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUEsdUJBQUMsWUFBTyxXQUFVLGVBQWMsTUFBSyxVQUFTLFVBQVU1QixXQUFXLE9BQU8sRUFBRW9ELFdBQVcsTUFBTSxHQUMxRnBEO0FBQUFBLHdCQUFZLHVCQUFDLFlBQVMsV0FBVSxnQkFBZSxNQUFNLE1BQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDLElBQU0sdUJBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0I7QUFBQSxZQUM5RUEsWUFBWSw4QkFBOEI7QUFBQSxlQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNDQSxJQUVBLHVCQUFDLFVBQUssVUFBVXdCLGtCQUFrQixPQUFPLEVBQUVJLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FDL0Y7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxPQUFPLEVBQUVGLFNBQVMsU0FBU08sVUFBVSxRQUFRQyxZQUFZLE9BQU9RLGNBQWMsTUFBTSxHQUFFLCtCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVJLE9BQU8sT0FBTztBQUFBLGdCQUN2QixhQUFZO0FBQUEsZ0JBQ1osT0FBT3REO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2UsTUFBTWQsYUFBYWMsRUFBRXdDLE9BQU9DLEtBQUs7QUFBQSxnQkFDNUMsVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFdEIsU0FBUyxTQUFTTyxVQUFVLFFBQVFDLFlBQVksT0FBT1EsY0FBYyxNQUFNLEdBQUUsc0NBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRUksT0FBTyxPQUFPO0FBQUEsZ0JBQ3ZCLGFBQVk7QUFBQSxnQkFDWixPQUFPbEQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDVyxNQUFNVixpQkFBaUJVLEVBQUV3QyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxjQUxsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLb0Q7QUFBQSxlQVR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxPQUFPLEVBQUV0QixTQUFTLFNBQVNPLFVBQVUsUUFBUUMsWUFBWSxPQUFPUSxjQUFjLE1BQU0sR0FBRSxxQ0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFSSxPQUFPLFFBQVFLLFdBQVcsU0FBU0MsUUFBUSxXQUFXO0FBQUEsZ0JBQy9ELGFBQVk7QUFBQSxnQkFDWixPQUFPMUQ7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDYSxNQUFNWixlQUFlWSxFQUFFd0MsT0FBT0MsS0FBSztBQUFBLGdCQUM5QyxVQUFRO0FBQUE7QUFBQSxjQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1VO0FBQUEsZUFWWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxZQUFPLFdBQVUsZUFBYyxNQUFLLFVBQVMsVUFBVWxELFdBQ3JEQTtBQUFBQSx3QkFBWSx1QkFBQyxZQUFTLFdBQVUsZ0JBQWUsTUFBTSxNQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QyxJQUFNLHVCQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBQ2pGQSxZQUFZLDBCQUEwQjtBQUFBLGVBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOENBO0FBQUEsV0FoSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1KQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFK0IsU0FBUyxRQUFRSCxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxPQUFPLEdBQzFHO0FBQUEsK0JBQUMsUUFBRyxPQUFPLEVBQUVLLFVBQVUsUUFBUUMsWUFBWSxPQUFPVCxRQUFRLEdBQUdDLFNBQVMsUUFBUUksWUFBWSxVQUFVRixLQUFLLE1BQU0sR0FDN0c7QUFBQSxpQ0FBQyxZQUFTLE1BQU0sSUFBSSxPQUFNLG9CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBO0FBQUEsVUFDckIxQixVQUFVbUQsV0FBV0MsVUFBVTtBQUFBLFVBQUU7QUFBQSxhQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVDLENBQUNwRCxVQUFVbUQsYUFBYW5ELFNBQVNtRCxVQUFVQyxXQUFXLElBQ3JELHVCQUFDLFNBQUksT0FBTyxFQUFFbkIsT0FBTyxtQkFBbUJGLFVBQVUsUUFBUU0sV0FBVyxVQUFVVixTQUFTLFNBQVMsR0FBRSw4REFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVILFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLFFBQVEyQixXQUFXLFNBQVNDLFdBQVcsT0FBTyxHQUN4R3RELG1CQUFTbUQsVUFBVUk7QUFBQUEsVUFBSSxDQUFDQyxRQUN2Qix1QkFBQyxTQUFpQixPQUFPLEVBQUV0QixZQUFZLHlCQUF5QkMsUUFBUSxpQ0FBaUNDLGNBQWMsUUFBUVQsU0FBUyxPQUFPLEdBQzdJO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVLLFlBQVksT0FBT0QsVUFBVSxRQUFRRSxPQUFPLG9CQUFvQk8sY0FBYyxNQUFNLEdBQy9GZ0IsY0FBSXhDLFNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0N3QyxJQUFJQyxjQUNILHVCQUFDLE9BQUUsTUFBTUQsSUFBSUMsWUFBWSxRQUFPLFVBQVMsS0FBSSxjQUFhLE9BQU8sRUFBRTFCLFVBQVUsUUFBUUUsT0FBTyxXQUFXeUIsZ0JBQWdCLFFBQVFsQyxTQUFTLFNBQVNtQyxVQUFVLFVBQVVDLGNBQWMsWUFBWUMsWUFBWSxTQUFTLEdBQ2pOTDtBQUFBQSxrQkFBSUM7QUFBQUEsY0FBVztBQUFBLGlCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRix1QkFBQyxTQUFJLE9BQU8sRUFBRTFCLFVBQVUsUUFBUUUsT0FBTyxtQkFBbUJlLFdBQVcsTUFBTSxHQUFFO0FBQUE7QUFBQSxjQUNuRSxJQUFJYyxLQUFLTixJQUFJTyxVQUFVLEVBQUVDLG1CQUFtQjtBQUFBLGlCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFYUVIsSUFBSVMsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsUUFDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsU0F2TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlMQTtBQUFBLE9BcE5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzTkE7QUFFSjtBQUFDbkYsR0E3U1lELFdBQW1CO0FBQUEsVUFDWlAsZ0JBQWdCO0FBQUE7QUFBQSxLQUR2Qk87QUFBbUIsSUFBQXFGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlT3V0bGV0Q29udGV4dCIsIkFwaU9wZXJhdGlvbnMiLCJIdHRwRXJyb3JSZXNwb25zZSIsIkdsb2JlIiwiRmlsZVRleHQiLCJEYXRhYmFzZSIsIlNwYXJrbGVzIiwiSW5nZXN0VGFiIiwiX3MiLCJjcmVkcyIsImFjdGl2ZVN1YlRhYiIsInNldEFjdGl2ZVN1YlRhYiIsInVybCIsInNldFVybCIsImNodW5rU2l6ZSIsInNldENodW5rU2l6ZSIsInRleHRUaXRsZSIsInNldFRleHRUaXRsZSIsInRleHRDb250ZW50Iiwic2V0VGV4dENvbnRlbnQiLCJ0ZXh0U291cmNlVXJsIiwic2V0VGV4dFNvdXJjZVVybCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInN0YXR1c01lc3NhZ2UiLCJzZXRTdGF0dXNNZXNzYWdlIiwiZG9jU3RhdHMiLCJzZXREb2NTdGF0cyIsImxvYWRTdGF0cyIsInN0YXRzIiwiZmV0Y2hEb2N1bWVudHMiLCJlIiwiY29uc29sZSIsIndhcm4iLCJoYW5kbGVJbmdlc3RVcmwiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJyZXMiLCJpbmdlc3RVcmwiLCJ0eXBlIiwidGV4dCIsImRhdGEiLCJ0aXRsZSIsInRvdGFsQ2h1bmtzIiwiZXJyIiwibWVzc2FnZSIsImhhbmRsZUluZ2VzdFRleHQiLCJpbmdlc3RUZXh0IiwibWF4V2lkdGgiLCJtYXJnaW4iLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsInBhZGRpbmciLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJmbGV4V3JhcCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImNvbG9yIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInRleHRBbGlnbiIsInRvdGFsRG9jdW1lbnRzIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsIm1hcmdpbkJvdHRvbSIsImJvcmRlckJvdHRvbSIsInBhZGRpbmdCb3R0b20iLCJjdXJzb3IiLCJ3aWR0aCIsInRhcmdldCIsInZhbHVlIiwiTnVtYmVyIiwibWFyZ2luVG9wIiwibWluSGVpZ2h0IiwicmVzaXplIiwiZG9jdW1lbnRzIiwibGVuZ3RoIiwibWF4SGVpZ2h0Iiwib3ZlcmZsb3dZIiwibWFwIiwiZG9jIiwic291cmNlX3VybCIsInRleHREZWNvcmF0aW9uIiwib3ZlcmZsb3ciLCJ0ZXh0T3ZlcmZsb3ciLCJ3aGl0ZVNwYWNlIiwiRGF0ZSIsImNyZWF0ZWRfYXQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJpZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkluZ2VzdFRhYi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQXBpQ3JlZGVudGlhbHMsIERvY3VtZW50U3RhdHMgfSBmcm9tICdAL3R5cGVzJ1xuaW1wb3J0IHsgQXBpT3BlcmF0aW9ucyB9IGZyb20gJ0Avb3BlcmF0aW9ucy9hcGkub3BlcmF0aW9uJ1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAL3V0aWxzL2Vycm9ycydcbmltcG9ydCB7IEdsb2JlLCBGaWxlVGV4dCwgRGF0YWJhc2UsIFNwYXJrbGVzLCBDaGVja0NpcmNsZTIsIEFycm93UmlnaHQsIExheWVycywgQWxlcnRDaXJjbGUsIExvYWRlcjIgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmV4cG9ydCBjb25zdCBJbmdlc3RUYWI6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IGNyZWRzIH0gPSB1c2VPdXRsZXRDb250ZXh0PHsgY3JlZHM6IEFwaUNyZWRlbnRpYWxzIH0+KClcbiAgY29uc3QgW2FjdGl2ZVN1YlRhYiwgc2V0QWN0aXZlU3ViVGFiXSA9IHVzZVN0YXRlPCd1cmwnIHwgJ3RleHQnPigndXJsJylcbiAgXG4gIC8vIFVSTCBJbmdlc3Rpb24gRm9ybSBTdGF0ZVxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJ2h0dHBzOi8vZnJlZWFjYWRlbXkuYWkvbGVzc29ucy9tZW1vcnktYW5kLWNvbnRleHQtcmFnJylcbiAgY29uc3QgW2NodW5rU2l6ZSwgc2V0Q2h1bmtTaXplXSA9IHVzZVN0YXRlKDUwMClcbiAgXG4gIC8vIFRleHQgSW5nZXN0aW9uIEZvcm0gU3RhdGVcbiAgY29uc3QgW3RleHRUaXRsZSwgc2V0VGV4dFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdGV4dENvbnRlbnQsIHNldFRleHRDb250ZW50XSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdGV4dFNvdXJjZVVybCwgc2V0VGV4dFNvdXJjZVVybF0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzdGF0dXNNZXNzYWdlLCBzZXRTdGF0dXNNZXNzYWdlXSA9IHVzZVN0YXRlPHsgdHlwZTogJ3N1Y2Nlc3MnIHwgJ2Vycm9yJzsgdGV4dDogc3RyaW5nIH0gfCBudWxsPihudWxsKVxuICBjb25zdCBbZG9jU3RhdHMsIHNldERvY1N0YXRzXSA9IHVzZVN0YXRlPERvY3VtZW50U3RhdHMgfCBudWxsPihudWxsKVxuXG4gIGNvbnN0IGxvYWRTdGF0cyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RhdHMgPSBhd2FpdCBBcGlPcGVyYXRpb25zLmZldGNoRG9jdW1lbnRzKClcbiAgICAgIHNldERvY1N0YXRzKHN0YXRzKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUud2FybignRmFpbGVkIHRvIGxvYWQgZG9jIHN0YXRzOicsIGUpXG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2FkU3RhdHMoKVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVJbmdlc3RVcmwgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgaWYgKCF1cmwudHJpbSgpIHx8IGlzTG9hZGluZykgcmV0dXJuXG5cbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSlcbiAgICBzZXRTdGF0dXNNZXNzYWdlKG51bGwpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQXBpT3BlcmF0aW9ucy5pbmdlc3RVcmwodXJsLCBjaHVua1NpemUpXG4gICAgICBzZXRTdGF0dXNNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxuICAgICAgICB0ZXh0OiBgU3VjY2Vzc2Z1bGx5IHNjcmFwZWQgcGFnZSB2aWEgRmlyZWNyYXdsISBUaXRsZTogXCIke3Jlcy5kYXRhLnRpdGxlfVwiIOKAoiBHZW5lcmF0ZWQgJHtyZXMuZGF0YS50b3RhbENodW5rc30gdmVjdG9yIGNodW5rcy5gXG4gICAgICB9KVxuICAgICAgc2V0VXJsKCcnKVxuICAgICAgbG9hZFN0YXRzKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnIgaW5zdGFuY2VvZiBIdHRwRXJyb3JSZXNwb25zZSA/IGVyci5tZXNzYWdlIDogJ0ZpcmVjcmF3bCB3ZWIgaW5nZXN0aW9uIGZhaWxlZCdcbiAgICAgIHNldFN0YXR1c01lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiAnZXJyb3InLFxuICAgICAgICB0ZXh0OiBtZXNzYWdlXG4gICAgICB9KVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlSW5nZXN0VGV4dCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBpZiAoIXRleHRUaXRsZS50cmltKCkgfHwgIXRleHRDb250ZW50LnRyaW0oKSB8fCBpc0xvYWRpbmcpIHJldHVyblxuXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpXG4gICAgc2V0U3RhdHVzTWVzc2FnZShudWxsKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFwaU9wZXJhdGlvbnMuaW5nZXN0VGV4dCh0ZXh0VGl0bGUsIHRleHRDb250ZW50LCB0ZXh0U291cmNlVXJsIHx8ICcnLCBjaHVua1NpemUpXG4gICAgICBzZXRTdGF0dXNNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxuICAgICAgICB0ZXh0OiBgU3VjY2Vzc2Z1bGx5IGNyZWF0ZWQgZG9jdW1lbnQ6IFwiJHtyZXMuZGF0YS50aXRsZX1cIiDigKIgR2VuZXJhdGVkICR7cmVzLmRhdGEudG90YWxDaHVua3N9IHZlY3RvciBjaHVua3MuYFxuICAgICAgfSlcbiAgICAgIHNldFRleHRUaXRsZSgnJylcbiAgICAgIHNldFRleHRDb250ZW50KCcnKVxuICAgICAgc2V0VGV4dFNvdXJjZVVybCgnJylcbiAgICAgIGxvYWRTdGF0cygpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0gZXJyIGluc3RhbmNlb2YgSHR0cEVycm9yUmVzcG9uc2UgPyBlcnIubWVzc2FnZSA6ICdUZXh0IGRvY3VtZW50IGluZ2VzdGlvbiBmYWlsZWQnXG4gICAgICBzZXRTdGF0dXNNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcbiAgICAgICAgdGV4dDogbWVzc2FnZVxuICAgICAgfSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBtYXhXaWR0aDogJzEyMDBweCcsIG1hcmdpbjogJzAgYXV0bycsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzI0cHgnIH19PlxuICAgICAgXG4gICAgICB7LyogVG9wIEJhbm5lciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcyNHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgZmxleFdyYXA6ICd3cmFwJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIHN0eWxlPXt7IGZvbnRTaXplOiAnMjBweCcsIGZvbnRXZWlnaHQ6ICc3MDAnLCBtYXJnaW46ICcwIDAgNnB4IDAnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcxMHB4JyB9fT5cbiAgICAgICAgICAgIDxHbG9iZSBjb2xvcj1cInZhcigtLWFjY2VudC1jeWFuKVwiIC8+XG4gICAgICAgICAgICBGaXJlY3Jhd2wgV2ViIEluZ2VzdGlvbiAmIFJBRyBWZWN0b3IgTG9hZGVyXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJywgbWFyZ2luOiAwIH19PlxuICAgICAgICAgICAgU2NyYXBlIGNsZWFuIG1hcmtkb3duIGNvbnRlbnQgZnJvbSBhbnkgd2Vic2l0ZSB1c2luZyAqKkZpcmVjcmF3bCoqLCBzcGxpdCBpbnRvIHNlbWFudGljIGNodW5rcywgZ2VuZXJhdGUgMTUzNi1kaW0gZW1iZWRkaW5ncywgYW5kIGluZGV4IGludG8gKipTdXBhYmFzZSBwZ3ZlY3RvcioqLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFF1aWNrIFN0YXRzIFdpZGdldCAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzE2cHgnIH19PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMTMsIDIxLCAzOSwgMC44KScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgYm9yZGVyUmFkaXVzOiAnMTJweCcsIHBhZGRpbmc6ICcxMnB4IDIwcHgnLCB0ZXh0QWxpZ246ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzIycHgnLCBmb250V2VpZ2h0OiAnODAwJywgY29sb3I6ICcjNjdlOGY5JyB9fT57ZG9jU3RhdHM/LnRvdGFsRG9jdW1lbnRzIHx8IDB9PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tdXRlZCknIH19PkRvY3VtZW50czwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMTMsIDIxLCAzOSwgMC44KScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgYm9yZGVyUmFkaXVzOiAnMTJweCcsIHBhZGRpbmc6ICcxMnB4IDIwcHgnLCB0ZXh0QWxpZ246ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzIycHgnLCBmb250V2VpZ2h0OiAnODAwJywgY29sb3I6ICcjYTViNGZjJyB9fT57ZG9jU3RhdHM/LnRvdGFsQ2h1bmtzIHx8IDB9PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tdXRlZCknIH19PlZlY3RvciBDaHVua3M8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgNDAwcHgnLCBnYXA6ICcyNHB4JyB9fT5cbiAgICAgICAgXG4gICAgICAgIHsvKiBJbmdlc3Rpb24gRm9ybSBQYW5lbCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbGFzcy1jYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnIH19PlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBTdWItVGFiIFNlbGVjdG9yICovfVxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcxMnB4JywgbWFyZ2luQm90dG9tOiAnMjBweCcsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgcGFkZGluZ0JvdHRvbTogJzEycHgnIH19PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ3VybCcpfVxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGFjdGl2ZVN1YlRhYiA9PT0gJ3VybCcgPyAncmdiYSg2LCAxODIsIDIxMiwgMC4yKScgOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogYWN0aXZlU3ViVGFiID09PSAndXJsJyA/ICcxcHggc29saWQgcmdiYSg2LCAxODIsIDIxMiwgMC40KScgOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgY29sb3I6IGFjdGl2ZVN1YlRhYiA9PT0gJ3VybCcgPyAnIzY3ZThmOScgOiAndmFyKC0tdGV4dC1tdXRlZCknLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXG4gICAgICAgICAgICAgICAgcGFkZGluZzogJzhweCAxNnB4JyxcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogJzEzcHgnLFxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxuICAgICAgICAgICAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICAgICAgICBnYXA6ICc4cHgnXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxHbG9iZSBzaXplPXsxNn0gLz4gRmlyZWNyYXdsIFVSTCBTY3JhcGVcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ3RleHQnKX1cbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBhY3RpdmVTdWJUYWIgPT09ICd0ZXh0JyA/ICdyZ2JhKDk5LCAxMDIsIDI0MSwgMC4yKScgOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogYWN0aXZlU3ViVGFiID09PSAndGV4dCcgPyAnMXB4IHNvbGlkIHJnYmEoOTksIDEwMiwgMjQxLCAwLjQpJyA6ICdub25lJyxcbiAgICAgICAgICAgICAgICBjb2xvcjogYWN0aXZlU3ViVGFiID09PSAndGV4dCcgPyAnI2E1YjRmYycgOiAndmFyKC0tdGV4dC1tdXRlZCknLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXG4gICAgICAgICAgICAgICAgcGFkZGluZzogJzhweCAxNnB4JyxcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogJzEzcHgnLFxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6ICc2MDAnLFxuICAgICAgICAgICAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICAgICAgICBnYXA6ICc4cHgnXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxGaWxlVGV4dCBzaXplPXsxNn0gLz4gUmF3IERvY3VtZW50IFRleHRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEZvcm0gRmVlZGJhY2sgKi99XG4gICAgICAgICAge3N0YXR1c01lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICBwYWRkaW5nOiAnMTJweCAxNnB4JyxcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnOHB4JyxcbiAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjBweCcsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IHN0YXR1c01lc3NhZ2UudHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJ3JnYmEoMTYsIDE4NSwgMTI5LCAwLjE1KScgOiAncmdiYSgyMzksIDY4LCA2OCwgMC4xNSknLFxuICAgICAgICAgICAgICBib3JkZXI6IHN0YXR1c01lc3NhZ2UudHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJzFweCBzb2xpZCByZ2JhKDE2LCAxODUsIDEyOSwgMC4zKScgOiAnMXB4IHNvbGlkIHJnYmEoMjM5LCA2OCwgNjgsIDAuMyknLFxuICAgICAgICAgICAgICBjb2xvcjogc3RhdHVzTWVzc2FnZS50eXBlID09PSAnc3VjY2VzcycgPyAnIzZlZTdiNycgOiAnI2ZjYTVhNScsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAnMTNweCdcbiAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICB7c3RhdHVzTWVzc2FnZS50ZXh0fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVTdWJUYWIgPT09ICd1cmwnID8gKFxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUluZ2VzdFVybH0gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycsIGZvbnRTaXplOiAnMTNweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBtYXJnaW5Cb3R0b206ICc4cHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbWFpbiknIH19PlxuICAgICAgICAgICAgICAgICAgVGFyZ2V0IFdlYiBQYWdlIFVSTCB0byBTY3JhcGUgKEZpcmVjcmF3bCk6XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ1cmxcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2V4YW1wbGUuY29tL2FydGljbGVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VybH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXJsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgZm9udFNpemU6ICcxM3B4JywgZm9udFdlaWdodDogJzYwMCcsIG1hcmdpbkJvdHRvbTogJzhweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tYWluKScgfX0+XG4gICAgICAgICAgICAgICAgICBDaHVuayBDaGFyYWN0ZXIgTGltaXQgKFNlbWFudGljIFdpbmRvdyk6XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgbWluPXsxMDB9XG4gICAgICAgICAgICAgICAgICBtYXg9ezIwMDB9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y2h1bmtTaXplfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDaHVua1NpemUoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzExcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScsIG1hcmdpblRvcDogJzRweCcsIGRpc3BsYXk6ICdibG9jaycgfX0+XG4gICAgICAgICAgICAgICAgICBSZWNvbW1lbmRlZDogNTAwIGNoYXJhY3RlcnMgcGVyIGNodW5rIGZvciBoaWdoIHNpbWlsYXJpdHkgcHJlY2lzaW9uLlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17aXNMb2FkaW5nfSBzdHlsZT17eyBtYXJnaW5Ub3A6ICc4cHgnIH19PlxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgc2l6ZT17MTZ9IC8+IDogPEdsb2JlIHNpemU9ezE2fSAvPn1cbiAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gJ0NyYXdsaW5nICYgVmVjdG9yaXppbmcuLi4nIDogJ1NjcmFwZSAmIEluZ2VzdCB2aWEgRmlyZWNyYXdsJ31cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVJbmdlc3RUZXh0fSBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxNnB4JyB9fT5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgZm9udFNpemU6ICcxM3B4JywgZm9udFdlaWdodDogJzYwMCcsIG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICBEb2N1bWVudCBUaXRsZTpcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEZyZWVBY2FkZW15IFJBRyBNb2R1bGUgQXJjaGl0ZWN0dXJlIE5vdGVzXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZXh0VGl0bGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRleHRUaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycsIGZvbnRTaXplOiAnMTNweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBtYXJnaW5Cb3R0b206ICc4cHgnIH19PlxuICAgICAgICAgICAgICAgICAgU291cmNlIFVSTCAoT3B0aW9uYWwpOlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImh0dHBzOi8vZnJlZWFjYWRlbXkuYWkvbGVzc29ucy9tZW1vcnktYW5kLWNvbnRleHQtcmFnXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZXh0U291cmNlVXJsfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZXh0U291cmNlVXJsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiAnYmxvY2snLCBmb250U2l6ZTogJzEzcHgnLCBmb250V2VpZ2h0OiAnNjAwJywgbWFyZ2luQm90dG9tOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgIFJhdyBEb2N1bWVudCBDb250ZW50OlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBtaW5IZWlnaHQ6ICcxNjBweCcsIHJlc2l6ZTogJ3ZlcnRpY2FsJyB9fVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXN0ZSBsZXNzb24gbWFya2Rvd24sIGFydGljbGUgdGV4dCwgb3IgbWFudWFsIGZhY3RzIGhlcmUuLi5cIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RleHRDb250ZW50fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZXh0Q29udGVudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzTG9hZGluZ30+XG4gICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IDxTcGFya2xlcyBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW5cIiBzaXplPXsxNn0gLz4gOiA8RmlsZVRleHQgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAnUHJvY2Vzc2luZyBWZWN0b3JzLi4uJyA6ICdWZWN0b3JpemUgRG9jdW1lbnQnfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICApfVxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBFeGlzdGluZyBEb2N1bWVudHMgTGlzdCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbGFzcy1jYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxNnB4JyB9fT5cbiAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6ICcxNnB4JywgZm9udFdlaWdodDogJzcwMCcsIG1hcmdpbjogMCwgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgIDxEYXRhYmFzZSBzaXplPXsxOH0gY29sb3I9XCJ2YXIoLS1wcmltYXJ5KVwiIC8+XG4gICAgICAgICAgICBJbmdlc3RlZCBEb2N1bWVudHMgKHtkb2NTdGF0cz8uZG9jdW1lbnRzPy5sZW5ndGggfHwgMH0pXG4gICAgICAgICAgPC9oMz5cblxuICAgICAgICAgIHshZG9jU3RhdHM/LmRvY3VtZW50cyB8fCBkb2NTdGF0cy5kb2N1bWVudHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScsIGZvbnRTaXplOiAnMTJweCcsIHRleHRBbGlnbjogJ2NlbnRlcicsIHBhZGRpbmc6ICczMHB4IDAnIH19PlxuICAgICAgICAgICAgICBObyBkb2N1bWVudHMgaW5nZXN0ZWQgeWV0LiBTdWJtaXQgYSBVUkwgYWJvdmUhXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxMHB4JywgbWF4SGVpZ2h0OiAnNDAwcHgnLCBvdmVyZmxvd1k6ICdhdXRvJyB9fT5cbiAgICAgICAgICAgICAge2RvY1N0YXRzLmRvY3VtZW50cy5tYXAoKGRvYykgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkb2MuaWR9IHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyZ2JhKDEzLCAyMSwgMzksIDAuNyknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKScsIGJvcmRlclJhZGl1czogJzEwcHgnLCBwYWRkaW5nOiAnMTJweCcgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRXZWlnaHQ6ICc2MDAnLCBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbWFpbiknLCBtYXJnaW5Cb3R0b206ICc0cHgnIH19PlxuICAgICAgICAgICAgICAgICAgICB7ZG9jLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7ZG9jLnNvdXJjZV91cmwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPXtkb2Muc291cmNlX3VybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiAnIzY3ZThmOScsIHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGRpc3BsYXk6ICdibG9jaycsIG92ZXJmbG93OiAnaGlkZGVuJywgdGV4dE92ZXJmbG93OiAnZWxsaXBzaXMnLCB3aGl0ZVNwYWNlOiAnbm93cmFwJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7ZG9jLnNvdXJjZV91cmx9IOKGl1xuICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEwcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScsIG1hcmdpblRvcDogJzZweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIEFkZGVkOiB7bmV3IERhdGUoZG9jLmNyZWF0ZWRfYXQpLnRvTG9jYWxlRGF0ZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiJDOi9ub2RlL2xsbS9jbGllbnQvc3JjL3ZpZXdzL0luZ2VzdFRhYi50c3gifQ==