import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ChatTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/ChatTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=90a7bf15";
import { ApiOperations } from "/src/operations/api.operation.ts";
import { HttpErrorResponse } from "/src/utils/errors.ts";
import { Send, Bot, User, Brain, Database, Search, Sparkles, SlidersHorizontal } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
export const ChatTab = () => {
  _s();
  const { creds } = useOutletContext();
  const [messages, setMessages] = useState(
    [
      {
        id: "welcome",
        role: "assistant",
        content: `Hello! I am your **Memory & Context RAG Engine**.

I combine **Short-Term Memory**, **Long-Term Vector Memory (Supabase)**, **Vector Knowledge Base (pgvector)**, and **Live Web Grounding (Tavily)**.

Try telling me something about yourself like: *"My name is Sarah and I prefer TypeScript over Python"* or ask a question!`,
        timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString()
      }
    ]
  );
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [useRag, setUseRag] = useState(true);
  const [useTavily, setUseTavily] = useState(true);
  const [useMemory, setUseMemory] = useState(true);
  const [selectedMessageContext, setSelectedMessageContext] = useState(null);
  const messagesEndRef = useRef(null);
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);
  const handleSend = async (textToSend) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;
    const userMsg = {
      id: `user_${Date.now()}`,
      role: "user",
      content: query,
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString()
    };
    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput("");
    setIsLoading(true);
    try {
      const historyForApi = [...messages, userMsg].map((m) => ({
        role: m.role,
        content: m.content
      }));
      const res = await ApiOperations.chat(historyForApi, { useRag, useTavily, useMemory, ...creds });
      const assistantMsg = {
        id: `assistant_${Date.now()}`,
        role: "assistant",
        content: res.answer,
        timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
        ragContext: {
          memoriesUsed: res.memoriesUsed || [],
          vectorChunksUsed: res.vectorChunksUsed || [],
          tavilyResultsUsed: res.tavilyResultsUsed || [],
          newMemoriesExtracted: res.newMemoriesExtracted || []
        }
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setSelectedMessageContext(assistantMsg.ragContext);
    } catch (err) {
      const message = err instanceof HttpErrorResponse ? err.message : "Unknown error";
      setMessages(
        (prev) => [
          ...prev,
          {
            id: `err_${Date.now()}`,
            role: "assistant",
            content: `⚠️ Error processing RAG completion: ${message}`,
            timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString()
          }
        ]
      );
    } finally {
      setIsLoading(false);
    }
  };
  const samplePrompts = [
    "My name is Sarah, I am building an AI startup in San Francisco.",
    "What do you remember about me and my goals?",
    "Search Tavily for latest developments in LLM Context Windows",
    "Explain how RAG memory architecture works in Supabase"
  ];
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 380px", gap: "20px", height: "calc(100vh - 140px)" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { display: "flex", flexDirection: "column", overflow: "hidden" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: {
        padding: "12px 20px",
        background: "rgba(255, 255, 255, 0.6)",
        borderBottom: "1px solid var(--border-color)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: "12px"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "8px", fontSize: "13px", color: "var(--text-muted)" }, children: [
          /* @__PURE__ */ jsxDEV(SlidersHorizontal, { size: 16, color: "var(--primary)" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 129,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: { fontWeight: "600", color: "var(--text-main)" }, children: "RAG Pipeline Controls:" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 130,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 128,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "12px" }, children: [
          /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "6px", cursor: "pointer", fontSize: "12px" }, children: [
            /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: useMemory, onChange: (e) => setUseMemory(e.target.checked) }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 135,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Brain, { size: 14, color: "#a5b4fc" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 136,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Memory Recall" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 137,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 134,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "6px", cursor: "pointer", fontSize: "12px" }, children: [
            /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: useRag, onChange: (e) => setUseRag(e.target.checked) }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 141,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Database, { size: 14, color: "#67e8f9" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 142,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "pgvector RAG" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 143,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 140,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "6px", cursor: "pointer", fontSize: "12px" }, children: [
            /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: useTavily, onChange: (e) => setUseTavily(e.target.checked) }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 147,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Search, { size: 14, color: "#6ee7b7" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 148,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Tavily Grounding" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 149,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 146,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 133,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, overflowY: "auto", padding: "20px", display: "flex", flexDirection: "column", gap: "16px" }, children: [
        messages.map(
          (msg) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "animate-fade-in",
              style: {
                display: "flex",
                gap: "12px",
                alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
                maxWidth: msg.role === "user" ? "80%" : "90%"
              },
              children: [
                msg.role !== "user" && /* @__PURE__ */ jsxDEV("div", { style: {
                  width: "36px",
                  height: "36px",
                  borderRadius: "10px",
                  background: "var(--primary-gradient)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0
                }, children: /* @__PURE__ */ jsxDEV(Bot, { size: 20, color: "#fff" }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 178,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 168,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "6px" }, children: [
                  /* @__PURE__ */ jsxDEV("div", { style: {
                    padding: "14px 18px",
                    borderRadius: "14px",
                    background: msg.role === "user" ? "var(--primary-gradient)" : "var(--bg-card)",
                    border: msg.role === "user" ? "none" : "1px solid var(--border-color)",
                    color: msg.role === "user" ? "#ffffff" : "var(--text-main)",
                    fontSize: "14px",
                    lineHeight: "1.6",
                    whiteSpace: "pre-wrap",
                    boxShadow: msg.role === "user" ? "0 4px 15px rgba(99, 102, 241, 0.25)" : "var(--shadow-card)"
                  }, children: msg.content }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                    lineNumber: 183,
                    columnNumber: 17
                  }, this),
                  msg.ragContext && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "6px", flexWrap: "wrap", marginTop: "4px" }, children: [
                    msg.ragContext.memoriesUsed.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "badge badge-indigo", onClick: () => setSelectedMessageContext(msg.ragContext), style: { cursor: "pointer" }, children: [
                      /* @__PURE__ */ jsxDEV(Brain, { size: 10 }, void 0, false, {
                        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                        lineNumber: 202,
                        columnNumber: 25
                      }, this),
                      " ",
                      msg.ragContext.memoriesUsed.length,
                      " Memories Recalled"
                    ] }, void 0, true, {
                      fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                      lineNumber: 201,
                      columnNumber: 17
                    }, this),
                    msg.ragContext.vectorChunksUsed.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "badge badge-cyan", onClick: () => setSelectedMessageContext(msg.ragContext), style: { cursor: "pointer" }, children: [
                      /* @__PURE__ */ jsxDEV(Database, { size: 10 }, void 0, false, {
                        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                        lineNumber: 207,
                        columnNumber: 25
                      }, this),
                      " ",
                      msg.ragContext.vectorChunksUsed.length,
                      " Vector Chunks"
                    ] }, void 0, true, {
                      fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                      lineNumber: 206,
                      columnNumber: 17
                    }, this),
                    msg.ragContext.tavilyResultsUsed.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "badge badge-emerald", onClick: () => setSelectedMessageContext(msg.ragContext), style: { cursor: "pointer" }, children: [
                      /* @__PURE__ */ jsxDEV(Search, { size: 10 }, void 0, false, {
                        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                        lineNumber: 212,
                        columnNumber: 25
                      }, this),
                      " ",
                      msg.ragContext.tavilyResultsUsed.length,
                      " Web Sources"
                    ] }, void 0, true, {
                      fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                      lineNumber: 211,
                      columnNumber: 17
                    }, this),
                    msg.ragContext.newMemoriesExtracted.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "badge badge-amber", children: [
                      /* @__PURE__ */ jsxDEV(Sparkles, { size: 10 }, void 0, false, {
                        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                        lineNumber: 217,
                        columnNumber: 25
                      }, this),
                      " ",
                      msg.ragContext.newMemoriesExtracted.length,
                      " New Memory Extracted"
                    ] }, void 0, true, {
                      fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                      lineNumber: 216,
                      columnNumber: 17
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                    lineNumber: 199,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "10px", color: "var(--text-dim)", alignSelf: msg.role === "user" ? "flex-end" : "flex-start" }, children: msg.timestamp }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                    lineNumber: 223,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 182,
                  columnNumber: 15
                }, this),
                msg.role === "user" && /* @__PURE__ */ jsxDEV("div", { style: {
                  width: "36px",
                  height: "36px",
                  borderRadius: "10px",
                  background: "rgba(255, 255, 255, 0.1)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  border: "1px solid var(--border-color)"
                }, children: /* @__PURE__ */ jsxDEV(User, { size: 20, color: "var(--text-main)" }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 240,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 229,
                  columnNumber: 13
                }, this)
              ]
            },
            msg.id,
            true,
            {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 157,
              columnNumber: 11
            },
            this
          )
        ),
        isLoading && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "12px", color: "var(--text-muted)", fontSize: "13px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { width: "36px", height: "36px", borderRadius: "10px", background: "var(--primary-gradient)", display: "flex", alignItems: "center", justifyContent: "center" }, children: /* @__PURE__ */ jsxDEV(Sparkles, { size: 20, color: "#fff", className: "animate-spin" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 249,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 248,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Searching Supabase pgvector + Tavily & Synthesizing response..." }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 251,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 247,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 255,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 155,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { padding: "0 20px 10px", display: "flex", gap: "8px", overflowX: "auto" }, children: samplePrompts.map(
        (prompt, idx) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleSend(prompt),
            style: {
              background: "rgba(255, 255, 255, 0.03)",
              border: "1px solid var(--border-color)",
              borderRadius: "20px",
              padding: "6px 12px",
              color: "var(--text-muted)",
              fontSize: "11px",
              cursor: "pointer",
              whiteSpace: "nowrap",
              transition: "all 0.2s"
            },
            onMouseEnter: (e) => e.currentTarget.style.borderColor = "var(--primary)",
            onMouseLeave: (e) => e.currentTarget.style.borderColor = "var(--border-color)",
            children: [
              "⚡ ",
              prompt
            ]
          },
          idx,
          true,
          {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 261,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 259,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { padding: "16px 20px", background: "rgba(255, 255, 255, 0.6)", borderTop: "1px solid var(--border-color)", display: "flex", gap: "12px" }, children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            className: "glass-input",
            style: { flex: 1 },
            placeholder: "Type your message or tell me a preference (e.g. 'I prefer PostgreSQL and Zod')...",
            value: input,
            onChange: (e) => setInput(e.target.value),
            onKeyDown: (e) => e.key === "Enter" && handleSend(),
            disabled: isLoading
          },
          void 0,
          false,
          {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 285,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", onClick: () => handleSend(), disabled: isLoading || !input.trim(), children: [
          /* @__PURE__ */ jsxDEV(Send, { size: 16 }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 295,
            columnNumber: 13
          }, this),
          " Send"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 294,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 284,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "20px", display: "flex", flexDirection: "column", gap: "16px", overflowY: "auto" }, children: [
      /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "16px", fontWeight: "700", margin: 0, display: "flex", alignItems: "center", gap: "8px" }, children: [
        /* @__PURE__ */ jsxDEV(Brain, { size: 18, color: "var(--primary)" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 304,
          columnNumber: 11
        }, this),
        "RAG Context Inspector"
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 303,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "12px", color: "var(--text-muted)", margin: 0 }, children: "Real-time view of retrieved Supabase vector chunks, active memories, and Tavily web results used for synthesis." }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 307,
        columnNumber: 9
      }, this),
      !selectedMessageContext ? /* @__PURE__ */ jsxDEV("div", { style: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "var(--text-dim)", textAlign: "center", gap: "8px" }, children: [
        /* @__PURE__ */ jsxDEV(Sparkles, { size: 32 }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 313,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "13px" }, children: "Send a message to inspect RAG grounding and memory extraction context." }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 314,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 312,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
        selectedMessageContext.newMemoriesExtracted.length > 0 && /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(245, 158, 11, 0.1)", border: "1px solid rgba(245, 158, 11, 0.3)", borderRadius: "10px", padding: "12px" }, children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "12px", color: "#fcd34d", margin: "0 0 8px 0", display: "flex", alignItems: "center", gap: "6px" }, children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { size: 14 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 323,
              columnNumber: 19
            }, this),
            " Memory Extracted (Zod Parsed)"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 322,
            columnNumber: 17
          }, this),
          selectedMessageContext.newMemoriesExtracted.map(
            (m, i) => /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "12px", color: "var(--text-main)", background: "rgba(255,255,255,0.8)", padding: "6px 10px", borderRadius: "6px", marginBottom: "4px", border: "1px solid var(--border-color)" }, children: [
              "[",
              m.category,
              "] ",
              m.content
            ] }, i, true, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 326,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 321,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "13px", color: "#a5b4fc", marginBottom: "8px", display: "flex", alignItems: "center", gap: "6px" }, children: [
            /* @__PURE__ */ jsxDEV(Brain, { size: 14 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 336,
              columnNumber: 17
            }, this),
            " Recalled Memories (",
            selectedMessageContext.memoriesUsed.length,
            ")"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 335,
            columnNumber: 15
          }, this),
          selectedMessageContext.memoriesUsed.length === 0 ? /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "11px", color: "var(--text-dim)" }, children: "No prior memories matched query embedding." }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 339,
            columnNumber: 13
          }, this) : selectedMessageContext.memoriesUsed.map(
            (m, i) => /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(99, 102, 241, 0.1)", border: "1px solid rgba(99, 102, 241, 0.2)", borderRadius: "8px", padding: "10px", marginBottom: "6px", fontSize: "12px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "10px", color: "var(--text-muted)" }, children: [
                /* @__PURE__ */ jsxDEV("span", { className: "badge badge-indigo", children: m.category }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 344,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "Sim: ",
                  (m.similarity * 100).toFixed(1),
                  "%"
                ] }, void 0, true, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 345,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                lineNumber: 343,
                columnNumber: 21
              }, this),
              m.content
            ] }, i, true, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 342,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 334,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "13px", color: "#67e8f9", marginBottom: "8px", display: "flex", alignItems: "center", gap: "6px" }, children: [
            /* @__PURE__ */ jsxDEV(Database, { size: 14 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 356,
              columnNumber: 17
            }, this),
            " Vector Chunks (",
            selectedMessageContext.vectorChunksUsed.length,
            ")"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 355,
            columnNumber: 15
          }, this),
          selectedMessageContext.vectorChunksUsed.length === 0 ? /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "11px", color: "var(--text-dim)" }, children: "No document vector chunks retrieved. Ingest URLs via Firecrawl to populate!" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 359,
            columnNumber: 13
          }, this) : selectedMessageContext.vectorChunksUsed.map(
            (c, i) => /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(6, 182, 212, 0.1)", border: "1px solid rgba(6, 182, 212, 0.2)", borderRadius: "8px", padding: "10px", marginBottom: "6px", fontSize: "12px" }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", marginBottom: "4px", fontSize: "10px", color: "var(--text-muted)" }, children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "Chunk #",
                  i + 1
                ] }, void 0, true, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 364,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "Sim: ",
                  (c.similarity * 100).toFixed(1),
                  "%"
                ] }, void 0, true, {
                  fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                  lineNumber: 365,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                lineNumber: 363,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-main)", display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }, children: c.content }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                lineNumber: 367,
                columnNumber: 21
              }, this)
            ] }, i, true, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 362,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 354,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { style: { fontSize: "13px", color: "#6ee7b7", marginBottom: "8px", display: "flex", alignItems: "center", gap: "6px" }, children: [
            /* @__PURE__ */ jsxDEV(Search, { size: 14 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 378,
              columnNumber: 17
            }, this),
            " Tavily Web Grounding (",
            selectedMessageContext.tavilyResultsUsed.length,
            ")"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 377,
            columnNumber: 15
          }, this),
          selectedMessageContext.tavilyResultsUsed.length === 0 ? /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "11px", color: "var(--text-dim)" }, children: "Tavily search disabled or no results." }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
            lineNumber: 381,
            columnNumber: 13
          }, this) : selectedMessageContext.tavilyResultsUsed.map(
            (t, i) => /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(16, 185, 129, 0.1)", border: "1px solid rgba(16, 185, 129, 0.2)", borderRadius: "8px", padding: "10px", marginBottom: "6px", fontSize: "12px" }, children: [
              /* @__PURE__ */ jsxDEV("a", { href: t.url, target: "_blank", rel: "noreferrer", style: { color: "#6ee7b7", textDecoration: "none", fontWeight: "600", display: "block", marginBottom: "4px" }, children: [
                t.title,
                " ↗"
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                lineNumber: 385,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-muted)" }, children: t.content }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
                lineNumber: 388,
                columnNumber: 21
              }, this)
            ] }, i, true, {
              fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
              lineNumber: 384,
              columnNumber: 13
            }, this)
          )
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
          lineNumber: 376,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
        lineNumber: 317,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
      lineNumber: 302,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/ChatTab.tsx",
    lineNumber: 112,
    columnNumber: 5
  }, this);
};
_s(ChatTab, "o6CVnYv9vGuyRhRauabcvQlW4lY=", false, function() {
  return [useOutletContext];
});
_c = ChatTab;
var _c;
$RefreshReg$(_c, "ChatTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/ChatTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/ChatTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkdZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdHWixTQUFnQkEsVUFBVUMsUUFBUUMsaUJBQWlCO0FBQ25ELFNBQVNDLHdCQUF3QjtBQUVqQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLE1BQU1DLEtBQUtDLE1BQU1DLE9BQU9DLFVBQVVDLFFBQVFDLFVBQVVDLHlCQUFxRDtBQUUzRyxhQUFNQyxVQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU0sRUFBRUMsTUFBTSxJQUFJYixpQkFBNEM7QUFDOUQsUUFBTSxDQUFDYyxVQUFVQyxXQUFXLElBQUlsQjtBQUFBQSxJQUFvQjtBQUFBLE1BQ2xEO0FBQUEsUUFDRW1CLElBQUk7QUFBQSxRQUNKQyxNQUFNO0FBQUEsUUFDTkMsU0FBUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFDVEMsWUFBVyxvQkFBSUMsS0FBSyxHQUFFQyxtQkFBbUI7QUFBQSxNQUMzQztBQUFBLElBQUM7QUFBQSxFQUNGO0FBQ0QsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUkxQixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMkIsV0FBV0MsWUFBWSxJQUFJNUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzZCLFFBQVFDLFNBQVMsSUFBSTlCLFNBQVMsSUFBSTtBQUN6QyxRQUFNLENBQUMrQixXQUFXQyxZQUFZLElBQUloQyxTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBUyxJQUFJO0FBQy9DLFFBQU0sQ0FBQ21DLHdCQUF3QkMseUJBQXlCLElBQUlwQyxTQUF1QyxJQUFJO0FBRXZHLFFBQU1xQyxpQkFBaUJwQyxPQUF1QixJQUFJO0FBRWxEQyxZQUFVLE1BQU07QUFDZG1DLG1CQUFlQyxTQUFTQyxlQUFlLEVBQUVDLFVBQVUsU0FBUyxDQUFDO0FBQUEsRUFDL0QsR0FBRyxDQUFDdkIsVUFBVVUsU0FBUyxDQUFDO0FBRXhCLFFBQU1jLGFBQWEsT0FBT0MsZUFBd0I7QUFDaEQsVUFBTUMsU0FBU0QsY0FBY2pCLE9BQU9tQixLQUFLO0FBQ3pDLFFBQUksQ0FBQ0QsU0FBU2hCLFVBQVc7QUFFekIsVUFBTWtCLFVBQW1CO0FBQUEsTUFDdkIxQixJQUFJLFFBQVFJLEtBQUt1QixJQUFJLENBQUM7QUFBQSxNQUN0QjFCLE1BQU07QUFBQSxNQUNOQyxTQUFTc0I7QUFBQUEsTUFDVHJCLFlBQVcsb0JBQUlDLEtBQUssR0FBRUMsbUJBQW1CO0FBQUEsSUFDM0M7QUFFQU4sZ0JBQVksQ0FBQzZCLFNBQVMsQ0FBQyxHQUFHQSxNQUFNRixPQUFPLENBQUM7QUFDeEMsUUFBSSxDQUFDSCxXQUFZaEIsVUFBUyxFQUFFO0FBQzVCRSxpQkFBYSxJQUFJO0FBRWpCLFFBQUk7QUFDRixZQUFNb0IsZ0JBQWdCLENBQUMsR0FBRy9CLFVBQVU0QixPQUFPLEVBQUVJLElBQUksQ0FBQ0MsT0FBTztBQUFBLFFBQ3ZEOUIsTUFBTThCLEVBQUU5QjtBQUFBQSxRQUNSQyxTQUFTNkIsRUFBRTdCO0FBQUFBLE1BQ2IsRUFBRTtBQUVGLFlBQU04QixNQUFNLE1BQU0vQyxjQUFjZ0QsS0FBS0osZUFBZSxFQUFFbkIsUUFBUUUsV0FBV0UsV0FBVyxHQUFHakIsTUFBTSxDQUFDO0FBRTlGLFlBQU1xQyxlQUF3QjtBQUFBLFFBQzVCbEMsSUFBSSxhQUFhSSxLQUFLdUIsSUFBSSxDQUFDO0FBQUEsUUFDM0IxQixNQUFNO0FBQUEsUUFDTkMsU0FBUzhCLElBQUlHO0FBQUFBLFFBQ2JoQyxZQUFXLG9CQUFJQyxLQUFLLEdBQUVDLG1CQUFtQjtBQUFBLFFBQ3pDK0IsWUFBWTtBQUFBLFVBQ1ZDLGNBQWNMLElBQUlLLGdCQUFnQjtBQUFBLFVBQ2xDQyxrQkFBa0JOLElBQUlNLG9CQUFvQjtBQUFBLFVBQzFDQyxtQkFBbUJQLElBQUlPLHFCQUFxQjtBQUFBLFVBQzVDQyxzQkFBc0JSLElBQUlRLHdCQUF3QjtBQUFBLFFBQ3BEO0FBQUEsTUFDRjtBQUVBekMsa0JBQVksQ0FBQzZCLFNBQVMsQ0FBQyxHQUFHQSxNQUFNTSxZQUFZLENBQUM7QUFDN0NqQixnQ0FBMEJpQixhQUFhRSxVQUFVO0FBQUEsSUFDbkQsU0FBU0ssS0FBSztBQUNaLFlBQU1DLFVBQVVELGVBQWV2RCxvQkFBb0J1RCxJQUFJQyxVQUFVO0FBQ2pFM0M7QUFBQUEsUUFBWSxDQUFDNkIsU0FBUztBQUFBLFVBQ3BCLEdBQUdBO0FBQUFBLFVBQ0g7QUFBQSxZQUNFNUIsSUFBSSxPQUFPSSxLQUFLdUIsSUFBSSxDQUFDO0FBQUEsWUFDckIxQixNQUFNO0FBQUEsWUFDTkMsU0FBUyx1Q0FBdUN3QyxPQUFPO0FBQUEsWUFDdkR2QyxZQUFXLG9CQUFJQyxLQUFLLEdBQUVDLG1CQUFtQjtBQUFBLFVBQzNDO0FBQUEsUUFBQztBQUFBLE1BQ0Y7QUFBQSxJQUNILFVBQUM7QUFDQ0ksbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU1rQyxnQkFBZ0I7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQXVEO0FBR3pELFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVDLFNBQVMsUUFBUUMscUJBQXFCLGFBQWFDLEtBQUssUUFBUUMsUUFBUSxzQkFBc0IsR0FHMUc7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVILFNBQVMsUUFBUUksZUFBZSxVQUFVQyxVQUFVLFNBQVMsR0FHaEc7QUFBQSw2QkFBQyxTQUFJLE9BQU87QUFBQSxRQUNWQyxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLGNBQWM7QUFBQSxRQUNkUixTQUFTO0FBQUEsUUFDVFMsWUFBWTtBQUFBLFFBQ1pDLGdCQUFnQjtBQUFBLFFBQ2hCQyxVQUFVO0FBQUEsUUFDVlQsS0FBSztBQUFBLE1BQ1AsR0FDRTtBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFRixTQUFTLFFBQVFTLFlBQVksVUFBVVAsS0FBSyxPQUFPVSxVQUFVLFFBQVFDLE9BQU8sb0JBQW9CLEdBQzVHO0FBQUEsaUNBQUMscUJBQWtCLE1BQU0sSUFBSSxPQUFNLG9CQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLFVBQUssT0FBTyxFQUFFQyxZQUFZLE9BQU9ELE9BQU8sbUJBQW1CLEdBQUcsc0NBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsYUFGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWIsU0FBUyxRQUFRRSxLQUFLLE9BQU8sR0FDekM7QUFBQSxpQ0FBQyxXQUFNLE9BQU8sRUFBRUYsU0FBUyxRQUFRUyxZQUFZLFVBQVVQLEtBQUssT0FBT2EsUUFBUSxXQUFXSCxVQUFVLE9BQU8sR0FDckc7QUFBQSxtQ0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTMUMsV0FBVyxVQUFVLENBQUM4QyxNQUFNN0MsYUFBYTZDLEVBQUVDLE9BQU9DLE9BQU8sS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkY7QUFBQSxZQUMzRix1QkFBQyxTQUFNLE1BQU0sSUFBSSxPQUFNLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsWUFDaEMsdUJBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLGVBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUVBLHVCQUFDLFdBQU0sT0FBTyxFQUFFbEIsU0FBUyxRQUFRUyxZQUFZLFVBQVVQLEtBQUssT0FBT2EsUUFBUSxXQUFXSCxVQUFVLE9BQU8sR0FDckc7QUFBQSxtQ0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTOUMsUUFBUSxVQUFVLENBQUNrRCxNQUFNakQsVUFBVWlELEVBQUVDLE9BQU9DLE9BQU8sS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUNyRix1QkFBQyxZQUFTLE1BQU0sSUFBSSxPQUFNLGFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DO0FBQUEsWUFDbkMsdUJBQUMsVUFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQjtBQUFBLGVBSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUVBLHVCQUFDLFdBQU0sT0FBTyxFQUFFbEIsU0FBUyxRQUFRUyxZQUFZLFVBQVVQLEtBQUssT0FBT2EsUUFBUSxXQUFXSCxVQUFVLE9BQU8sR0FDckc7QUFBQSxtQ0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTNUMsV0FBVyxVQUFVLENBQUNnRCxNQUFNL0MsYUFBYStDLEVBQUVDLE9BQU9DLE9BQU8sS0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkY7QUFBQSxZQUMzRix1QkFBQyxVQUFPLE1BQU0sSUFBSSxPQUFNLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsWUFDakMsdUJBQUMsVUFBSyxnQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBLGVBSHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsV0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVDLE1BQU0sR0FBR0MsV0FBVyxRQUFRZCxTQUFTLFFBQVFOLFNBQVMsUUFBUUksZUFBZSxVQUFVRixLQUFLLE9BQU8sR0FDOUdoRDtBQUFBQSxpQkFBU2dDO0FBQUFBLFVBQUksQ0FBQ21DLFFBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFdBQVU7QUFBQSxjQUNWLE9BQU87QUFBQSxnQkFDTHJCLFNBQVM7QUFBQSxnQkFDVEUsS0FBSztBQUFBLGdCQUNMb0IsV0FBV0QsSUFBSWhFLFNBQVMsU0FBUyxhQUFhO0FBQUEsZ0JBQzlDa0UsVUFBVUYsSUFBSWhFLFNBQVMsU0FBUyxRQUFRO0FBQUEsY0FDMUM7QUFBQSxjQUVDZ0U7QUFBQUEsb0JBQUloRSxTQUFTLFVBQ1osdUJBQUMsU0FBSSxPQUFPO0FBQUEsa0JBQ1ZtRSxPQUFPO0FBQUEsa0JBQ1ByQixRQUFRO0FBQUEsa0JBQ1JzQixjQUFjO0FBQUEsa0JBQ2RsQixZQUFZO0FBQUEsa0JBQ1pQLFNBQVM7QUFBQSxrQkFDVFMsWUFBWTtBQUFBLGtCQUNaQyxnQkFBZ0I7QUFBQSxrQkFDaEJnQixZQUFZO0FBQUEsZ0JBQ2QsR0FDRSxpQ0FBQyxPQUFJLE1BQU0sSUFBSSxPQUFNLFVBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCLEtBVjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFHRix1QkFBQyxTQUFJLE9BQU8sRUFBRTFCLFNBQVMsUUFBUUksZUFBZSxVQUFVRixLQUFLLE1BQU0sR0FDakU7QUFBQSx5Q0FBQyxTQUFJLE9BQU87QUFBQSxvQkFDVkksU0FBUztBQUFBLG9CQUNUbUIsY0FBYztBQUFBLG9CQUNkbEIsWUFBWWMsSUFBSWhFLFNBQVMsU0FBUyw0QkFBNEI7QUFBQSxvQkFDOURzRSxRQUFRTixJQUFJaEUsU0FBUyxTQUFTLFNBQVM7QUFBQSxvQkFDdkN3RCxPQUFPUSxJQUFJaEUsU0FBUyxTQUFTLFlBQVk7QUFBQSxvQkFDekN1RCxVQUFVO0FBQUEsb0JBQ1ZnQixZQUFZO0FBQUEsb0JBQ1pDLFlBQVk7QUFBQSxvQkFDWkMsV0FBV1QsSUFBSWhFLFNBQVMsU0FBUyx3Q0FBd0M7QUFBQSxrQkFDM0UsR0FDR2dFLGNBQUkvRCxXQVhQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxrQkFHQytELElBQUk3QixjQUNILHVCQUFDLFNBQUksT0FBTyxFQUFFUSxTQUFTLFFBQVFFLEtBQUssT0FBT1MsVUFBVSxRQUFRb0IsV0FBVyxNQUFNLEdBQzNFVjtBQUFBQSx3QkFBSTdCLFdBQVdDLGFBQWF1QyxTQUFTLEtBQ3BDLHVCQUFDLFVBQUssV0FBVSxzQkFBcUIsU0FBUyxNQUFNM0QsMEJBQTBCZ0QsSUFBSTdCLFVBQVUsR0FBRyxPQUFPLEVBQUV1QixRQUFRLFVBQVUsR0FDeEg7QUFBQSw2Q0FBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQjtBQUFBLHNCQUFHO0FBQUEsc0JBQUVNLElBQUk3QixXQUFXQyxhQUFhdUM7QUFBQUEsc0JBQU87QUFBQSx5QkFEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVEWCxJQUFJN0IsV0FBV0UsaUJBQWlCc0MsU0FBUyxLQUN4Qyx1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLFNBQVMsTUFBTTNELDBCQUEwQmdELElBQUk3QixVQUFVLEdBQUcsT0FBTyxFQUFFdUIsUUFBUSxVQUFVLEdBQ3RIO0FBQUEsNkNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1CO0FBQUEsc0JBQUc7QUFBQSxzQkFBRU0sSUFBSTdCLFdBQVdFLGlCQUFpQnNDO0FBQUFBLHNCQUFPO0FBQUEseUJBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFRFgsSUFBSTdCLFdBQVdHLGtCQUFrQnFDLFNBQVMsS0FDekMsdUJBQUMsVUFBSyxXQUFVLHVCQUFzQixTQUFTLE1BQU0zRCwwQkFBMEJnRCxJQUFJN0IsVUFBVSxHQUFHLE9BQU8sRUFBRXVCLFFBQVEsVUFBVSxHQUN6SDtBQUFBLDZDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlCO0FBQUEsc0JBQUc7QUFBQSxzQkFBRU0sSUFBSTdCLFdBQVdHLGtCQUFrQnFDO0FBQUFBLHNCQUFPO0FBQUEseUJBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFRFgsSUFBSTdCLFdBQVdJLHFCQUFxQm9DLFNBQVMsS0FDNUMsdUJBQUMsVUFBSyxXQUFVLHFCQUNkO0FBQUEsNkNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1CO0FBQUEsc0JBQUc7QUFBQSxzQkFBRVgsSUFBSTdCLFdBQVdJLHFCQUFxQm9DO0FBQUFBLHNCQUFPO0FBQUEseUJBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQSxrQkFHRix1QkFBQyxVQUFLLE9BQU8sRUFBRXBCLFVBQVUsUUFBUUMsT0FBTyxtQkFBbUJTLFdBQVdELElBQUloRSxTQUFTLFNBQVMsYUFBYSxhQUFhLEdBQ25IZ0UsY0FBSTlELGFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTRDQTtBQUFBLGdCQUVDOEQsSUFBSWhFLFNBQVMsVUFDWix1QkFBQyxTQUFJLE9BQU87QUFBQSxrQkFDVm1FLE9BQU87QUFBQSxrQkFDUHJCLFFBQVE7QUFBQSxrQkFDUnNCLGNBQWM7QUFBQSxrQkFDZGxCLFlBQVk7QUFBQSxrQkFDWlAsU0FBUztBQUFBLGtCQUNUUyxZQUFZO0FBQUEsa0JBQ1pDLGdCQUFnQjtBQUFBLGtCQUNoQmdCLFlBQVk7QUFBQSxrQkFDWkMsUUFBUTtBQUFBLGdCQUNWLEdBQ0UsaUNBQUMsUUFBSyxNQUFNLElBQUksT0FBTSxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0MsS0FYMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBO0FBQUE7QUFBQSxZQW5GR04sSUFBSWpFO0FBQUFBLFlBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNGQTtBQUFBLFFBQ0Q7QUFBQSxRQUVBUSxhQUNDLHVCQUFDLFNBQUksT0FBTyxFQUFFb0MsU0FBUyxRQUFRUyxZQUFZLFVBQVVQLEtBQUssUUFBUVcsT0FBTyxxQkFBcUJELFVBQVUsT0FBTyxHQUM3RztBQUFBLGlDQUFDLFNBQUksT0FBTyxFQUFFWSxPQUFPLFFBQVFyQixRQUFRLFFBQVFzQixjQUFjLFFBQVFsQixZQUFZLDJCQUEyQlAsU0FBUyxRQUFRUyxZQUFZLFVBQVVDLGdCQUFnQixTQUFTLEdBQ3hLLGlDQUFDLFlBQVMsTUFBTSxJQUFJLE9BQU0sUUFBTyxXQUFVLGtCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RCxLQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLCtFQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsYUFKdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHRix1QkFBQyxTQUFJLEtBQUtwQyxrQkFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsV0FwRzNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxR0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFZ0MsU0FBUyxlQUFlTixTQUFTLFFBQVFFLEtBQUssT0FBTytCLFdBQVcsT0FBTyxHQUNsRmxDLHdCQUFjYjtBQUFBQSxRQUFJLENBQUNnRCxRQUFRQyxRQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsU0FBUyxNQUFNekQsV0FBV3dELE1BQU07QUFBQSxZQUNoQyxPQUFPO0FBQUEsY0FDTDNCLFlBQVk7QUFBQSxjQUNab0IsUUFBUTtBQUFBLGNBQ1JGLGNBQWM7QUFBQSxjQUNkbkIsU0FBUztBQUFBLGNBQ1RPLE9BQU87QUFBQSxjQUNQRCxVQUFVO0FBQUEsY0FDVkcsUUFBUTtBQUFBLGNBQ1JjLFlBQVk7QUFBQSxjQUNaTyxZQUFZO0FBQUEsWUFDZDtBQUFBLFlBQ0EsY0FBYyxDQUFDcEIsTUFBT0EsRUFBRXFCLGNBQWNDLE1BQU1DLGNBQWM7QUFBQSxZQUMxRCxjQUFjLENBQUN2QixNQUFPQSxFQUFFcUIsY0FBY0MsTUFBTUMsY0FBYztBQUFBLFlBQXVCO0FBQUE7QUFBQSxjQUU5RUw7QUFBQUE7QUFBQUE7QUFBQUEsVUFoQkVDO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtCQTtBQUFBLE1BQ0QsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU3QixTQUFTLGFBQWFDLFlBQVksNEJBQTRCaUMsV0FBVyxpQ0FBaUN4QyxTQUFTLFFBQVFFLEtBQUssT0FBTyxHQUNuSjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVpQixNQUFNLEVBQUU7QUFBQSxZQUNqQixhQUFZO0FBQUEsWUFDWixPQUFPekQ7QUFBQUEsWUFDUCxVQUFVLENBQUNzRCxNQUFNckQsU0FBU3FELEVBQUVDLE9BQU93QixLQUFLO0FBQUEsWUFDeEMsV0FBVyxDQUFDekIsTUFBTUEsRUFBRTBCLFFBQVEsV0FBV2hFLFdBQVc7QUFBQSxZQUNsRCxVQUFVZDtBQUFBQTtBQUFBQSxVQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9zQjtBQUFBLFFBRXRCLHVCQUFDLFlBQU8sV0FBVSxlQUFjLFNBQVMsTUFBTWMsV0FBVyxHQUFHLFVBQVVkLGFBQWEsQ0FBQ0YsTUFBTW1CLEtBQUssR0FDOUY7QUFBQSxpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFBRztBQUFBLGFBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F0TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdMQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFeUIsU0FBUyxRQUFRTixTQUFTLFFBQVFJLGVBQWUsVUFBVUYsS0FBSyxRQUFRa0IsV0FBVyxPQUFPLEdBQzdIO0FBQUEsNkJBQUMsUUFBRyxPQUFPLEVBQUVSLFVBQVUsUUFBUUUsWUFBWSxPQUFPNkIsUUFBUSxHQUFHM0MsU0FBUyxRQUFRUyxZQUFZLFVBQVVQLEtBQUssTUFBTSxHQUM3RztBQUFBLCtCQUFDLFNBQU0sTUFBTSxJQUFJLE9BQU0sb0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQTtBQUFBLFdBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVVLFVBQVUsUUFBUUMsT0FBTyxxQkFBcUI4QixRQUFRLEVBQUUsR0FBRSwrSEFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQyxDQUFDdkUseUJBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUrQyxNQUFNLEdBQUduQixTQUFTLFFBQVFJLGVBQWUsVUFBVUssWUFBWSxVQUFVQyxnQkFBZ0IsVUFBVUcsT0FBTyxtQkFBbUIrQixXQUFXLFVBQVUxQyxLQUFLLE1BQU0sR0FDeks7QUFBQSwrQkFBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFFBQ25CLHVCQUFDLFVBQUssT0FBTyxFQUFFVSxVQUFVLE9BQU8sR0FBRyxzRkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RztBQUFBLFdBRjNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxJQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFWixTQUFTLFFBQVFJLGVBQWUsVUFBVUYsS0FBSyxPQUFPLEdBR2pFOUI7QUFBQUEsK0JBQXVCd0IscUJBQXFCb0MsU0FBUyxLQUNwRCx1QkFBQyxTQUFJLE9BQU8sRUFBRXpCLFlBQVksMkJBQTJCb0IsUUFBUSxxQ0FBcUNGLGNBQWMsUUFBUW5CLFNBQVMsT0FBTyxHQUN0STtBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFTSxVQUFVLFFBQVFDLE9BQU8sV0FBVzhCLFFBQVEsYUFBYTNDLFNBQVMsUUFBUVMsWUFBWSxVQUFVUCxLQUFLLE1BQU0sR0FDdEg7QUFBQSxtQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUI7QUFBQSxZQUFHO0FBQUEsZUFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0M5Qix1QkFBdUJ3QixxQkFBcUJWO0FBQUFBLFlBQUksQ0FBQ0MsR0FBRzBELE1BQ25ELHVCQUFDLFNBQVksT0FBTyxFQUFFakMsVUFBVSxRQUFRQyxPQUFPLG9CQUFvQk4sWUFBWSx5QkFBeUJELFNBQVMsWUFBWW1CLGNBQWMsT0FBT3FCLGNBQWMsT0FBT25CLFFBQVEsZ0NBQWdDLEdBQUU7QUFBQTtBQUFBLGNBQzdNeEMsRUFBRTREO0FBQUFBLGNBQVM7QUFBQSxjQUFHNUQsRUFBRTdCO0FBQUFBLGlCQURWdUYsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRDtBQUFBLGFBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFJRix1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxPQUFPLEVBQUVqQyxVQUFVLFFBQVFDLE9BQU8sV0FBV2lDLGNBQWMsT0FBTzlDLFNBQVMsUUFBUVMsWUFBWSxVQUFVUCxLQUFLLE1BQU0sR0FDdEg7QUFBQSxtQ0FBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLFlBQUc7QUFBQSxZQUFxQjlCLHVCQUF1QnFCLGFBQWF1QztBQUFBQSxZQUFPO0FBQUEsZUFEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0M1RCx1QkFBdUJxQixhQUFhdUMsV0FBVyxJQUM5Qyx1QkFBQyxVQUFLLE9BQU8sRUFBRXBCLFVBQVUsUUFBUUMsT0FBTyxrQkFBa0IsR0FBRywwREFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUcsSUFFdkd6Qyx1QkFBdUJxQixhQUFhUDtBQUFBQSxZQUFJLENBQUNDLEdBQUcwRCxNQUMxQyx1QkFBQyxTQUFZLE9BQU8sRUFBRXRDLFlBQVksMkJBQTJCb0IsUUFBUSxxQ0FBcUNGLGNBQWMsT0FBT25CLFNBQVMsUUFBUXdDLGNBQWMsT0FBT2xDLFVBQVUsT0FBTyxHQUNwTDtBQUFBLHFDQUFDLFNBQUksT0FBTyxFQUFFWixTQUFTLFFBQVFVLGdCQUFnQixpQkFBaUJvQyxjQUFjLE9BQU9sQyxVQUFVLFFBQVFDLE9BQU8sb0JBQW9CLEdBQ2hJO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHNCQUFzQjFCLFlBQUU0RCxZQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRDtBQUFBLGdCQUNqRCx1QkFBQyxVQUFLO0FBQUE7QUFBQSxtQkFBTzVELEVBQUU2RCxhQUFhLEtBQUtDLFFBQVEsQ0FBQztBQUFBLGtCQUFFO0FBQUEscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsbUJBRi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNDOUQsRUFBRTdCO0FBQUFBLGlCQUxLdUYsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsVUFDRDtBQUFBLGFBZkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFakMsVUFBVSxRQUFRQyxPQUFPLFdBQVdpQyxjQUFjLE9BQU85QyxTQUFTLFFBQVFTLFlBQVksVUFBVVAsS0FBSyxNQUFNLEdBQ3RIO0FBQUEsbUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1CO0FBQUEsWUFBRztBQUFBLFlBQWlCOUIsdUJBQXVCc0IsaUJBQWlCc0M7QUFBQUEsWUFBTztBQUFBLGVBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDNUQsdUJBQXVCc0IsaUJBQWlCc0MsV0FBVyxJQUNsRCx1QkFBQyxVQUFLLE9BQU8sRUFBRXBCLFVBQVUsUUFBUUMsT0FBTyxrQkFBa0IsR0FBRywyRkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0ksSUFFeEl6Qyx1QkFBdUJzQixpQkFBaUJSO0FBQUFBLFlBQUksQ0FBQ2dFLEdBQUdMLE1BQzlDLHVCQUFDLFNBQVksT0FBTyxFQUFFdEMsWUFBWSwwQkFBMEJvQixRQUFRLG9DQUFvQ0YsY0FBYyxPQUFPbkIsU0FBUyxRQUFRd0MsY0FBYyxPQUFPbEMsVUFBVSxPQUFPLEdBQ2xMO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVaLFNBQVMsUUFBUVUsZ0JBQWdCLGlCQUFpQm9DLGNBQWMsT0FBT2xDLFVBQVUsUUFBUUMsT0FBTyxvQkFBb0IsR0FDaEk7QUFBQSx1Q0FBQyxVQUFLO0FBQUE7QUFBQSxrQkFBUWdDLElBQUk7QUFBQSxxQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0I7QUFBQSxnQkFDcEIsdUJBQUMsVUFBSztBQUFBO0FBQUEsbUJBQU9LLEVBQUVGLGFBQWEsS0FBS0MsUUFBUSxDQUFDO0FBQUEsa0JBQUU7QUFBQSxxQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxtQkFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVyQyxVQUFVLFFBQVFDLE9BQU8sb0JBQW9CYixTQUFTLGVBQWVtRCxpQkFBaUIsR0FBR0MsaUJBQWlCLFlBQVkvQyxVQUFVLFNBQVMsR0FDcEo2QyxZQUFFNUYsV0FETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUFF1RixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxVQUNEO0FBQUEsYUFqQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFakMsVUFBVSxRQUFRQyxPQUFPLFdBQVdpQyxjQUFjLE9BQU85QyxTQUFTLFFBQVFTLFlBQVksVUFBVVAsS0FBSyxNQUFNLEdBQ3RIO0FBQUEsbUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUFHO0FBQUEsWUFBd0I5Qix1QkFBdUJ1QixrQkFBa0JxQztBQUFBQSxZQUFPO0FBQUEsZUFEOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0M1RCx1QkFBdUJ1QixrQkFBa0JxQyxXQUFXLElBQ25ELHVCQUFDLFVBQUssT0FBTyxFQUFFcEIsVUFBVSxRQUFRQyxPQUFPLGtCQUFrQixHQUFHLHFEQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRyxJQUVsR3pDLHVCQUF1QnVCLGtCQUFrQlQ7QUFBQUEsWUFBSSxDQUFDbUUsR0FBR1IsTUFDL0MsdUJBQUMsU0FBWSxPQUFPLEVBQUV0QyxZQUFZLDJCQUEyQm9CLFFBQVEscUNBQXFDRixjQUFjLE9BQU9uQixTQUFTLFFBQVF3QyxjQUFjLE9BQU9sQyxVQUFVLE9BQU8sR0FDcEw7QUFBQSxxQ0FBQyxPQUFFLE1BQU15QyxFQUFFQyxLQUFLLFFBQU8sVUFBUyxLQUFJLGNBQWEsT0FBTyxFQUFFekMsT0FBTyxXQUFXMEMsZ0JBQWdCLFFBQVF6QyxZQUFZLE9BQU9kLFNBQVMsU0FBUzhDLGNBQWMsTUFBTSxHQUMxSk87QUFBQUEsa0JBQUVHO0FBQUFBLGdCQUFNO0FBQUEsbUJBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUU1QyxVQUFVLFFBQVFDLE9BQU8sb0JBQW9CLEdBQUl3QyxZQUFFL0YsV0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUU7QUFBQSxpQkFKakV1RixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxVQUNEO0FBQUEsYUFkTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZFQTtBQUFBLFNBNUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErRkE7QUFBQSxPQTdSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK1JBO0FBRUo7QUFBQzdGLEdBdFhZRCxTQUFpQjtBQUFBLFVBQ1ZYLGdCQUFnQjtBQUFBO0FBQUEsS0FEdkJXO0FBQWlCLElBQUEwRztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJlZiIsInVzZUVmZmVjdCIsInVzZU91dGxldENvbnRleHQiLCJBcGlPcGVyYXRpb25zIiwiSHR0cEVycm9yUmVzcG9uc2UiLCJTZW5kIiwiQm90IiwiVXNlciIsIkJyYWluIiwiRGF0YWJhc2UiLCJTZWFyY2giLCJTcGFya2xlcyIsIlNsaWRlcnNIb3Jpem9udGFsIiwiQ2hhdFRhYiIsIl9zIiwiY3JlZHMiLCJtZXNzYWdlcyIsInNldE1lc3NhZ2VzIiwiaWQiLCJyb2xlIiwiY29udGVudCIsInRpbWVzdGFtcCIsIkRhdGUiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJpbnB1dCIsInNldElucHV0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidXNlUmFnIiwic2V0VXNlUmFnIiwidXNlVGF2aWx5Iiwic2V0VXNlVGF2aWx5IiwidXNlTWVtb3J5Iiwic2V0VXNlTWVtb3J5Iiwic2VsZWN0ZWRNZXNzYWdlQ29udGV4dCIsInNldFNlbGVjdGVkTWVzc2FnZUNvbnRleHQiLCJtZXNzYWdlc0VuZFJlZiIsImN1cnJlbnQiLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiaGFuZGxlU2VuZCIsInRleHRUb1NlbmQiLCJxdWVyeSIsInRyaW0iLCJ1c2VyTXNnIiwibm93IiwicHJldiIsImhpc3RvcnlGb3JBcGkiLCJtYXAiLCJtIiwicmVzIiwiY2hhdCIsImFzc2lzdGFudE1zZyIsImFuc3dlciIsInJhZ0NvbnRleHQiLCJtZW1vcmllc1VzZWQiLCJ2ZWN0b3JDaHVua3NVc2VkIiwidGF2aWx5UmVzdWx0c1VzZWQiLCJuZXdNZW1vcmllc0V4dHJhY3RlZCIsImVyciIsIm1lc3NhZ2UiLCJzYW1wbGVQcm9tcHRzIiwiZGlzcGxheSIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJnYXAiLCJoZWlnaHQiLCJmbGV4RGlyZWN0aW9uIiwib3ZlcmZsb3ciLCJwYWRkaW5nIiwiYmFja2dyb3VuZCIsImJvcmRlckJvdHRvbSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhXcmFwIiwiZm9udFNpemUiLCJjb2xvciIsImZvbnRXZWlnaHQiLCJjdXJzb3IiLCJlIiwidGFyZ2V0IiwiY2hlY2tlZCIsImZsZXgiLCJvdmVyZmxvd1kiLCJtc2ciLCJhbGlnblNlbGYiLCJtYXhXaWR0aCIsIndpZHRoIiwiYm9yZGVyUmFkaXVzIiwiZmxleFNocmluayIsImJvcmRlciIsImxpbmVIZWlnaHQiLCJ3aGl0ZVNwYWNlIiwiYm94U2hhZG93IiwibWFyZ2luVG9wIiwibGVuZ3RoIiwib3ZlcmZsb3dYIiwicHJvbXB0IiwiaWR4IiwidHJhbnNpdGlvbiIsImN1cnJlbnRUYXJnZXQiLCJzdHlsZSIsImJvcmRlckNvbG9yIiwiYm9yZGVyVG9wIiwidmFsdWUiLCJrZXkiLCJtYXJnaW4iLCJ0ZXh0QWxpZ24iLCJpIiwibWFyZ2luQm90dG9tIiwiY2F0ZWdvcnkiLCJzaW1pbGFyaXR5IiwidG9GaXhlZCIsImMiLCJXZWJraXRMaW5lQ2xhbXAiLCJXZWJraXRCb3hPcmllbnQiLCJ0IiwidXJsIiwidGV4dERlY29yYXRpb24iLCJ0aXRsZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoYXRUYWIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgTWVzc2FnZSwgQXBpQ3JlZGVudGlhbHMgfSBmcm9tICdAL3R5cGVzJ1xuaW1wb3J0IHsgQXBpT3BlcmF0aW9ucyB9IGZyb20gJ0Avb3BlcmF0aW9ucy9hcGkub3BlcmF0aW9uJ1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAL3V0aWxzL2Vycm9ycydcbmltcG9ydCB7IFNlbmQsIEJvdCwgVXNlciwgQnJhaW4sIERhdGFiYXNlLCBTZWFyY2gsIFNwYXJrbGVzLCBTbGlkZXJzSG9yaXpvbnRhbCwgQ2hlY2tDaXJjbGUyLCBDaGV2cm9uUmlnaHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmV4cG9ydCBjb25zdCBDaGF0VGFiOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBjcmVkcyB9ID0gdXNlT3V0bGV0Q29udGV4dDx7IGNyZWRzOiBBcGlDcmVkZW50aWFscyB9PigpXG4gIGNvbnN0IFttZXNzYWdlcywgc2V0TWVzc2FnZXNdID0gdXNlU3RhdGU8TWVzc2FnZVtdPihbXG4gICAge1xuICAgICAgaWQ6ICd3ZWxjb21lJyxcbiAgICAgIHJvbGU6ICdhc3Npc3RhbnQnLFxuICAgICAgY29udGVudDogYEhlbGxvISBJIGFtIHlvdXIgKipNZW1vcnkgJiBDb250ZXh0IFJBRyBFbmdpbmUqKi5cXG5cXG5JIGNvbWJpbmUgKipTaG9ydC1UZXJtIE1lbW9yeSoqLCAqKkxvbmctVGVybSBWZWN0b3IgTWVtb3J5IChTdXBhYmFzZSkqKiwgKipWZWN0b3IgS25vd2xlZGdlIEJhc2UgKHBndmVjdG9yKSoqLCBhbmQgKipMaXZlIFdlYiBHcm91bmRpbmcgKFRhdmlseSkqKi5cXG5cXG5UcnkgdGVsbGluZyBtZSBzb21ldGhpbmcgYWJvdXQgeW91cnNlbGYgbGlrZTogKlwiTXkgbmFtZSBpcyBTYXJhaCBhbmQgSSBwcmVmZXIgVHlwZVNjcmlwdCBvdmVyIFB5dGhvblwiKiBvciBhc2sgYSBxdWVzdGlvbiFgLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpXG4gICAgfVxuICBdKVxuICBjb25zdCBbaW5wdXQsIHNldElucHV0XSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt1c2VSYWcsIHNldFVzZVJhZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbdXNlVGF2aWx5LCBzZXRVc2VUYXZpbHldID0gdXNlU3RhdGUodHJ1ZSlcbiAgY29uc3QgW3VzZU1lbW9yeSwgc2V0VXNlTWVtb3J5XSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtzZWxlY3RlZE1lc3NhZ2VDb250ZXh0LCBzZXRTZWxlY3RlZE1lc3NhZ2VDb250ZXh0XSA9IHVzZVN0YXRlPE1lc3NhZ2VbJ3JhZ0NvbnRleHQnXSB8IG51bGw+KG51bGwpXG5cbiAgY29uc3QgbWVzc2FnZXNFbmRSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBtZXNzYWdlc0VuZFJlZi5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KVxuICB9LCBbbWVzc2FnZXMsIGlzTG9hZGluZ10pXG5cbiAgY29uc3QgaGFuZGxlU2VuZCA9IGFzeW5jICh0ZXh0VG9TZW5kPzogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgcXVlcnkgPSAodGV4dFRvU2VuZCB8fCBpbnB1dCkudHJpbSgpXG4gICAgaWYgKCFxdWVyeSB8fCBpc0xvYWRpbmcpIHJldHVyblxuXG4gICAgY29uc3QgdXNlck1zZzogTWVzc2FnZSA9IHtcbiAgICAgIGlkOiBgdXNlcl8ke0RhdGUubm93KCl9YCxcbiAgICAgIHJvbGU6ICd1c2VyJyxcbiAgICAgIGNvbnRlbnQ6IHF1ZXJ5LFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpXG4gICAgfVxuXG4gICAgc2V0TWVzc2FnZXMoKHByZXYpID0+IFsuLi5wcmV2LCB1c2VyTXNnXSlcbiAgICBpZiAoIXRleHRUb1NlbmQpIHNldElucHV0KCcnKVxuICAgIHNldElzTG9hZGluZyh0cnVlKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGhpc3RvcnlGb3JBcGkgPSBbLi4ubWVzc2FnZXMsIHVzZXJNc2ddLm1hcCgobSkgPT4gKHtcbiAgICAgICAgcm9sZTogbS5yb2xlLFxuICAgICAgICBjb250ZW50OiBtLmNvbnRlbnRcbiAgICAgIH0pKVxuXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBBcGlPcGVyYXRpb25zLmNoYXQoaGlzdG9yeUZvckFwaSwgeyB1c2VSYWcsIHVzZVRhdmlseSwgdXNlTWVtb3J5LCAuLi5jcmVkcyB9KVxuXG4gICAgICBjb25zdCBhc3Npc3RhbnRNc2c6IE1lc3NhZ2UgPSB7XG4gICAgICAgIGlkOiBgYXNzaXN0YW50XyR7RGF0ZS5ub3coKX1gLFxuICAgICAgICByb2xlOiAnYXNzaXN0YW50JyxcbiAgICAgICAgY29udGVudDogcmVzLmFuc3dlcixcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpLFxuICAgICAgICByYWdDb250ZXh0OiB7XG4gICAgICAgICAgbWVtb3JpZXNVc2VkOiByZXMubWVtb3JpZXNVc2VkIHx8IFtdLFxuICAgICAgICAgIHZlY3RvckNodW5rc1VzZWQ6IHJlcy52ZWN0b3JDaHVua3NVc2VkIHx8IFtdLFxuICAgICAgICAgIHRhdmlseVJlc3VsdHNVc2VkOiByZXMudGF2aWx5UmVzdWx0c1VzZWQgfHwgW10sXG4gICAgICAgICAgbmV3TWVtb3JpZXNFeHRyYWN0ZWQ6IHJlcy5uZXdNZW1vcmllc0V4dHJhY3RlZCB8fCBbXVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHNldE1lc3NhZ2VzKChwcmV2KSA9PiBbLi4ucHJldiwgYXNzaXN0YW50TXNnXSlcbiAgICAgIHNldFNlbGVjdGVkTWVzc2FnZUNvbnRleHQoYXNzaXN0YW50TXNnLnJhZ0NvbnRleHQpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0gZXJyIGluc3RhbmNlb2YgSHR0cEVycm9yUmVzcG9uc2UgPyBlcnIubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ1xuICAgICAgc2V0TWVzc2FnZXMoKHByZXYpID0+IFtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAge1xuICAgICAgICAgIGlkOiBgZXJyXyR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIHJvbGU6ICdhc3Npc3RhbnQnLFxuICAgICAgICAgIGNvbnRlbnQ6IGDimqDvuI8gRXJyb3IgcHJvY2Vzc2luZyBSQUcgY29tcGxldGlvbjogJHttZXNzYWdlfWAsXG4gICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpXG4gICAgICAgIH1cbiAgICAgIF0pXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBzYW1wbGVQcm9tcHRzID0gW1xuICAgIFwiTXkgbmFtZSBpcyBTYXJhaCwgSSBhbSBidWlsZGluZyBhbiBBSSBzdGFydHVwIGluIFNhbiBGcmFuY2lzY28uXCIsXG4gICAgXCJXaGF0IGRvIHlvdSByZW1lbWJlciBhYm91dCBtZSBhbmQgbXkgZ29hbHM/XCIsXG4gICAgXCJTZWFyY2ggVGF2aWx5IGZvciBsYXRlc3QgZGV2ZWxvcG1lbnRzIGluIExMTSBDb250ZXh0IFdpbmRvd3NcIixcbiAgICBcIkV4cGxhaW4gaG93IFJBRyBtZW1vcnkgYXJjaGl0ZWN0dXJlIHdvcmtzIGluIFN1cGFiYXNlXCJcbiAgXVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMzgwcHgnLCBnYXA6ICcyMHB4JywgaGVpZ2h0OiAnY2FsYygxMDB2aCAtIDE0MHB4KScgfX0+XG4gICAgICBcbiAgICAgIHsvKiBNYWluIENoYXQgUGFuZWwgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBvdmVyZmxvdzogJ2hpZGRlbicgfX0+XG4gICAgICAgIFxuICAgICAgICB7LyogQ29udHJvbHMgVG9vbGJhciAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgIHBhZGRpbmc6ICcxMnB4IDIwcHgnLFxuICAgICAgICAgIGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNiknLFxuICAgICAgICAgIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJyxcbiAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyxcbiAgICAgICAgICBmbGV4V3JhcDogJ3dyYXAnLFxuICAgICAgICAgIGdhcDogJzEycHgnXG4gICAgICAgIH19PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JywgZm9udFNpemU6ICcxM3B4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScgfX0+XG4gICAgICAgICAgICA8U2xpZGVyc0hvcml6b250YWwgc2l6ZT17MTZ9IGNvbG9yPVwidmFyKC0tcHJpbWFyeSlcIiAvPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFdlaWdodDogJzYwMCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tYWluKScgfX0+UkFHIFBpcGVsaW5lIENvbnRyb2xzOjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcxMnB4JyB9fT5cbiAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc2cHgnLCBjdXJzb3I6ICdwb2ludGVyJywgZm9udFNpemU6ICcxMnB4JyB9fT5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3VzZU1lbW9yeX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VNZW1vcnkoZS50YXJnZXQuY2hlY2tlZCl9IC8+XG4gICAgICAgICAgICAgIDxCcmFpbiBzaXplPXsxNH0gY29sb3I9XCIjYTViNGZjXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+TWVtb3J5IFJlY2FsbDwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc2cHgnLCBjdXJzb3I6ICdwb2ludGVyJywgZm9udFNpemU6ICcxMnB4JyB9fT5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3VzZVJhZ30gb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VSYWcoZS50YXJnZXQuY2hlY2tlZCl9IC8+XG4gICAgICAgICAgICAgIDxEYXRhYmFzZSBzaXplPXsxNH0gY29sb3I9XCIjNjdlOGY5XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+cGd2ZWN0b3IgUkFHPC9zcGFuPlxuICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzZweCcsIGN1cnNvcjogJ3BvaW50ZXInLCBmb250U2l6ZTogJzEycHgnIH19PlxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17dXNlVGF2aWx5fSBvbkNoYW5nZT17KGUpID0+IHNldFVzZVRhdmlseShlLnRhcmdldC5jaGVja2VkKX0gLz5cbiAgICAgICAgICAgICAgPFNlYXJjaCBzaXplPXsxNH0gY29sb3I9XCIjNmVlN2I3XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+VGF2aWx5IEdyb3VuZGluZzwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXNzYWdlIEZlZWQgKi99XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgb3ZlcmZsb3dZOiAnYXV0bycsIHBhZGRpbmc6ICcyMHB4JywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgICAge21lc3NhZ2VzLm1hcCgobXNnKSA9PiAoXG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGtleT17bXNnLmlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhbmltYXRlLWZhZGUtaW5cIlxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAgICBnYXA6ICcxMnB4JyxcbiAgICAgICAgICAgICAgICBhbGlnblNlbGY6IG1zZy5yb2xlID09PSAndXNlcicgPyAnZmxleC1lbmQnIDogJ2ZsZXgtc3RhcnQnLFxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiBtc2cucm9sZSA9PT0gJ3VzZXInID8gJzgwJScgOiAnOTAlJ1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7bXNnLnJvbGUgIT09ICd1c2VyJyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgd2lkdGg6ICczNnB4JyxcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAndmFyKC0tcHJpbWFyeS1ncmFkaWVudCknLFxuICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgICAgICAgICAgICAgICBmbGV4U2hyaW5rOiAwXG4gICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICA8Qm90IHNpemU9ezIwfSBjb2xvcj1cIiNmZmZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMTRweCAxOHB4JyxcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzE0cHgnLFxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbXNnLnJvbGUgPT09ICd1c2VyJyA/ICd2YXIoLS1wcmltYXJ5LWdyYWRpZW50KScgOiAndmFyKC0tYmctY2FyZCknLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBtc2cucm9sZSA9PT0gJ3VzZXInID8gJ25vbmUnIDogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJyxcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBtc2cucm9sZSA9PT0gJ3VzZXInID8gJyNmZmZmZmYnIDogJ3ZhcigtLXRleHQtbWFpbiknLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxNHB4JyxcbiAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6ICcxLjYnLFxuICAgICAgICAgICAgICAgICAgd2hpdGVTcGFjZTogJ3ByZS13cmFwJyxcbiAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogbXNnLnJvbGUgPT09ICd1c2VyJyA/ICcwIDRweCAxNXB4IHJnYmEoOTksIDEwMiwgMjQxLCAwLjI1KScgOiAndmFyKC0tc2hhZG93LWNhcmQpJ1xuICAgICAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICAgICAge21zZy5jb250ZW50fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIENvbnRleHQgQmFkZ2VzIG9uIEFzc2lzdGFudCBNZXNzYWdlcyAqL31cbiAgICAgICAgICAgICAgICB7bXNnLnJhZ0NvbnRleHQgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzZweCcsIGZsZXhXcmFwOiAnd3JhcCcsIG1hcmdpblRvcDogJzRweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIHttc2cucmFnQ29udGV4dC5tZW1vcmllc1VzZWQubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYmFkZ2UtaW5kaWdvXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRNZXNzYWdlQ29udGV4dChtc2cucmFnQ29udGV4dCl9IHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJyYWluIHNpemU9ezEwfSAvPiB7bXNnLnJhZ0NvbnRleHQubWVtb3JpZXNVc2VkLmxlbmd0aH0gTWVtb3JpZXMgUmVjYWxsZWRcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIHttc2cucmFnQ29udGV4dC52ZWN0b3JDaHVua3NVc2VkLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJhZGdlLWN5YW5cIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZE1lc3NhZ2VDb250ZXh0KG1zZy5yYWdDb250ZXh0KX0gc3R5bGU9e3sgY3Vyc29yOiAncG9pbnRlcicgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RGF0YWJhc2Ugc2l6ZT17MTB9IC8+IHttc2cucmFnQ29udGV4dC52ZWN0b3JDaHVua3NVc2VkLmxlbmd0aH0gVmVjdG9yIENodW5rc1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge21zZy5yYWdDb250ZXh0LnRhdmlseVJlc3VsdHNVc2VkLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJhZGdlLWVtZXJhbGRcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZE1lc3NhZ2VDb250ZXh0KG1zZy5yYWdDb250ZXh0KX0gc3R5bGU9e3sgY3Vyc29yOiAncG9pbnRlcicgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VhcmNoIHNpemU9ezEwfSAvPiB7bXNnLnJhZ0NvbnRleHQudGF2aWx5UmVzdWx0c1VzZWQubGVuZ3RofSBXZWIgU291cmNlc1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge21zZy5yYWdDb250ZXh0Lm5ld01lbW9yaWVzRXh0cmFjdGVkLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJhZGdlIGJhZGdlLWFtYmVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTB9IC8+IHttc2cucmFnQ29udGV4dC5uZXdNZW1vcmllc0V4dHJhY3RlZC5sZW5ndGh9IE5ldyBNZW1vcnkgRXh0cmFjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMTBweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1kaW0pJywgYWxpZ25TZWxmOiBtc2cucm9sZSA9PT0gJ3VzZXInID8gJ2ZsZXgtZW5kJyA6ICdmbGV4LXN0YXJ0JyB9fT5cbiAgICAgICAgICAgICAgICAgIHttc2cudGltZXN0YW1wfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge21zZy5yb2xlID09PSAndXNlcicgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiAnMzZweCcsXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6ICczNnB4JyxcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzEwcHgnLFxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4xKScsXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICAgICAgICAgICAgICAgIGZsZXhTaHJpbms6IDAsXG4gICAgICAgICAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKSdcbiAgICAgICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAgICAgIDxVc2VyIHNpemU9ezIwfSBjb2xvcj1cInZhcigtLXRleHQtbWFpbilcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG5cbiAgICAgICAgICB7aXNMb2FkaW5nICYmIChcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnMTJweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tdXRlZCknLCBmb250U2l6ZTogJzEzcHgnIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiAnMzZweCcsIGhlaWdodDogJzM2cHgnLCBib3JkZXJSYWRpdXM6ICcxMHB4JywgYmFja2dyb3VuZDogJ3ZhcigtLXByaW1hcnktZ3JhZGllbnQpJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsyMH0gY29sb3I9XCIjZmZmXCIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxzcGFuPlNlYXJjaGluZyBTdXBhYmFzZSBwZ3ZlY3RvciArIFRhdmlseSAmIFN5bnRoZXNpemluZyByZXNwb25zZS4uLjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IHJlZj17bWVzc2FnZXNFbmRSZWZ9IC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTYW1wbGUgUHJvbXB0cyAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMCAyMHB4IDEwcHgnLCBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzhweCcsIG92ZXJmbG93WDogJ2F1dG8nIH19PlxuICAgICAgICAgIHtzYW1wbGVQcm9tcHRzLm1hcCgocHJvbXB0LCBpZHgpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbmQocHJvbXB0KX1cbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjAzKScsXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWJvcmRlci1jb2xvciknLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzIwcHgnLFxuICAgICAgICAgICAgICAgIHBhZGRpbmc6ICc2cHggMTJweCcsXG4gICAgICAgICAgICAgICAgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScsXG4gICAgICAgICAgICAgICAgZm9udFNpemU6ICcxMXB4JyxcbiAgICAgICAgICAgICAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAgICAgICAgICAgICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiAnYWxsIDAuMnMnXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17KGUpID0+IChlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYm9yZGVyQ29sb3IgPSAndmFyKC0tcHJpbWFyeSknKX1cbiAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXsoZSkgPT4gKGUuY3VycmVudFRhcmdldC5zdHlsZS5ib3JkZXJDb2xvciA9ICd2YXIoLS1ib3JkZXItY29sb3IpJyl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIOKaoSB7cHJvbXB0fVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBJbnB1dCBCYXIgKi99XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzE2cHggMjBweCcsIGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNiknLCBib3JkZXJUb3A6ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKScsIGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnMTJweCcgfX0+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1pbnB1dFwiXG4gICAgICAgICAgICBzdHlsZT17eyBmbGV4OiAxIH19XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlR5cGUgeW91ciBtZXNzYWdlIG9yIHRlbGwgbWUgYSBwcmVmZXJlbmNlIChlLmcuICdJIHByZWZlciBQb3N0Z3JlU1FMIGFuZCBab2QnKS4uLlwiXG4gICAgICAgICAgICB2YWx1ZT17aW5wdXR9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSAnRW50ZXInICYmIGhhbmRsZVNlbmQoKX1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4gaGFuZGxlU2VuZCgpfSBkaXNhYmxlZD17aXNMb2FkaW5nIHx8ICFpbnB1dC50cmltKCl9PlxuICAgICAgICAgICAgPFNlbmQgc2l6ZT17MTZ9IC8+IFNlbmRcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU2lkZSBSQUcgJiBNZW1vcnkgQ29udGV4dCBJbnNwZWN0b3IgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAnMjBweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzE2cHgnLCBvdmVyZmxvd1k6ICdhdXRvJyB9fT5cbiAgICAgICAgPGgzIHN0eWxlPXt7IGZvbnRTaXplOiAnMTZweCcsIGZvbnRXZWlnaHQ6ICc3MDAnLCBtYXJnaW46IDAsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XG4gICAgICAgICAgPEJyYWluIHNpemU9ezE4fSBjb2xvcj1cInZhcigtLXByaW1hcnkpXCIgLz5cbiAgICAgICAgICBSQUcgQ29udGV4dCBJbnNwZWN0b3JcbiAgICAgICAgPC9oMz5cbiAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxMnB4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScsIG1hcmdpbjogMCB9fT5cbiAgICAgICAgICBSZWFsLXRpbWUgdmlldyBvZiByZXRyaWV2ZWQgU3VwYWJhc2UgdmVjdG9yIGNodW5rcywgYWN0aXZlIG1lbW9yaWVzLCBhbmQgVGF2aWx5IHdlYiByZXN1bHRzIHVzZWQgZm9yIHN5bnRoZXNpcy5cbiAgICAgICAgPC9wPlxuXG4gICAgICAgIHshc2VsZWN0ZWRNZXNzYWdlQ29udGV4dCA/IChcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6IDEsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGNvbG9yOiAndmFyKC0tdGV4dC1kaW0pJywgdGV4dEFsaWduOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXszMn0gLz5cbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMTNweCcgfX0+U2VuZCBhIG1lc3NhZ2UgdG8gaW5zcGVjdCBSQUcgZ3JvdW5kaW5nIGFuZCBtZW1vcnkgZXh0cmFjdGlvbiBjb250ZXh0Ljwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzE2cHgnIH19PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogRXh0cmFjdGVkIE1lbW9yaWVzICovfVxuICAgICAgICAgICAge3NlbGVjdGVkTWVzc2FnZUNvbnRleHQubmV3TWVtb3JpZXNFeHRyYWN0ZWQubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMjQ1LCAxNTgsIDExLCAwLjEpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHJnYmEoMjQ1LCAxNTgsIDExLCAwLjMpJywgYm9yZGVyUmFkaXVzOiAnMTBweCcsIHBhZGRpbmc6ICcxMnB4JyB9fT5cbiAgICAgICAgICAgICAgICA8aDQgc3R5bGU9e3sgZm9udFNpemU6ICcxMnB4JywgY29sb3I6ICcjZmNkMzRkJywgbWFyZ2luOiAnMCAwIDhweCAwJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxNH0gLz4gTWVtb3J5IEV4dHJhY3RlZCAoWm9kIFBhcnNlZClcbiAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZE1lc3NhZ2VDb250ZXh0Lm5ld01lbW9yaWVzRXh0cmFjdGVkLm1hcCgobSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IHN0eWxlPXt7IGZvbnRTaXplOiAnMTJweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tYWluKScsIGJhY2tncm91bmQ6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuOCknLCBwYWRkaW5nOiAnNnB4IDEwcHgnLCBib3JkZXJSYWRpdXM6ICc2cHgnLCBtYXJnaW5Cb3R0b206ICc0cHgnLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKScgfX0+XG4gICAgICAgICAgICAgICAgICAgIFt7bS5jYXRlZ29yeX1dIHttLmNvbnRlbnR9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogUmVjYWxsZWQgTG9uZy1UZXJtIE1lbW9yaWVzICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGg0IHN0eWxlPXt7IGZvbnRTaXplOiAnMTNweCcsIGNvbG9yOiAnI2E1YjRmYycsIG1hcmdpbkJvdHRvbTogJzhweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzZweCcgfX0+XG4gICAgICAgICAgICAgICAgPEJyYWluIHNpemU9ezE0fSAvPiBSZWNhbGxlZCBNZW1vcmllcyAoe3NlbGVjdGVkTWVzc2FnZUNvbnRleHQubWVtb3JpZXNVc2VkLmxlbmd0aH0pXG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgIHtzZWxlY3RlZE1lc3NhZ2VDb250ZXh0Lm1lbW9yaWVzVXNlZC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICd2YXIoLS10ZXh0LWRpbSknIH19Pk5vIHByaW9yIG1lbW9yaWVzIG1hdGNoZWQgcXVlcnkgZW1iZWRkaW5nLjwvc3Bhbj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1lc3NhZ2VDb250ZXh0Lm1lbW9yaWVzVXNlZC5tYXAoKG0sIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSg5OSwgMTAyLCAyNDEsIDAuMSknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSg5OSwgMTAyLCAyNDEsIDAuMiknLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBwYWRkaW5nOiAnMTBweCcsIG1hcmdpbkJvdHRvbTogJzZweCcsIGZvbnRTaXplOiAnMTJweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBtYXJnaW5Cb3R0b206ICc0cHgnLCBmb250U2l6ZTogJzEwcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiYWRnZS1pbmRpZ29cIj57bS5jYXRlZ29yeX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2ltOiB7KG0uc2ltaWxhcml0eSAqIDEwMCkudG9GaXhlZCgxKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge20uY29udGVudH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFZlY3RvciBEQiBDaHVua3MgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDQgc3R5bGU9e3sgZm9udFNpemU6ICcxM3B4JywgY29sb3I6ICcjNjdlOGY5JywgbWFyZ2luQm90dG9tOiAnOHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICA8RGF0YWJhc2Ugc2l6ZT17MTR9IC8+IFZlY3RvciBDaHVua3MgKHtzZWxlY3RlZE1lc3NhZ2VDb250ZXh0LnZlY3RvckNodW5rc1VzZWQubGVuZ3RofSlcbiAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAge3NlbGVjdGVkTWVzc2FnZUNvbnRleHQudmVjdG9yQ2h1bmtzVXNlZC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICd2YXIoLS10ZXh0LWRpbSknIH19Pk5vIGRvY3VtZW50IHZlY3RvciBjaHVua3MgcmV0cmlldmVkLiBJbmdlc3QgVVJMcyB2aWEgRmlyZWNyYXdsIHRvIHBvcHVsYXRlITwvc3Bhbj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1lc3NhZ2VDb250ZXh0LnZlY3RvckNodW5rc1VzZWQubWFwKChjLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoNiwgMTgyLCAyMTIsIDAuMSknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSg2LCAxODIsIDIxMiwgMC4yKScsIGJvcmRlclJhZGl1czogJzhweCcsIHBhZGRpbmc6ICcxMHB4JywgbWFyZ2luQm90dG9tOiAnNnB4JywgZm9udFNpemU6ICcxMnB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIG1hcmdpbkJvdHRvbTogJzRweCcsIGZvbnRTaXplOiAnMTBweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tdXRlZCknIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNodW5rICN7aSArIDF9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNpbTogeyhjLnNpbWlsYXJpdHkgKiAxMDApLnRvRml4ZWQoMSl9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICd2YXIoLS10ZXh0LW1haW4pJywgZGlzcGxheTogJy13ZWJraXQtYm94JywgV2Via2l0TGluZUNsYW1wOiAzLCBXZWJraXRCb3hPcmllbnQ6ICd2ZXJ0aWNhbCcsIG92ZXJmbG93OiAnaGlkZGVuJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7Yy5jb250ZW50fVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFRhdmlseSBXZWIgUmVzdWx0cyAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoNCBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJyM2ZWU3YjcnLCBtYXJnaW5Cb3R0b206ICc4cHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc2cHgnIH19PlxuICAgICAgICAgICAgICAgIDxTZWFyY2ggc2l6ZT17MTR9IC8+IFRhdmlseSBXZWIgR3JvdW5kaW5nICh7c2VsZWN0ZWRNZXNzYWdlQ29udGV4dC50YXZpbHlSZXN1bHRzVXNlZC5sZW5ndGh9KVxuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICB7c2VsZWN0ZWRNZXNzYWdlQ29udGV4dC50YXZpbHlSZXN1bHRzVXNlZC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICd2YXIoLS10ZXh0LWRpbSknIH19PlRhdmlseSBzZWFyY2ggZGlzYWJsZWQgb3Igbm8gcmVzdWx0cy48L3NwYW4+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNZXNzYWdlQ29udGV4dC50YXZpbHlSZXN1bHRzVXNlZC5tYXAoKHQsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBzdHlsZT17eyBiYWNrZ3JvdW5kOiAncmdiYSgxNiwgMTg1LCAxMjksIDAuMSknLCBib3JkZXI6ICcxcHggc29saWQgcmdiYSgxNiwgMTg1LCAxMjksIDAuMiknLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBwYWRkaW5nOiAnMTBweCcsIG1hcmdpbkJvdHRvbTogJzZweCcsIGZvbnRTaXplOiAnMTJweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e3QudXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyXCIgc3R5bGU9e3sgY29sb3I6ICcjNmVlN2I3JywgdGV4dERlY29yYXRpb246ICdub25lJywgZm9udFdlaWdodDogJzYwMCcsIGRpc3BsYXk6ICdibG9jaycsIG1hcmdpbkJvdHRvbTogJzRweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAge3QudGl0bGV9IOKGl1xuICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcxMXB4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScgfX0+e3QuY29udGVudH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICA8L2Rpdj5cblxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6IkM6L25vZGUvbGxtL2NsaWVudC9zcmMvdmlld3MvQ2hhdFRhYi50c3gifQ==