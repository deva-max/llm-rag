import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/MemoriesTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/MemoriesTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=90a7bf15";
import { ApiOperations } from "/src/operations/api.operation.ts";
import { HttpErrorResponse } from "/src/utils/errors.ts";
import { Brain, Plus, Trash2, Sparkles, Filter } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
import { TOAST_MESSAGES } from "/src/config/messages/toast.messages.ts";
export const MemoriesTab = () => {
  _s();
  const { creds } = useOutletContext();
  const [memories, setMemories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isLoading, setIsLoading] = useState(false);
  const [newContent, setNewContent] = useState("");
  const [newCategory, setNewCategory] = useState("preference");
  const [statusMsg, setStatusMsg] = useState(null);
  const loadMemories = async () => {
    setIsLoading(true);
    try {
      const data = await ApiOperations.fetchMemories();
      setMemories(data.memories);
    } catch (err) {
      console.warn("Failed to load memories:", err);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    loadMemories();
  }, []);
  const handleAddMemory = async (e) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    try {
      await ApiOperations.addMemory(newContent, newCategory, 1, "manual");
      setNewContent("");
      setStatusMsg({ type: "success", text: TOAST_MESSAGES.SUCCESS.MEMORY_SAVED });
      setTimeout(() => setStatusMsg(null), 4e3);
      loadMemories();
    } catch (err) {
      const message = err instanceof HttpErrorResponse ? err.message : "Unknown error";
      setStatusMsg({ type: "error", text: `${TOAST_MESSAGES.ERROR.MEMORY_ACTION_FAILED} ${message}` });
      setTimeout(() => setStatusMsg(null), 4e3);
    }
  };
  const handleDelete = async (id) => {
    try {
      await ApiOperations.deleteMemory(id);
      setMemories((prev) => prev.filter((m) => m.id !== id));
      setStatusMsg({ type: "success", text: TOAST_MESSAGES.SUCCESS.MEMORY_DELETED });
      setTimeout(() => setStatusMsg(null), 4e3);
    } catch (err) {
      const message = err instanceof HttpErrorResponse ? err.message : "Unknown error";
      setStatusMsg({ type: "error", text: `${TOAST_MESSAGES.ERROR.MEMORY_ACTION_FAILED} ${message}` });
      setTimeout(() => setStatusMsg(null), 4e3);
    }
  };
  const filteredMemories = memories.filter(
    (m) => selectedCategory === "all" ? true : m.category === selectedCategory
  );
  const categoryBadge = (cat) => {
    switch (cat) {
      case "preference":
        return "badge-indigo";
      case "fact":
        return "badge-cyan";
      case "goal":
        return "badge-amber";
      case "entity":
        return "badge-emerald";
      default:
        return "badge-indigo";
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1200px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "24px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "20px", fontWeight: "700", margin: "0 0 6px 0", display: "flex", alignItems: "center", gap: "10px" }, children: [
          /* @__PURE__ */ jsxDEV(Brain, { color: "#a5b4fc" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 104,
            columnNumber: 13
          }, this),
          "Supabase Long-Term Memory Explorer"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "13px", color: "var(--text-muted)", margin: 0 }, children: "Inspect facts, preferences, and entity memories extracted automatically via Zod or added manually. Stored in Supabase `memories` table with vector cosine indexing." }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 107,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", onClick: loadMemories, children: [
        /* @__PURE__ */ jsxDEV(Sparkles, { size: 16 }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        " Refresh Memories (",
        memories.length,
        ")"
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 380px", gap: "24px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "12px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "8px", fontSize: "13px", color: "var(--text-muted)" }, children: [
            /* @__PURE__ */ jsxDEV(Filter, { size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 125,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Filter Category:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 126,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 124,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "6px" }, children: ["all", "preference", "fact", "goal", "entity", "general"].map(
            (cat) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedCategory(cat),
                style: {
                  background: selectedCategory === cat ? "rgba(99, 102, 241, 0.2)" : "transparent",
                  border: selectedCategory === cat ? "1px solid rgba(99, 102, 241, 0.4)" : "1px solid transparent",
                  color: selectedCategory === cat ? "#a5b4fc" : "var(--text-muted)",
                  borderRadius: "6px",
                  padding: "4px 10px",
                  fontSize: "12px",
                  cursor: "pointer",
                  textTransform: "capitalize"
                },
                children: cat
              },
              cat,
              false,
              {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 131,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 129,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { style: { padding: "40px", textTransform: "uppercase", textAlign: "center", color: "var(--text-dim)", fontSize: "13px" }, children: "Loading memories from Supabase..." }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 152,
          columnNumber: 11
        }, this) : filteredMemories.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "40px", textAlign: "center", color: "var(--text-dim)", fontSize: "13px" }, children: [
          'No memories found in category "',
          selectedCategory,
          '". Start chatting or add one manually!'
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 156,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px" }, children: filteredMemories.map(
          (mem) => /* @__PURE__ */ jsxDEV("div", { className: "glass-card animate-fade-in", style: { padding: "16px", display: "flex", flexDirection: "column", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }, children: [
                /* @__PURE__ */ jsxDEV("span", { className: `badge ${categoryBadge(mem.category)}`, children: mem.category }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                  lineNumber: 165,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleDelete(mem.id),
                    style: { background: "none", border: "none", color: "#fca5a5", cursor: "pointer", opacity: 0.7 },
                    title: "Delete Memory",
                    children: /* @__PURE__ */ jsxDEV(Trash2, { size: 14 }, void 0, false, {
                      fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                      lineNumber: 171,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                    lineNumber: 166,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 164,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "13px", lineHeight: "1.5", margin: "0 0 10px 0", color: "var(--text-main)" }, children: mem.content }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 175,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 163,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", fontSize: "10px", color: "var(--text-dim)", borderTop: "1px solid var(--border-color)", paddingTop: "8px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Source: ",
                mem.source
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 181,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Confidence: ",
                (mem.confidence * 100).toFixed(0),
                "%"
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 182,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 180,
              columnNumber: 19
            }, this)
          ] }, mem.id, true, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 162,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 160,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "16px", fontWeight: "700", margin: 0, display: "flex", alignItems: "center", gap: "8px" }, children: [
          /* @__PURE__ */ jsxDEV(Plus, { size: 18, color: "var(--primary)" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 194,
            columnNumber: 13
          }, this),
          "Add Manual Memory"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 193,
          columnNumber: 11
        }, this),
        statusMsg && /* @__PURE__ */ jsxDEV("div", { style: {
          padding: "10px 14px",
          borderRadius: "8px",
          background: statusMsg.type === "success" ? "rgba(16, 185, 129, 0.15)" : "rgba(239, 68, 68, 0.15)",
          border: statusMsg.type === "success" ? "1px solid rgba(16, 185, 129, 0.3)" : "1px solid rgba(239, 68, 68, 0.3)",
          color: statusMsg.type === "success" ? "#6ee7b7" : "#fca5a5",
          fontSize: "12px"
        }, children: statusMsg.text }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 199,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleAddMemory, style: { display: "flex", flexDirection: "column", gap: "14px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "12px", fontWeight: "600", marginBottom: "6px" }, children: "Memory Category:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 213,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "glass-input",
                style: { width: "100%" },
                value: newCategory,
                onChange: (e) => setNewCategory(e.target.value),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "preference", children: "Preference (e.g. Likes TypeScript)" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                    lineNumber: 222,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "fact", children: "Fact (e.g. User lives in NY)" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                    lineNumber: 223,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "goal", children: "Goal (e.g. Building RAG app)" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                    lineNumber: 224,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "entity", children: "Entity (e.g. Project Name)" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                    lineNumber: 225,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "general", children: "General" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                    lineNumber: 226,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 216,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 212,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "12px", fontWeight: "600", marginBottom: "6px" }, children: "Memory Content:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 231,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                className: "glass-input",
                style: { width: "100%", minHeight: "100px", resize: "vertical" },
                placeholder: "e.g. User is building a full-stack RAG app using Supabase pgvector.",
                value: newContent,
                onChange: (e) => setNewContent(e.target.value),
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
                lineNumber: 234,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 230,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "submit", children: [
            /* @__PURE__ */ jsxDEV(Brain, { size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
              lineNumber: 245,
              columnNumber: 15
            }, this),
            " Save Memory to Vector Store"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
            lineNumber: 244,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
          lineNumber: 211,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
        lineNumber: 192,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/MemoriesTab.tsx",
    lineNumber: 98,
    columnNumber: 5
  }, this);
};
_s(MemoriesTab, "njwDHLZ+c5YWxcw/zKucumpU/dk=", false, function() {
  return [useOutletContext];
});
_c = MemoriesTab;
var _c;
$RefreshReg$(_c, "MemoriesTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/MemoriesTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/MemoriesTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBGWixTQUFnQkEsVUFBVUMsaUJBQWlCO0FBQzNDLFNBQVNDLHdCQUF3QjtBQUVqQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLE9BQU9DLE1BQU1DLFFBQVFDLFVBQVVDLGNBQXlDO0FBQ2pGLFNBQVNDLHNCQUFzQjtBQUV4QixhQUFNQyxjQUF3QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pDLFFBQU0sRUFBRUMsTUFBTSxJQUFJWCxpQkFBNEM7QUFDOUQsUUFBTSxDQUFDWSxVQUFVQyxXQUFXLElBQUlmLFNBQXlCLEVBQUU7QUFDM0QsUUFBTSxDQUFDZ0Isa0JBQWtCQyxtQkFBbUIsSUFBSWpCLFNBQWlCLEtBQUs7QUFDdEUsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJbkIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ29CLFlBQVlDLGFBQWEsSUFBSXJCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNzQixhQUFhQyxjQUFjLElBQUl2QixTQUFjLFlBQVk7QUFDaEUsUUFBTSxDQUFDd0IsV0FBV0MsWUFBWSxJQUFJekIsU0FBNkQsSUFBSTtBQUVuRyxRQUFNMEIsZUFBZSxZQUFZO0FBQy9CUCxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNUSxPQUFPLE1BQU14QixjQUFjeUIsY0FBYztBQUMvQ2Isa0JBQVlZLEtBQUtiLFFBQVE7QUFBQSxJQUMzQixTQUFTZSxLQUFLO0FBQ1pDLGNBQVFDLEtBQUssNEJBQTRCRixHQUFHO0FBQUEsSUFDOUMsVUFBQztBQUNDVixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUFsQixZQUFVLE1BQU07QUFDZHlCLGlCQUFhO0FBQUEsRUFDZixHQUFHLEVBQUU7QUFFTCxRQUFNTSxrQkFBa0IsT0FBT0MsTUFBdUI7QUFDcERBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDZCxXQUFXZSxLQUFLLEVBQUc7QUFFeEIsUUFBSTtBQUNGLFlBQU1oQyxjQUFjaUMsVUFBVWhCLFlBQVlFLGFBQWEsR0FBSyxRQUFRO0FBQ3BFRCxvQkFBYyxFQUFFO0FBQ2hCSSxtQkFBYSxFQUFFWSxNQUFNLFdBQVdDLE1BQU01QixlQUFlNkIsUUFBUUMsYUFBYSxDQUFDO0FBQzNFQyxpQkFBVyxNQUFNaEIsYUFBYSxJQUFJLEdBQUcsR0FBSTtBQUN6Q0MsbUJBQWE7QUFBQSxJQUNmLFNBQVNHLEtBQUs7QUFDWixZQUFNYSxVQUFVYixlQUFlekIsb0JBQW9CeUIsSUFBSWEsVUFBVTtBQUNqRWpCLG1CQUFhLEVBQUVZLE1BQU0sU0FBU0MsTUFBTSxHQUFHNUIsZUFBZWlDLE1BQU1DLG9CQUFvQixJQUFJRixPQUFPLEdBQUcsQ0FBQztBQUMvRkQsaUJBQVcsTUFBTWhCLGFBQWEsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFFQSxRQUFNb0IsZUFBZSxPQUFPQyxPQUFlO0FBQ3pDLFFBQUk7QUFDRixZQUFNM0MsY0FBYzRDLGFBQWFELEVBQUU7QUFDbkMvQixrQkFBWSxDQUFDaUMsU0FBU0EsS0FBS0MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFSixPQUFPQSxFQUFFLENBQUM7QUFDckRyQixtQkFBYSxFQUFFWSxNQUFNLFdBQVdDLE1BQU01QixlQUFlNkIsUUFBUVksZUFBZSxDQUFDO0FBQzdFVixpQkFBVyxNQUFNaEIsYUFBYSxJQUFJLEdBQUcsR0FBSTtBQUFBLElBQzNDLFNBQVNJLEtBQUs7QUFDWixZQUFNYSxVQUFVYixlQUFlekIsb0JBQW9CeUIsSUFBSWEsVUFBVTtBQUNqRWpCLG1CQUFhLEVBQUVZLE1BQU0sU0FBU0MsTUFBTSxHQUFHNUIsZUFBZWlDLE1BQU1DLG9CQUFvQixJQUFJRixPQUFPLEdBQUcsQ0FBQztBQUMvRkQsaUJBQVcsTUFBTWhCLGFBQWEsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFFQSxRQUFNMkIsbUJBQW1CdEMsU0FBU21DO0FBQUFBLElBQU8sQ0FBQ0MsTUFDeENsQyxxQkFBcUIsUUFBUSxPQUFPa0MsRUFBRUcsYUFBYXJDO0FBQUFBLEVBQ3JEO0FBRUEsUUFBTXNDLGdCQUFnQkEsQ0FBQ0MsUUFBZ0I7QUFDckMsWUFBUUEsS0FBRztBQUFBLE1BQ1QsS0FBSztBQUFjLGVBQU87QUFBQSxNQUMxQixLQUFLO0FBQVEsZUFBTztBQUFBLE1BQ3BCLEtBQUs7QUFBUSxlQUFPO0FBQUEsTUFDcEIsS0FBSztBQUFVLGVBQU87QUFBQSxNQUN0QjtBQUFTLGVBQU87QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxVQUFVLFVBQVVDLFFBQVEsVUFBVUMsU0FBUyxRQUFRQyxlQUFlLFVBQVVDLEtBQUssT0FBTyxHQUd4RztBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRUMsU0FBUyxRQUFRSCxTQUFTLFFBQVFJLFlBQVksVUFBVUMsZ0JBQWdCLGlCQUFpQkMsVUFBVSxRQUFRSixLQUFLLE9BQU8sR0FDMUo7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxPQUFPLEVBQUVLLFVBQVUsUUFBUUMsWUFBWSxPQUFPVCxRQUFRLGFBQWFDLFNBQVMsUUFBUUksWUFBWSxVQUFVRixLQUFLLE9BQU8sR0FDeEg7QUFBQSxpQ0FBQyxTQUFNLE9BQU0sYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBO0FBQUEsYUFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLE9BQU8sRUFBRUssVUFBVSxRQUFRRSxPQUFPLHFCQUFxQlYsUUFBUSxFQUFFLEdBQUUsbUxBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLFNBQVMvQixjQUN6QztBQUFBLCtCQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CO0FBQUEsUUFBRztBQUFBLFFBQW9CWixTQUFTc0Q7QUFBQUEsUUFBTztBQUFBLFdBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVYsU0FBUyxRQUFRVyxxQkFBcUIsYUFBYVQsS0FBSyxPQUFPLEdBRzNFO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVGLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FHbEU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLFNBQVMsYUFBYUgsU0FBUyxRQUFRSSxZQUFZLFVBQVVDLGdCQUFnQixnQkFBZ0IsR0FDaEk7QUFBQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUwsU0FBUyxRQUFRSSxZQUFZLFVBQVVGLEtBQUssT0FBT0ssVUFBVSxRQUFRRSxPQUFPLG9CQUFvQixHQUM1RztBQUFBLG1DQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUEsWUFDakIsdUJBQUMsVUFBSyxnQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBLGVBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFVCxTQUFTLFFBQVFFLEtBQUssTUFBTSxHQUN2QyxXQUFDLE9BQU8sY0FBYyxRQUFRLFFBQVEsVUFBVSxTQUFTLEVBQUVVO0FBQUFBLFlBQUksQ0FBQ2YsUUFDL0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxTQUFTLE1BQU10QyxvQkFBb0JzQyxHQUFHO0FBQUEsZ0JBQ3RDLE9BQU87QUFBQSxrQkFDTGdCLFlBQVl2RCxxQkFBcUJ1QyxNQUFNLDRCQUE0QjtBQUFBLGtCQUNuRWlCLFFBQVF4RCxxQkFBcUJ1QyxNQUFNLHNDQUFzQztBQUFBLGtCQUN6RVksT0FBT25ELHFCQUFxQnVDLE1BQU0sWUFBWTtBQUFBLGtCQUM5Q2tCLGNBQWM7QUFBQSxrQkFDZFosU0FBUztBQUFBLGtCQUNUSSxVQUFVO0FBQUEsa0JBQ1ZTLFFBQVE7QUFBQSxrQkFDUkMsZUFBZTtBQUFBLGdCQUNqQjtBQUFBLGdCQUVDcEI7QUFBQUE7QUFBQUEsY0FiSUE7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZUE7QUFBQSxVQUNELEtBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUNyQyxZQUNDLHVCQUFDLFNBQUksT0FBTyxFQUFFMkMsU0FBUyxRQUFRYyxlQUFlLGFBQWFDLFdBQVcsVUFBVVQsT0FBTyxtQkFBbUJGLFVBQVUsT0FBTyxHQUFFLGlEQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFDRWIsaUJBQWlCZ0IsV0FBVyxJQUM5Qix1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVQLFNBQVMsUUFBUWUsV0FBVyxVQUFVVCxPQUFPLG1CQUFtQkYsVUFBVSxPQUFPLEdBQUU7QUFBQTtBQUFBLFVBQ3RGakQ7QUFBQUEsVUFBaUI7QUFBQSxhQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRTBDLFNBQVMsUUFBUVcscUJBQXFCLHlDQUF5Q1QsS0FBSyxPQUFPLEdBQ3RHUiwyQkFBaUJrQjtBQUFBQSxVQUFJLENBQUNPLFFBQ3JCLHVCQUFDLFNBQWlCLFdBQVUsOEJBQTZCLE9BQU8sRUFBRWhCLFNBQVMsUUFBUUgsU0FBUyxRQUFRQyxlQUFlLFVBQVVJLGdCQUFnQixnQkFBZ0IsR0FDM0o7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVMLFNBQVMsUUFBUUssZ0JBQWdCLGlCQUFpQkQsWUFBWSxVQUFVZ0IsY0FBYyxNQUFNLEdBQ3hHO0FBQUEsdUNBQUMsVUFBSyxXQUFXLFNBQVN4QixjQUFjdUIsSUFBSXhCLFFBQVEsQ0FBQyxJQUFLd0IsY0FBSXhCLFlBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsZ0JBQ3ZFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTVIsYUFBYWdDLElBQUkvQixFQUFFO0FBQUEsb0JBQ2xDLE9BQU8sRUFBRXlCLFlBQVksUUFBUUMsUUFBUSxRQUFRTCxPQUFPLFdBQVdPLFFBQVEsV0FBV0ssU0FBUyxJQUFJO0FBQUEsb0JBQy9GLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQjtBQUFBO0FBQUEsa0JBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUVBLHVCQUFDLE9BQUUsT0FBTyxFQUFFZCxVQUFVLFFBQVFlLFlBQVksT0FBT3ZCLFFBQVEsY0FBY1UsT0FBTyxtQkFBbUIsR0FDOUZVLGNBQUlJLFdBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksT0FBTyxFQUFFdkIsU0FBUyxRQUFRSyxnQkFBZ0IsaUJBQWlCRSxVQUFVLFFBQVFFLE9BQU8sbUJBQW1CZSxXQUFXLGlDQUFpQ0MsWUFBWSxNQUFNLEdBQ3hLO0FBQUEscUNBQUMsVUFBSztBQUFBO0FBQUEsZ0JBQVNOLElBQUlPO0FBQUFBLG1CQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQzFCLHVCQUFDLFVBQUs7QUFBQTtBQUFBLGlCQUFjUCxJQUFJUSxhQUFhLEtBQUtDLFFBQVEsQ0FBQztBQUFBLGdCQUFFO0FBQUEsbUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsaUJBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQXJCUVQsSUFBSS9CLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxRQUNELEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQWxFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVlLFNBQVMsUUFBUUgsU0FBUyxRQUFRQyxlQUFlLFVBQVVDLEtBQUssT0FBTyxHQUMxRztBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFSyxVQUFVLFFBQVFDLFlBQVksT0FBT1QsUUFBUSxHQUFHQyxTQUFTLFFBQVFJLFlBQVksVUFBVUYsS0FBSyxNQUFNLEdBQzdHO0FBQUEsaUNBQUMsUUFBSyxNQUFNLElBQUksT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQTtBQUFBLGFBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUNwQyxhQUNDLHVCQUFDLFNBQUksT0FBTztBQUFBLFVBQ1ZxQyxTQUFTO0FBQUEsVUFDVFksY0FBYztBQUFBLFVBQ2RGLFlBQVkvQyxVQUFVYSxTQUFTLFlBQVksNkJBQTZCO0FBQUEsVUFDeEVtQyxRQUFRaEQsVUFBVWEsU0FBUyxZQUFZLHNDQUFzQztBQUFBLFVBQzdFOEIsT0FBTzNDLFVBQVVhLFNBQVMsWUFBWSxZQUFZO0FBQUEsVUFDbEQ0QixVQUFVO0FBQUEsUUFDWixHQUNHekMsb0JBQVVjLFFBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHRix1QkFBQyxVQUFLLFVBQVVOLGlCQUFpQixPQUFPLEVBQUUwQixTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxPQUFPLEdBQzlGO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFRixTQUFTLFNBQVNPLFVBQVUsUUFBUUMsWUFBWSxPQUFPWSxjQUFjLE1BQU0sR0FBRSxnQ0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFUyxPQUFPLE9BQU87QUFBQSxnQkFDdkIsT0FBT2pFO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ1csTUFBTVYsZUFBZVUsRUFBRXVELE9BQU9DLEtBQUs7QUFBQSxnQkFFOUM7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sY0FBYSxrREFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkQ7QUFBQSxrQkFDN0QsdUJBQUMsWUFBTyxPQUFNLFFBQU8sNENBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pELHVCQUFDLFlBQU8sT0FBTSxRQUFPLDRDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRDtBQUFBLGtCQUNqRCx1QkFBQyxZQUFPLE9BQU0sVUFBUywwQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUQ7QUFBQSxrQkFDakQsdUJBQUMsWUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUE7QUFBQTtBQUFBLGNBVmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFL0IsU0FBUyxTQUFTTyxVQUFVLFFBQVFDLFlBQVksT0FBT1ksY0FBYyxNQUFNLEdBQUUsK0JBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRVMsT0FBTyxRQUFRRyxXQUFXLFNBQVNDLFFBQVEsV0FBVztBQUFBLGdCQUMvRCxhQUFZO0FBQUEsZ0JBQ1osT0FBT3ZFO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2EsTUFBTVosY0FBY1ksRUFBRXVELE9BQU9DLEtBQUs7QUFBQSxnQkFDN0MsVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsWUFBTyxXQUFVLGVBQWMsTUFBSyxVQUNuQztBQUFBLG1DQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFBRztBQUFBLGVBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsV0F2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLFNBcElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzSUE7QUFBQSxPQXpKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkpBO0FBRUo7QUFBQzdFLEdBbk9ZRCxhQUFxQjtBQUFBLFVBQ2RULGdCQUFnQjtBQUFBO0FBQUEsS0FEdkJTO0FBQXFCLElBQUFpRjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU91dGxldENvbnRleHQiLCJBcGlPcGVyYXRpb25zIiwiSHR0cEVycm9yUmVzcG9uc2UiLCJCcmFpbiIsIlBsdXMiLCJUcmFzaDIiLCJTcGFya2xlcyIsIkZpbHRlciIsIlRPQVNUX01FU1NBR0VTIiwiTWVtb3JpZXNUYWIiLCJfcyIsImNyZWRzIiwibWVtb3JpZXMiLCJzZXRNZW1vcmllcyIsInNlbGVjdGVkQ2F0ZWdvcnkiLCJzZXRTZWxlY3RlZENhdGVnb3J5IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwibmV3Q29udGVudCIsInNldE5ld0NvbnRlbnQiLCJuZXdDYXRlZ29yeSIsInNldE5ld0NhdGVnb3J5Iiwic3RhdHVzTXNnIiwic2V0U3RhdHVzTXNnIiwibG9hZE1lbW9yaWVzIiwiZGF0YSIsImZldGNoTWVtb3JpZXMiLCJlcnIiLCJjb25zb2xlIiwid2FybiIsImhhbmRsZUFkZE1lbW9yeSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJhZGRNZW1vcnkiLCJ0eXBlIiwidGV4dCIsIlNVQ0NFU1MiLCJNRU1PUllfU0FWRUQiLCJzZXRUaW1lb3V0IiwibWVzc2FnZSIsIkVSUk9SIiwiTUVNT1JZX0FDVElPTl9GQUlMRUQiLCJoYW5kbGVEZWxldGUiLCJpZCIsImRlbGV0ZU1lbW9yeSIsInByZXYiLCJmaWx0ZXIiLCJtIiwiTUVNT1JZX0RFTEVURUQiLCJmaWx0ZXJlZE1lbW9yaWVzIiwiY2F0ZWdvcnkiLCJjYXRlZ29yeUJhZGdlIiwiY2F0IiwibWF4V2lkdGgiLCJtYXJnaW4iLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsInBhZGRpbmciLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJmbGV4V3JhcCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImNvbG9yIiwibGVuZ3RoIiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsIm1hcCIsImJhY2tncm91bmQiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJjdXJzb3IiLCJ0ZXh0VHJhbnNmb3JtIiwidGV4dEFsaWduIiwibWVtIiwibWFyZ2luQm90dG9tIiwib3BhY2l0eSIsImxpbmVIZWlnaHQiLCJjb250ZW50IiwiYm9yZGVyVG9wIiwicGFkZGluZ1RvcCIsInNvdXJjZSIsImNvbmZpZGVuY2UiLCJ0b0ZpeGVkIiwid2lkdGgiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1pbkhlaWdodCIsInJlc2l6ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1lbW9yaWVzVGFiLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlT3V0bGV0Q29udGV4dCB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBcGlDcmVkZW50aWFscywgTWVtb3J5UmVjb3JkIH0gZnJvbSAnQC90eXBlcydcbmltcG9ydCB7IEFwaU9wZXJhdGlvbnMgfSBmcm9tICdAL29wZXJhdGlvbnMvYXBpLm9wZXJhdGlvbidcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSAnQC91dGlscy9lcnJvcnMnXG5pbXBvcnQgeyBCcmFpbiwgUGx1cywgVHJhc2gyLCBTcGFya2xlcywgRmlsdGVyLCBDaGVja0NpcmNsZTIsIFNoaWVsZEFsZXJ0IH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgVE9BU1RfTUVTU0FHRVMgfSBmcm9tICdAL2NvbmZpZy9tZXNzYWdlcy90b2FzdC5tZXNzYWdlcydcblxuZXhwb3J0IGNvbnN0IE1lbW9yaWVzVGFiOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBjcmVkcyB9ID0gdXNlT3V0bGV0Q29udGV4dDx7IGNyZWRzOiBBcGlDcmVkZW50aWFscyB9PigpXG4gIGNvbnN0IFttZW1vcmllcywgc2V0TWVtb3JpZXNdID0gdXNlU3RhdGU8TWVtb3J5UmVjb3JkW10+KFtdKVxuICBjb25zdCBbc2VsZWN0ZWRDYXRlZ29yeSwgc2V0U2VsZWN0ZWRDYXRlZ29yeV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdhbGwnKVxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtuZXdDb250ZW50LCBzZXROZXdDb250ZW50XSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbmV3Q2F0ZWdvcnksIHNldE5ld0NhdGVnb3J5XSA9IHVzZVN0YXRlPGFueT4oJ3ByZWZlcmVuY2UnKVxuICBjb25zdCBbc3RhdHVzTXNnLCBzZXRTdGF0dXNNc2ddID0gdXNlU3RhdGU8eyB0eXBlOiAnc3VjY2VzcycgfCAnZXJyb3InOyB0ZXh0OiBzdHJpbmcgfSB8IG51bGw+KG51bGwpXG5cbiAgY29uc3QgbG9hZE1lbW9yaWVzID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzTG9hZGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgQXBpT3BlcmF0aW9ucy5mZXRjaE1lbW9yaWVzKClcbiAgICAgIHNldE1lbW9yaWVzKGRhdGEubWVtb3JpZXMpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0ZhaWxlZCB0byBsb2FkIG1lbW9yaWVzOicsIGVycilcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9hZE1lbW9yaWVzKClcbiAgfSwgW10pXG5cbiAgY29uc3QgaGFuZGxlQWRkTWVtb3J5ID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmICghbmV3Q29udGVudC50cmltKCkpIHJldHVyblxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IEFwaU9wZXJhdGlvbnMuYWRkTWVtb3J5KG5ld0NvbnRlbnQsIG5ld0NhdGVnb3J5LCAxLjAsICdtYW51YWwnKVxuICAgICAgc2V0TmV3Q29udGVudCgnJylcbiAgICAgIHNldFN0YXR1c01zZyh7IHR5cGU6ICdzdWNjZXNzJywgdGV4dDogVE9BU1RfTUVTU0FHRVMuU1VDQ0VTUy5NRU1PUllfU0FWRUQgfSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzTXNnKG51bGwpLCA0MDAwKVxuICAgICAgbG9hZE1lbW9yaWVzKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnIgaW5zdGFuY2VvZiBIdHRwRXJyb3JSZXNwb25zZSA/IGVyci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InXG4gICAgICBzZXRTdGF0dXNNc2coeyB0eXBlOiAnZXJyb3InLCB0ZXh0OiBgJHtUT0FTVF9NRVNTQUdFUy5FUlJPUi5NRU1PUllfQUNUSU9OX0ZBSUxFRH0gJHttZXNzYWdlfWAgfSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzTXNnKG51bGwpLCA0MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IEFwaU9wZXJhdGlvbnMuZGVsZXRlTWVtb3J5KGlkKVxuICAgICAgc2V0TWVtb3JpZXMoKHByZXYpID0+IHByZXYuZmlsdGVyKChtKSA9PiBtLmlkICE9PSBpZCkpXG4gICAgICBzZXRTdGF0dXNNc2coeyB0eXBlOiAnc3VjY2VzcycsIHRleHQ6IFRPQVNUX01FU1NBR0VTLlNVQ0NFU1MuTUVNT1JZX0RFTEVURUQgfSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzTXNnKG51bGwpLCA0MDAwKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IGVyciBpbnN0YW5jZW9mIEh0dHBFcnJvclJlc3BvbnNlID8gZXJyLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcidcbiAgICAgIHNldFN0YXR1c01zZyh7IHR5cGU6ICdlcnJvcicsIHRleHQ6IGAke1RPQVNUX01FU1NBR0VTLkVSUk9SLk1FTU9SWV9BQ1RJT05fRkFJTEVEfSAke21lc3NhZ2V9YCB9KVxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdGF0dXNNc2cobnVsbCksIDQwMDApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZmlsdGVyZWRNZW1vcmllcyA9IG1lbW9yaWVzLmZpbHRlcigobSkgPT5cbiAgICBzZWxlY3RlZENhdGVnb3J5ID09PSAnYWxsJyA/IHRydWUgOiBtLmNhdGVnb3J5ID09PSBzZWxlY3RlZENhdGVnb3J5XG4gIClcblxuICBjb25zdCBjYXRlZ29yeUJhZGdlID0gKGNhdDogc3RyaW5nKSA9PiB7XG4gICAgc3dpdGNoIChjYXQpIHtcbiAgICAgIGNhc2UgJ3ByZWZlcmVuY2UnOiByZXR1cm4gJ2JhZGdlLWluZGlnbydcbiAgICAgIGNhc2UgJ2ZhY3QnOiByZXR1cm4gJ2JhZGdlLWN5YW4nXG4gICAgICBjYXNlICdnb2FsJzogcmV0dXJuICdiYWRnZS1hbWJlcidcbiAgICAgIGNhc2UgJ2VudGl0eSc6IHJldHVybiAnYmFkZ2UtZW1lcmFsZCdcbiAgICAgIGRlZmF1bHQ6IHJldHVybiAnYmFkZ2UtaW5kaWdvJ1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBtYXhXaWR0aDogJzEyMDBweCcsIG1hcmdpbjogJzAgYXV0bycsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzI0cHgnIH19PlxuICAgICAgXG4gICAgICB7LyogVG9wIEJhbm5lciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcyNHB4JywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgZmxleFdyYXA6ICd3cmFwJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIHN0eWxlPXt7IGZvbnRTaXplOiAnMjBweCcsIGZvbnRXZWlnaHQ6ICc3MDAnLCBtYXJnaW46ICcwIDAgNnB4IDAnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcxMHB4JyB9fT5cbiAgICAgICAgICAgIDxCcmFpbiBjb2xvcj1cIiNhNWI0ZmNcIiAvPlxuICAgICAgICAgICAgU3VwYWJhc2UgTG9uZy1UZXJtIE1lbW9yeSBFeHBsb3JlclxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxM3B4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScsIG1hcmdpbjogMCB9fT5cbiAgICAgICAgICAgIEluc3BlY3QgZmFjdHMsIHByZWZlcmVuY2VzLCBhbmQgZW50aXR5IG1lbW9yaWVzIGV4dHJhY3RlZCBhdXRvbWF0aWNhbGx5IHZpYSBab2Qgb3IgYWRkZWQgbWFudWFsbHkuIFN0b3JlZCBpbiBTdXBhYmFzZSBgbWVtb3JpZXNgIHRhYmxlIHdpdGggdmVjdG9yIGNvc2luZSBpbmRleGluZy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIG9uQ2xpY2s9e2xvYWRNZW1vcmllc30+XG4gICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE2fSAvPiBSZWZyZXNoIE1lbW9yaWVzICh7bWVtb3JpZXMubGVuZ3RofSlcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICcxZnIgMzgwcHgnLCBnYXA6ICcyNHB4JyB9fT5cbiAgICAgICAgXG4gICAgICAgIHsvKiBNZW1vcmllcyBHcmlkICovfVxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzE2cHgnIH19PlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBDYXRlZ29yeSBGaWx0ZXIgQmFyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcxMnB4IDIwcHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nIH19PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnLCBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJyB9fT5cbiAgICAgICAgICAgICAgPEZpbHRlciBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgPHNwYW4+RmlsdGVyIENhdGVnb3J5Ojwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAge1snYWxsJywgJ3ByZWZlcmVuY2UnLCAnZmFjdCcsICdnb2FsJywgJ2VudGl0eScsICdnZW5lcmFsJ10ubWFwKChjYXQpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2NhdH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQ2F0ZWdvcnkoY2F0KX1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHNlbGVjdGVkQ2F0ZWdvcnkgPT09IGNhdCA/ICdyZ2JhKDk5LCAxMDIsIDI0MSwgMC4yKScgOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IHNlbGVjdGVkQ2F0ZWdvcnkgPT09IGNhdCA/ICcxcHggc29saWQgcmdiYSg5OSwgMTAyLCAyNDEsIDAuNCknIDogJzFweCBzb2xpZCB0cmFuc3BhcmVudCcsXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBzZWxlY3RlZENhdGVnb3J5ID09PSBjYXQgPyAnI2E1YjRmYycgOiAndmFyKC0tdGV4dC1tdXRlZCknLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnNHB4IDEwcHgnLFxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogJzEycHgnLFxuICAgICAgICAgICAgICAgICAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAgICAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogJ2NhcGl0YWxpemUnXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtjYXR9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7aXNMb2FkaW5nID8gKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnNDBweCcsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScsIGZvbnRTaXplOiAnMTNweCcgfX0+XG4gICAgICAgICAgICAgIExvYWRpbmcgbWVtb3JpZXMgZnJvbSBTdXBhYmFzZS4uLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IGZpbHRlcmVkTWVtb3JpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbGFzcy1jYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogJzQwcHgnLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScsIGZvbnRTaXplOiAnMTNweCcgfX0+XG4gICAgICAgICAgICAgIE5vIG1lbW9yaWVzIGZvdW5kIGluIGNhdGVnb3J5IFwie3NlbGVjdGVkQ2F0ZWdvcnl9XCIuIFN0YXJ0IGNoYXR0aW5nIG9yIGFkZCBvbmUgbWFudWFsbHkhXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdyZXBlYXQoYXV0by1maWxsLCBtaW5tYXgoMjgwcHgsIDFmcikpJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZE1lbW9yaWVzLm1hcCgobWVtKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e21lbS5pZH0gY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCBhbmltYXRlLWZhZGUtaW5cIiBzdHlsZT17eyBwYWRkaW5nOiAnMTZweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgYWxpZ25JdGVtczogJ2NlbnRlcicsIG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgYmFkZ2UgJHtjYXRlZ29yeUJhZGdlKG1lbS5jYXRlZ29yeSl9YH0+e21lbS5jYXRlZ29yeX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKG1lbS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbm9uZScsIGJvcmRlcjogJ25vbmUnLCBjb2xvcjogJyNmY2E1YTUnLCBjdXJzb3I6ICdwb2ludGVyJywgb3BhY2l0eTogMC43IH19XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlbGV0ZSBNZW1vcnlcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRTaXplOiAnMTNweCcsIGxpbmVIZWlnaHQ6ICcxLjUnLCBtYXJnaW46ICcwIDAgMTBweCAwJywgY29sb3I6ICd2YXIoLS10ZXh0LW1haW4pJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7bWVtLmNvbnRlbnR9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgZm9udFNpemU6ICcxMHB4JywgY29sb3I6ICd2YXIoLS10ZXh0LWRpbSknLCBib3JkZXJUb3A6ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKScsIHBhZGRpbmdUb3A6ICc4cHgnIH19PlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Tb3VyY2U6IHttZW0uc291cmNlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q29uZmlkZW5jZTogeyhtZW0uY29uZmlkZW5jZSAqIDEwMCkudG9GaXhlZCgwKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWRkIE1lbW9yeSBTaWRlYmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzE2cHgnIH19PlxuICAgICAgICAgIDxoMyBzdHlsZT17eyBmb250U2l6ZTogJzE2cHgnLCBmb250V2VpZ2h0OiAnNzAwJywgbWFyZ2luOiAwLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxuICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTh9IGNvbG9yPVwidmFyKC0tcHJpbWFyeSlcIiAvPlxuICAgICAgICAgICAgQWRkIE1hbnVhbCBNZW1vcnlcbiAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAge3N0YXR1c01zZyAmJiAoXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgICAgICAgIHBhZGRpbmc6ICcxMHB4IDE0cHgnLFxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBzdGF0dXNNc2cudHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJ3JnYmEoMTYsIDE4NSwgMTI5LCAwLjE1KScgOiAncmdiYSgyMzksIDY4LCA2OCwgMC4xNSknLFxuICAgICAgICAgICAgICBib3JkZXI6IHN0YXR1c01zZy50eXBlID09PSAnc3VjY2VzcycgPyAnMXB4IHNvbGlkIHJnYmEoMTYsIDE4NSwgMTI5LCAwLjMpJyA6ICcxcHggc29saWQgcmdiYSgyMzksIDY4LCA2OCwgMC4zKScsXG4gICAgICAgICAgICAgIGNvbG9yOiBzdGF0dXNNc2cudHlwZSA9PT0gJ3N1Y2Nlc3MnID8gJyM2ZWU3YjcnIDogJyNmY2E1YTUnLFxuICAgICAgICAgICAgICBmb250U2l6ZTogJzEycHgnXG4gICAgICAgICAgICB9fT5cbiAgICAgICAgICAgICAge3N0YXR1c01zZy50ZXh0fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBZGRNZW1vcnl9IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzE0cHgnIH19PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycsIGZvbnRTaXplOiAnMTJweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBtYXJnaW5Cb3R0b206ICc2cHgnIH19PlxuICAgICAgICAgICAgICAgIE1lbW9yeSBDYXRlZ29yeTpcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWlucHV0XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XG4gICAgICAgICAgICAgICAgdmFsdWU9e25ld0NhdGVnb3J5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3Q2F0ZWdvcnkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInByZWZlcmVuY2VcIj5QcmVmZXJlbmNlIChlLmcuIExpa2VzIFR5cGVTY3JpcHQpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImZhY3RcIj5GYWN0IChlLmcuIFVzZXIgbGl2ZXMgaW4gTlkpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImdvYWxcIj5Hb2FsIChlLmcuIEJ1aWxkaW5nIFJBRyBhcHApPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImVudGl0eVwiPkVudGl0eSAoZS5nLiBQcm9qZWN0IE5hbWUpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImdlbmVyYWxcIj5HZW5lcmFsPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiAnYmxvY2snLCBmb250U2l6ZTogJzEycHgnLCBmb250V2VpZ2h0OiAnNjAwJywgbWFyZ2luQm90dG9tOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICBNZW1vcnkgQ29udGVudDpcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScsIG1pbkhlaWdodDogJzEwMHB4JywgcmVzaXplOiAndmVydGljYWwnIH19XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFVzZXIgaXMgYnVpbGRpbmcgYSBmdWxsLXN0YWNrIFJBRyBhcHAgdXNpbmcgU3VwYWJhc2UgcGd2ZWN0b3IuXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Q29udGVudH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0NvbnRlbnQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiIHR5cGU9XCJzdWJtaXRcIj5cbiAgICAgICAgICAgICAgPEJyYWluIHNpemU9ezE2fSAvPiBTYXZlIE1lbW9yeSB0byBWZWN0b3IgU3RvcmVcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiJDOi9ub2RlL2xsbS9jbGllbnQvc3JjL3ZpZXdzL01lbW9yaWVzVGFiLnRzeCJ9