import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/KafkaTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/KafkaTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { ApiOperations } from "/src/operations/api.operation.ts";
import { HttpErrorResponse } from "/src/utils/errors.ts";
import { Activity, Radio, RefreshCw, CheckCircle2, ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
export const KafkaTab = () => {
  _s();
  const [kafkaStatus, setKafkaStatus] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const loadStatus = async () => {
    setIsRefreshing(true);
    try {
      const data = await ApiOperations.fetchKafkaStatus();
      setKafkaStatus(data);
    } catch (e) {
      console.warn("Failed to load Kafka status:", e instanceof HttpErrorResponse ? e.message : e);
    } finally {
      setIsRefreshing(false);
    }
  };
  useEffect(() => {
    loadStatus();
    const interval = setInterval(loadStatus, 4e3);
    return () => clearInterval(interval);
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1200px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "24px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "20px", fontWeight: "700", margin: "0 0 6px 0", display: "flex", alignItems: "center", gap: "10px" }, children: [
          /* @__PURE__ */ jsxDEV(Activity, { color: "#f59e0b" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 55,
            columnNumber: 13
          }, this),
          "Apache Kafka Event Streaming Hub"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 54,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "13px", color: "var(--text-muted)", margin: 0 }, children: "Asynchronous message bus powered by **kafkajs**. Offloads Firecrawl web ingestion (`rag.ingest`), user memory extraction (`memory.extract`), and search auditing (`search.audit`)." }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 58,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", onClick: loadStatus, disabled: isRefreshing, children: [
        /* @__PURE__ */ jsxDEV(RefreshCw, { size: 16, className: isRefreshing ? "animate-spin" : "" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 64,
          columnNumber: 11
        }, this),
        "Refresh Topics & Logs"
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
        lineNumber: 63,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "320px 1fr", gap: "24px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "20px" }, children: [
          /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "14px", fontWeight: "700", marginBottom: "12px", display: "flex", alignItems: "center", gap: "8px" }, children: [
            /* @__PURE__ */ jsxDEV(Radio, { size: 16, color: "#f59e0b" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 77,
              columnNumber: 15
            }, this),
            " Broker Status"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 76,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            padding: "12px",
            borderRadius: "8px",
            background: kafkaStatus?.connected ? "rgba(16, 185, 129, 0.15)" : "rgba(245, 158, 11, 0.15)",
            border: kafkaStatus?.connected ? "1px solid rgba(16, 185, 129, 0.3)" : "1px solid rgba(245, 158, 11, 0.3)",
            color: kafkaStatus?.connected ? "#6ee7b7" : "#fcd34d",
            fontSize: "13px",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }, children: [
            kafkaStatus?.connected ? /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 18 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 91,
              columnNumber: 41
            }, this) : /* @__PURE__ */ jsxDEV(ShieldAlert, { size: 18 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 91,
              columnNumber: 70
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: "600" }, children: kafkaStatus?.connected ? "Kafka Connected" : "Event Stream Active" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                lineNumber: 93,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", opacity: 0.8 }, children: kafkaStatus?.connected ? "Cluster: kafka:29092" : "Local Fallback Logger" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                lineNumber: 94,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 92,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 80,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 75,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "20px", display: "flex", flexDirection: "column", gap: "12px" }, children: [
          /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "14px", fontWeight: "700", margin: 0 }, children: "Active Kafka Topics" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 103,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(13, 21, 39, 0.8)", border: "1px solid var(--border-color)", borderRadius: "8px", padding: "10px" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "12px", fontWeight: "600", color: "#67e8f9", marginBottom: "4px" }, children: "rag.ingest" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 106,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-muted)" }, children: "Async Firecrawl web crawling & vector storage" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 107,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 105,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(13, 21, 39, 0.8)", border: "1px solid var(--border-color)", borderRadius: "8px", padding: "10px" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "12px", fontWeight: "600", color: "#a5b4fc", marginBottom: "4px" }, children: "memory.extract" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 111,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-muted)" }, children: "Background Zod memory extraction worker" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 112,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 110,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { background: "rgba(13, 21, 39, 0.8)", border: "1px solid var(--border-color)", borderRadius: "8px", padding: "10px" }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "12px", fontWeight: "600", color: "#6ee7b7", marginBottom: "4px" }, children: "search.audit" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 116,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: "11px", color: "var(--text-muted)" }, children: "Tavily web grounding & RAG query audit log" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 117,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 115,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 102,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
        lineNumber: 72,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "16px", fontWeight: "700", margin: 0, display: "flex", alignItems: "center", gap: "8px" }, children: [
          /* @__PURE__ */ jsxDEV(Activity, { size: 18, color: "var(--primary)" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
            lineNumber: 126,
            columnNumber: 13
          }, this),
          "Real-Time Kafka Event Stream (",
          kafkaStatus?.logs?.length || 0,
          " events)"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 125,
          columnNumber: 11
        }, this),
        !kafkaStatus?.logs || kafkaStatus.logs.length === 0 ? /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center", color: "var(--text-dim)", padding: "60px 0", fontSize: "13px" }, children: "No Kafka events streamed yet. Send a chat message or scrape a URL to produce events!" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 131,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "10px", maxHeight: "520px", overflowY: "auto" }, children: kafkaStatus.logs.map(
          (log) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "animate-fade-in",
              style: {
                background: "rgba(13, 21, 39, 0.85)",
                border: "1px solid var(--border-color)",
                borderRadius: "10px",
                padding: "14px",
                display: "flex",
                flexDirection: "column",
                gap: "8px"
              },
              children: [
                /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "badge badge-amber", children: log.topic }, void 0, false, {
                      fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                      lineNumber: 152,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "11px", color: log.status === "published" ? "#6ee7b7" : "#a5b4fc" }, children: [
                      "● ",
                      log.status
                    ] }, void 0, true, {
                      fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                      lineNumber: 153,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                    lineNumber: 151,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { style: { fontSize: "10px", color: "var(--text-dim)" }, children: new Date(log.timestamp).toLocaleTimeString() }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                    lineNumber: 157,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                  lineNumber: 150,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("pre", { style: {
                  margin: 0,
                  fontSize: "11px",
                  fontFamily: "var(--font-mono)",
                  color: "#f8fafc",
                  background: "rgba(0,0,0,0.4)",
                  padding: "8px",
                  borderRadius: "6px",
                  overflowX: "auto"
                }, children: JSON.stringify(log.payload, null, 2) }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
                  lineNumber: 162,
                  columnNumber: 19
                }, this)
              ]
            },
            log.id,
            true,
            {
              fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
              lineNumber: 137,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/KafkaTab.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
};
_s(KafkaTab, "RaSor0oJMeCk+jkjP94qeGTHKuQ=");
_c = KafkaTab;
var _c;
$RefreshReg$(_c, "KafkaTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/KafkaTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/KafkaTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNZOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5DWixTQUFnQkEsVUFBVUMsaUJBQWlCO0FBRTNDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsVUFBVUMsT0FBaUJDLFdBQWlCQyxjQUFjQyxtQkFBNkI7QUFFekYsYUFBTUMsV0FBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUN0QyxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSVosU0FBcUMsSUFBSTtBQUMvRSxRQUFNLENBQUNhLGNBQWNDLGVBQWUsSUFBSWQsU0FBUyxLQUFLO0FBRXRELFFBQU1lLGFBQWEsWUFBWTtBQUM3QkQsb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNGLFlBQU1FLE9BQU8sTUFBTWQsY0FBY2UsaUJBQWlCO0FBQ2xETCxxQkFBZUksSUFBSTtBQUFBLElBQ3JCLFNBQVNFLEdBQUc7QUFDVkMsY0FBUUMsS0FBSyxnQ0FBZ0NGLGFBQWFmLG9CQUFvQmUsRUFBRUcsVUFBVUgsQ0FBQztBQUFBLElBQzdGLFVBQUM7QUFDQ0osc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQWIsWUFBVSxNQUFNO0FBQ2RjLGVBQVc7QUFDWCxVQUFNTyxXQUFXQyxZQUFZUixZQUFZLEdBQUk7QUFDN0MsV0FBTyxNQUFNUyxjQUFjRixRQUFRO0FBQUEsRUFDckMsR0FBRyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsVUFBVSxVQUFVQyxRQUFRLFVBQVVDLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FHeEc7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLFNBQVMsUUFBUUgsU0FBUyxRQUFRSSxZQUFZLFVBQVVDLGdCQUFnQixpQkFBaUJDLFVBQVUsUUFBUUosS0FBSyxPQUFPLEdBQzFKO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFSyxVQUFVLFFBQVFDLFlBQVksT0FBT1QsUUFBUSxhQUFhQyxTQUFTLFFBQVFJLFlBQVksVUFBVUYsS0FBSyxPQUFPLEdBQ3hIO0FBQUEsaUNBQUMsWUFBUyxPQUFNLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlCO0FBQUE7QUFBQSxhQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsT0FBTyxFQUFFSyxVQUFVLFFBQVFFLE9BQU8scUJBQXFCVixRQUFRLEVBQUUsR0FBRSxrTUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsU0FBU1gsWUFBWSxVQUFVRixjQUMvRDtBQUFBLCtCQUFDLGFBQVUsTUFBTSxJQUFJLFdBQVdBLGVBQWUsaUJBQWlCLE1BQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQTtBQUFBLFdBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWMsU0FBUyxRQUFRVSxxQkFBcUIsYUFBYVIsS0FBSyxPQUFPLEdBRzNFO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEVBQUVGLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FHbEU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLFNBQVMsT0FBTyxHQUNuRDtBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFSSxVQUFVLFFBQVFDLFlBQVksT0FBT0csY0FBYyxRQUFRWCxTQUFTLFFBQVFJLFlBQVksVUFBVUYsS0FBSyxNQUFNLEdBQ3hIO0FBQUEsbUNBQUMsU0FBTSxNQUFNLElBQUksT0FBTSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQUc7QUFBQSxlQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUNWQyxTQUFTO0FBQUEsWUFDVFMsY0FBYztBQUFBLFlBQ2RDLFlBQVk3QixhQUFhOEIsWUFBWSw2QkFBNkI7QUFBQSxZQUNsRUMsUUFBUS9CLGFBQWE4QixZQUFZLHNDQUFzQztBQUFBLFlBQ3ZFTCxPQUFPekIsYUFBYThCLFlBQVksWUFBWTtBQUFBLFlBQzVDUCxVQUFVO0FBQUEsWUFDVlAsU0FBUztBQUFBLFlBQ1RJLFlBQVk7QUFBQSxZQUNaRixLQUFLO0FBQUEsVUFDUCxHQUNHbEI7QUFBQUEseUJBQWE4QixZQUFZLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUIsSUFBTSx1QkFBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUM3RSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxPQUFPLEVBQUVOLFlBQVksTUFBTSxHQUFJeEIsdUJBQWE4QixZQUFZLG9CQUFvQix5QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUc7QUFBQSxjQUN2Ryx1QkFBQyxTQUFJLE9BQU8sRUFBRVAsVUFBVSxRQUFRUyxTQUFTLElBQUksR0FDMUNoQyx1QkFBYThCLFlBQVkseUJBQXlCLDJCQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFWCxTQUFTLFFBQVFILFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FDMUc7QUFBQSxpQ0FBQyxRQUFHLE9BQU8sRUFBRUssVUFBVSxRQUFRQyxZQUFZLE9BQU9ULFFBQVEsRUFBRSxHQUFHLG1DQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBRWxGLHVCQUFDLFNBQUksT0FBTyxFQUFFYyxZQUFZLHlCQUF5QkUsUUFBUSxpQ0FBaUNILGNBQWMsT0FBT1QsU0FBUyxPQUFPLEdBQy9IO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUVJLFVBQVUsUUFBUUMsWUFBWSxPQUFPQyxPQUFPLFdBQVdFLGNBQWMsTUFBTSxHQUFHLDBCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRztBQUFBLFlBQ3RHLHVCQUFDLFNBQUksT0FBTyxFQUFFSixVQUFVLFFBQVFFLE9BQU8sb0JBQW9CLEdBQUcsNkRBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJHO0FBQUEsZUFGN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVJLFlBQVkseUJBQXlCRSxRQUFRLGlDQUFpQ0gsY0FBYyxPQUFPVCxTQUFTLE9BQU8sR0FDL0g7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRUksVUFBVSxRQUFRQyxZQUFZLE9BQU9DLE9BQU8sV0FBV0UsY0FBYyxNQUFNLEdBQUcsOEJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBHO0FBQUEsWUFDMUcsdUJBQUMsU0FBSSxPQUFPLEVBQUVKLFVBQVUsUUFBUUUsT0FBTyxvQkFBb0IsR0FBRyx1REFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUc7QUFBQSxlQUZ2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUksWUFBWSx5QkFBeUJFLFFBQVEsaUNBQWlDSCxjQUFjLE9BQU9ULFNBQVMsT0FBTyxHQUMvSDtBQUFBLG1DQUFDLFNBQUksT0FBTyxFQUFFSSxVQUFVLFFBQVFDLFlBQVksT0FBT0MsT0FBTyxXQUFXRSxjQUFjLE1BQU0sR0FBRyw0QkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0c7QUFBQSxZQUN4Ryx1QkFBQyxTQUFJLE9BQU8sRUFBRUosVUFBVSxRQUFRRSxPQUFPLG9CQUFvQixHQUFHLDBEQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLGVBRjFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlEQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTyxFQUFFTixTQUFTLFFBQVFILFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FDMUc7QUFBQSwrQkFBQyxRQUFHLE9BQU8sRUFBRUssVUFBVSxRQUFRQyxZQUFZLE9BQU9ULFFBQVEsR0FBR0MsU0FBUyxRQUFRSSxZQUFZLFVBQVVGLEtBQUssTUFBTSxHQUM3RztBQUFBLGlDQUFDLFlBQVMsTUFBTSxJQUFJLE9BQU0sb0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUE7QUFBQSxVQUNYbEIsYUFBYWlDLE1BQU1DLFVBQVU7QUFBQSxVQUFFO0FBQUEsYUFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQyxDQUFDbEMsYUFBYWlDLFFBQVFqQyxZQUFZaUMsS0FBS0MsV0FBVyxJQUNqRCx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsV0FBVyxVQUFVVixPQUFPLG1CQUFtQk4sU0FBUyxVQUFVSSxVQUFVLE9BQU8sR0FBRSxvR0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVQLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLFFBQVFrQixXQUFXLFNBQVNDLFdBQVcsT0FBTyxHQUN4R3JDLHNCQUFZaUMsS0FBS0s7QUFBQUEsVUFBSSxDQUFDQyxRQUNyQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBQ1YsT0FBTztBQUFBLGdCQUNMVixZQUFZO0FBQUEsZ0JBQ1pFLFFBQVE7QUFBQSxnQkFDUkgsY0FBYztBQUFBLGdCQUNkVCxTQUFTO0FBQUEsZ0JBQ1RILFNBQVM7QUFBQSxnQkFDVEMsZUFBZTtBQUFBLGdCQUNmQyxLQUFLO0FBQUEsY0FDUDtBQUFBLGNBRUE7QUFBQSx1Q0FBQyxTQUFJLE9BQU8sRUFBRUYsU0FBUyxRQUFRSyxnQkFBZ0IsaUJBQWlCRCxZQUFZLFNBQVMsR0FDbkY7QUFBQSx5Q0FBQyxTQUFJLE9BQU8sRUFBRUosU0FBUyxRQUFRSSxZQUFZLFVBQVVGLEtBQUssTUFBTSxHQUM5RDtBQUFBLDJDQUFDLFVBQUssV0FBVSxxQkFBcUJxQixjQUFJQyxTQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUMvQyx1QkFBQyxVQUFLLE9BQU8sRUFBRWpCLFVBQVUsUUFBUUUsT0FBT2MsSUFBSUUsV0FBVyxjQUFjLFlBQVksVUFBVSxHQUFFO0FBQUE7QUFBQSxzQkFDeEZGLElBQUlFO0FBQUFBLHlCQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVsQixVQUFVLFFBQVFFLE9BQU8sa0JBQWtCLEdBQ3ZELGNBQUlpQixLQUFLSCxJQUFJSSxTQUFTLEVBQUVDLG1CQUFtQixLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksT0FBTztBQUFBLGtCQUNWN0IsUUFBUTtBQUFBLGtCQUNSUSxVQUFVO0FBQUEsa0JBQ1ZzQixZQUFZO0FBQUEsa0JBQ1pwQixPQUFPO0FBQUEsa0JBQ1BJLFlBQVk7QUFBQSxrQkFDWlYsU0FBUztBQUFBLGtCQUNUUyxjQUFjO0FBQUEsa0JBQ2RrQixXQUFXO0FBQUEsZ0JBQ2IsR0FDR0MsZUFBS0MsVUFBVVQsSUFBSVUsU0FBUyxNQUFNLENBQUMsS0FWdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBO0FBQUE7QUFBQSxZQW5DS1YsSUFBSVc7QUFBQUEsWUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBcUNBO0FBQUEsUUFDRCxLQXhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsV0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQTtBQUFBLFNBOUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnSEE7QUFBQSxPQXBJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0lBO0FBRUo7QUFBQ25ELEdBL0pZRCxVQUFrQjtBQUFBLEtBQWxCQTtBQUFrQixJQUFBcUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJBcGlPcGVyYXRpb25zIiwiSHR0cEVycm9yUmVzcG9uc2UiLCJBY3Rpdml0eSIsIlJhZGlvIiwiUmVmcmVzaEN3IiwiQ2hlY2tDaXJjbGUyIiwiU2hpZWxkQWxlcnQiLCJLYWZrYVRhYiIsIl9zIiwia2Fma2FTdGF0dXMiLCJzZXRLYWZrYVN0YXR1cyIsImlzUmVmcmVzaGluZyIsInNldElzUmVmcmVzaGluZyIsImxvYWRTdGF0dXMiLCJkYXRhIiwiZmV0Y2hLYWZrYVN0YXR1cyIsImUiLCJjb25zb2xlIiwid2FybiIsIm1lc3NhZ2UiLCJpbnRlcnZhbCIsInNldEludGVydmFsIiwiY2xlYXJJbnRlcnZhbCIsIm1heFdpZHRoIiwibWFyZ2luIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJnYXAiLCJwYWRkaW5nIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZmxleFdyYXAiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvciIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJtYXJnaW5Cb3R0b20iLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwiY29ubmVjdGVkIiwiYm9yZGVyIiwib3BhY2l0eSIsImxvZ3MiLCJsZW5ndGgiLCJ0ZXh0QWxpZ24iLCJtYXhIZWlnaHQiLCJvdmVyZmxvd1kiLCJtYXAiLCJsb2ciLCJ0b3BpYyIsInN0YXR1cyIsIkRhdGUiLCJ0aW1lc3RhbXAiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJmb250RmFtaWx5Iiwib3ZlcmZsb3dYIiwiSlNPTiIsInN0cmluZ2lmeSIsInBheWxvYWQiLCJpZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkthZmthVGFiLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgS2Fma2FMb2csIEthZmthU3RhdHVzUmVzcG9uc2UgfSBmcm9tICdAL3R5cGVzJ1xuaW1wb3J0IHsgQXBpT3BlcmF0aW9ucyB9IGZyb20gJ0Avb3BlcmF0aW9ucy9hcGkub3BlcmF0aW9uJ1xuaW1wb3J0IHsgSHR0cEVycm9yUmVzcG9uc2UgfSBmcm9tICdAL3V0aWxzL2Vycm9ycydcbmltcG9ydCB7IEFjdGl2aXR5LCBSYWRpbywgRGF0YWJhc2UsIFJlZnJlc2hDdywgU2VuZCwgQ2hlY2tDaXJjbGUyLCBTaGllbGRBbGVydCwgU3BhcmtsZXMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5cbmV4cG9ydCBjb25zdCBLYWZrYVRhYjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IFtrYWZrYVN0YXR1cywgc2V0S2Fma2FTdGF0dXNdID0gdXNlU3RhdGU8S2Fma2FTdGF0dXNSZXNwb25zZSB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFtpc1JlZnJlc2hpbmcsIHNldElzUmVmcmVzaGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBsb2FkU3RhdHVzID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzUmVmcmVzaGluZyh0cnVlKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgQXBpT3BlcmF0aW9ucy5mZXRjaEthZmthU3RhdHVzKClcbiAgICAgIHNldEthZmthU3RhdHVzKGRhdGEpXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gbG9hZCBLYWZrYSBzdGF0dXM6JywgZSBpbnN0YW5jZW9mIEh0dHBFcnJvclJlc3BvbnNlID8gZS5tZXNzYWdlIDogZSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNSZWZyZXNoaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9hZFN0YXR1cygpXG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbChsb2FkU3RhdHVzLCA0MDAwKVxuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKVxuICB9LCBbXSlcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgbWF4V2lkdGg6ICcxMjAwcHgnLCBtYXJnaW46ICcwIGF1dG8nLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcyNHB4JyB9fT5cbiAgICAgIFxuICAgICAgey8qIFRvcCBCYW5uZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGZsZXhXcmFwOiAnd3JhcCcsIGdhcDogJzE2cHgnIH19PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBzdHlsZT17eyBmb250U2l6ZTogJzIwcHgnLCBmb250V2VpZ2h0OiAnNzAwJywgbWFyZ2luOiAnMCAwIDZweCAwJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnMTBweCcgfX0+XG4gICAgICAgICAgICA8QWN0aXZpdHkgY29sb3I9XCIjZjU5ZTBiXCIgLz5cbiAgICAgICAgICAgIEFwYWNoZSBLYWZrYSBFdmVudCBTdHJlYW1pbmcgSHViXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJywgbWFyZ2luOiAwIH19PlxuICAgICAgICAgICAgQXN5bmNocm9ub3VzIG1lc3NhZ2UgYnVzIHBvd2VyZWQgYnkgKiprYWZrYWpzKiouIE9mZmxvYWRzIEZpcmVjcmF3bCB3ZWIgaW5nZXN0aW9uIChgcmFnLmluZ2VzdGApLCB1c2VyIG1lbW9yeSBleHRyYWN0aW9uIChgbWVtb3J5LmV4dHJhY3RgKSwgYW5kIHNlYXJjaCBhdWRpdGluZyAoYHNlYXJjaC5hdWRpdGApLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCIgb25DbGljaz17bG9hZFN0YXR1c30gZGlzYWJsZWQ9e2lzUmVmcmVzaGluZ30+XG4gICAgICAgICAgPFJlZnJlc2hDdyBzaXplPXsxNn0gY2xhc3NOYW1lPXtpc1JlZnJlc2hpbmcgPyAnYW5pbWF0ZS1zcGluJyA6ICcnfSAvPlxuICAgICAgICAgIFJlZnJlc2ggVG9waWNzICYgTG9nc1xuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzMyMHB4IDFmcicsIGdhcDogJzI0cHgnIH19PlxuICAgICAgICBcbiAgICAgICAgey8qIFN0YXR1cyAmIFRvcGljIFN1bW1hcnkgU2lkZWJhciAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxNnB4JyB9fT5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogQ29ubmVjdGlvbiBTdGF0dXMgQ2FyZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAnMjBweCcgfX0+XG4gICAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgZm9udFdlaWdodDogJzcwMCcsIG1hcmdpbkJvdHRvbTogJzEycHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxuICAgICAgICAgICAgICA8UmFkaW8gc2l6ZT17MTZ9IGNvbG9yPVwiI2Y1OWUwYlwiIC8+IEJyb2tlciBTdGF0dXNcbiAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcbiAgICAgICAgICAgICAgcGFkZGluZzogJzEycHgnLFxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBrYWZrYVN0YXR1cz8uY29ubmVjdGVkID8gJ3JnYmEoMTYsIDE4NSwgMTI5LCAwLjE1KScgOiAncmdiYSgyNDUsIDE1OCwgMTEsIDAuMTUpJyxcbiAgICAgICAgICAgICAgYm9yZGVyOiBrYWZrYVN0YXR1cz8uY29ubmVjdGVkID8gJzFweCBzb2xpZCByZ2JhKDE2LCAxODUsIDEyOSwgMC4zKScgOiAnMXB4IHNvbGlkIHJnYmEoMjQ1LCAxNTgsIDExLCAwLjMpJyxcbiAgICAgICAgICAgICAgY29sb3I6IGthZmthU3RhdHVzPy5jb25uZWN0ZWQgPyAnIzZlZTdiNycgOiAnI2ZjZDM0ZCcsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAnMTNweCcsXG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgICAgIGdhcDogJzhweCdcbiAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICB7a2Fma2FTdGF0dXM/LmNvbm5lY3RlZCA/IDxDaGVja0NpcmNsZTIgc2l6ZT17MTh9IC8+IDogPFNoaWVsZEFsZXJ0IHNpemU9ezE4fSAvPn1cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRXZWlnaHQ6ICc2MDAnIH19PntrYWZrYVN0YXR1cz8uY29ubmVjdGVkID8gJ0thZmthIENvbm5lY3RlZCcgOiAnRXZlbnQgU3RyZWFtIEFjdGl2ZSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzExcHgnLCBvcGFjaXR5OiAwLjggfX0+XG4gICAgICAgICAgICAgICAgICB7a2Fma2FTdGF0dXM/LmNvbm5lY3RlZCA/ICdDbHVzdGVyOiBrYWZrYToyOTA5MicgOiAnTG9jYWwgRmFsbGJhY2sgTG9nZ2VyJ31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUb3BpY3MgQ2FyZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAnMjBweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzEycHgnIH19PlxuICAgICAgICAgICAgPGgzIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGZvbnRXZWlnaHQ6ICc3MDAnLCBtYXJnaW46IDAgfX0+QWN0aXZlIEthZmthIFRvcGljczwvaDM+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMTMsIDIxLCAzOSwgMC44KScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgYm9yZGVyUmFkaXVzOiAnOHB4JywgcGFkZGluZzogJzEwcHgnIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTJweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBjb2xvcjogJyM2N2U4ZjknLCBtYXJnaW5Cb3R0b206ICc0cHgnIH19PnJhZy5pbmdlc3Q8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzExcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJyB9fT5Bc3luYyBGaXJlY3Jhd2wgd2ViIGNyYXdsaW5nICYgdmVjdG9yIHN0b3JhZ2U8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmQ6ICdyZ2JhKDEzLCAyMSwgMzksIDAuOCknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tYm9yZGVyLWNvbG9yKScsIGJvcmRlclJhZGl1czogJzhweCcsIHBhZGRpbmc6ICcxMHB4JyB9fT5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEycHgnLCBmb250V2VpZ2h0OiAnNjAwJywgY29sb3I6ICcjYTViNGZjJywgbWFyZ2luQm90dG9tOiAnNHB4JyB9fT5tZW1vcnkuZXh0cmFjdDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tdXRlZCknIH19PkJhY2tncm91bmQgWm9kIG1lbW9yeSBleHRyYWN0aW9uIHdvcmtlcjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JnYmEoMTMsIDIxLCAzOSwgMC44KScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJywgYm9yZGVyUmFkaXVzOiAnOHB4JywgcGFkZGluZzogJzEwcHgnIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTJweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBjb2xvcjogJyM2ZWU3YjcnLCBtYXJnaW5Cb3R0b206ICc0cHgnIH19PnNlYXJjaC5hdWRpdDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiAndmFyKC0tdGV4dC1tdXRlZCknIH19PlRhdmlseSB3ZWIgZ3JvdW5kaW5nICYgUkFHIHF1ZXJ5IGF1ZGl0IGxvZzwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJlYWwtdGltZSBTdHJlYW1pbmcgTG9ncyBGZWVkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmRcIiBzdHlsZT17eyBwYWRkaW5nOiAnMjRweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzE2cHgnIH19PlxuICAgICAgICAgIDxoMyBzdHlsZT17eyBmb250U2l6ZTogJzE2cHgnLCBmb250V2VpZ2h0OiAnNzAwJywgbWFyZ2luOiAwLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxuICAgICAgICAgICAgPEFjdGl2aXR5IHNpemU9ezE4fSBjb2xvcj1cInZhcigtLXByaW1hcnkpXCIgLz5cbiAgICAgICAgICAgIFJlYWwtVGltZSBLYWZrYSBFdmVudCBTdHJlYW0gKHtrYWZrYVN0YXR1cz8ubG9ncz8ubGVuZ3RoIHx8IDB9IGV2ZW50cylcbiAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgeyFrYWZrYVN0YXR1cz8ubG9ncyB8fCBrYWZrYVN0YXR1cy5sb2dzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgY29sb3I6ICd2YXIoLS10ZXh0LWRpbSknLCBwYWRkaW5nOiAnNjBweCAwJywgZm9udFNpemU6ICcxM3B4JyB9fT5cbiAgICAgICAgICAgICAgTm8gS2Fma2EgZXZlbnRzIHN0cmVhbWVkIHlldC4gU2VuZCBhIGNoYXQgbWVzc2FnZSBvciBzY3JhcGUgYSBVUkwgdG8gcHJvZHVjZSBldmVudHMhXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxMHB4JywgbWF4SGVpZ2h0OiAnNTIwcHgnLCBvdmVyZmxvd1k6ICdhdXRvJyB9fT5cbiAgICAgICAgICAgICAge2thZmthU3RhdHVzLmxvZ3MubWFwKChsb2cpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2xvZy5pZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtZmFkZS1pblwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAncmdiYSgxMywgMjEsIDM5LCAwLjg1KScsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXItY29sb3IpJyxcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICcxNHB4JyxcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICAgICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiAnOHB4J1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiYWRnZS1hbWJlclwiPntsb2cudG9waWN9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMTFweCcsIGNvbG9yOiBsb2cuc3RhdHVzID09PSAncHVibGlzaGVkJyA/ICcjNmVlN2I3JyA6ICcjYTViNGZjJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICAgIOKXjyB7bG9nLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzEwcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScgfX0+XG4gICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGxvZy50aW1lc3RhbXApLnRvTG9jYWxlVGltZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPHByZSBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDAsXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMTFweCcsXG4gICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6ICd2YXIoLS1mb250LW1vbm8pJyxcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjZjhmYWZjJyxcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMCwwLDAsMC40KScsXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6ICc4cHgnLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc2cHgnLFxuICAgICAgICAgICAgICAgICAgICBvdmVyZmxvd1g6ICdhdXRvJ1xuICAgICAgICAgICAgICAgICAgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtKU09OLnN0cmluZ2lmeShsb2cucGF5bG9hZCwgbnVsbCwgMil9XG4gICAgICAgICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cblxuICAgIDwvZGl2PlxuICApXG59XG4iXSwiZmlsZSI6IkM6L25vZGUvbGxtL2NsaWVudC9zcmMvdmlld3MvS2Fma2FUYWIudHN4In0=