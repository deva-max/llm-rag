import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Outlet, useNavigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=90a7bf15";
import { ApiOperations } from "/src/operations/api.operation.ts";
import { Navigation } from "/src/views/Navigation.tsx";
const App = () => {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const [creds, setCreds] = useState(() => {
    const saved = localStorage.getItem("rag_api_credentials");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
      }
    }
    return {
      supabaseUrl: "",
      supabaseKey: "",
      openaiApiKey: "",
      firecrawlApiKey: "",
      tavilyApiKey: ""
    };
  });
  const [configStatus, setConfigStatus] = useState(null);
  const refreshStatus = async () => {
    try {
      const status = await ApiOperations.fetchConfigStatus();
      setConfigStatus(status);
    } catch (e) {
      console.warn("Failed to fetch status:", e);
    }
  };
  useEffect(() => {
    refreshStatus();
  }, [creds]);
  const activeTab = location.pathname.replace("/", "") || "chat";
  const handleSelectTab = (tab) => {
    if (tab === "chat") navigate("/");
    else
      navigate(`/${tab}`);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { minHeight: "100vh", display: "flex", flexDirection: "column" }, children: [
    /* @__PURE__ */ jsxDEV(
      Navigation,
      {
        activeTab,
        onSelectTab: handleSelectTab,
        configStatus
      },
      void 0,
      false,
      {
        fileName: "C:/node/llm/client/src/App.tsx",
        lineNumber: 69,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("main", { style: { flex: 1, padding: "0 24px 32px", maxWidth: "1400px", margin: "0 auto", width: "100%" }, children: /* @__PURE__ */ jsxDEV(Outlet, { context: { creds, setCreds, configStatus, refreshStatus } }, void 0, false, {
      fileName: "C:/node/llm/client/src/App.tsx",
      lineNumber: 75,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/node/llm/client/src/App.tsx",
      lineNumber: 74,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/App.tsx",
    lineNumber: 68,
    columnNumber: 5
  }, this);
};
_s(App, "CXcID/1Vlzsd0jkX57YBiB8jgOk=", false, function() {
  return [useNavigate, useLocation];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpETixTQUFnQkEsVUFBVUMsaUJBQWlCO0FBQzNDLFNBQVNDLFFBQVFDLGFBQWFDLG1CQUFtQjtBQUVqRCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msa0JBQWtCO0FBRTNCLE1BQU1DLE1BQWdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUIsUUFBTUMsV0FBV04sWUFBWTtBQUM3QixRQUFNTyxXQUFXTixZQUFZO0FBRTdCLFFBQU0sQ0FBQ08sT0FBT0MsUUFBUSxJQUFJWixTQUF5QixNQUFNO0FBQ3ZELFVBQU1hLFFBQVFDLGFBQWFDLFFBQVEscUJBQXFCO0FBQ3hELFFBQUlGLE9BQU87QUFDVCxVQUFJO0FBQUUsZUFBT0csS0FBS0MsTUFBTUosS0FBSztBQUFBLE1BQUUsU0FBU0ssR0FBRztBQUFBLE1BQUM7QUFBQSxJQUM5QztBQUNBLFdBQU87QUFBQSxNQUNMQyxhQUFhO0FBQUEsTUFDYkMsYUFBYTtBQUFBLE1BQ2JDLGNBQWM7QUFBQSxNQUNkQyxpQkFBaUI7QUFBQSxNQUNqQkMsY0FBYztBQUFBLElBQ2hCO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUl6QixTQUE4QixJQUFJO0FBRTFFLFFBQU0wQixnQkFBZ0IsWUFBWTtBQUNoQyxRQUFJO0FBRUYsWUFBTUMsU0FBUyxNQUFNdEIsY0FBY3VCLGtCQUFrQjtBQUNyREgsc0JBQWdCRSxNQUFNO0FBQUEsSUFDeEIsU0FBU1QsR0FBRztBQUNWVyxjQUFRQyxLQUFLLDJCQUEyQlosQ0FBQztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBakIsWUFBVSxNQUFNO0FBQ2R5QixrQkFBYztBQUFBLEVBQ2hCLEdBQUcsQ0FBQ2YsS0FBSyxDQUFDO0FBR1YsUUFBTW9CLFlBQXNCckIsU0FBU3NCLFNBQVNDLFFBQVEsS0FBSyxFQUFFLEtBQUs7QUFFbEUsUUFBTUMsa0JBQWtCQSxDQUFDQyxRQUFpQjtBQUN4QyxRQUFJQSxRQUFRLE9BQVExQixVQUFTLEdBQUc7QUFBQTtBQUMzQkEsZUFBUyxJQUFJMEIsR0FBRyxFQUFFO0FBQUEsRUFDekI7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFQyxXQUFXLFNBQVNDLFNBQVMsUUFBUUMsZUFBZSxTQUFTLEdBQ3pFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxhQUFhSjtBQUFBQSxRQUNiO0FBQUE7QUFBQSxNQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUc2QjtBQUFBLElBRTdCLHVCQUFDLFVBQUssT0FBTyxFQUFFSyxNQUFNLEdBQUdDLFNBQVMsZUFBZUMsVUFBVSxVQUFVQyxRQUFRLFVBQVVDLE9BQU8sT0FBTyxHQUNsRyxpQ0FBQyxVQUFPLFNBQVMsRUFBRWhDLE9BQU9DLFVBQVVZLGNBQWNFLGNBQWMsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRSxLQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNsQixHQXJES0QsS0FBYTtBQUFBLFVBQ0FKLGFBQ0FDLFdBQVc7QUFBQTtBQUFBLEtBRnhCRztBQXVETixlQUFlQTtBQUFHLElBQUFxQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIk91dGxldCIsInVzZU5hdmlnYXRlIiwidXNlTG9jYXRpb24iLCJBcGlPcGVyYXRpb25zIiwiTmF2aWdhdGlvbiIsIkFwcCIsIl9zIiwibmF2aWdhdGUiLCJsb2NhdGlvbiIsImNyZWRzIiwic2V0Q3JlZHMiLCJzYXZlZCIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJlIiwic3VwYWJhc2VVcmwiLCJzdXBhYmFzZUtleSIsIm9wZW5haUFwaUtleSIsImZpcmVjcmF3bEFwaUtleSIsInRhdmlseUFwaUtleSIsImNvbmZpZ1N0YXR1cyIsInNldENvbmZpZ1N0YXR1cyIsInJlZnJlc2hTdGF0dXMiLCJzdGF0dXMiLCJmZXRjaENvbmZpZ1N0YXR1cyIsImNvbnNvbGUiLCJ3YXJuIiwiYWN0aXZlVGFiIiwicGF0aG5hbWUiLCJyZXBsYWNlIiwiaGFuZGxlU2VsZWN0VGFiIiwidGFiIiwibWluSGVpZ2h0IiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJmbGV4IiwicGFkZGluZyIsIm1heFdpZHRoIiwibWFyZ2luIiwid2lkdGgiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBPdXRsZXQsIHVzZU5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBBcGlDcmVkZW50aWFscywgQ29uZmlnU3RhdHVzLCBUYWJUeXBlIH0gZnJvbSAnQC90eXBlcydcbmltcG9ydCB7IEFwaU9wZXJhdGlvbnMgfSBmcm9tICdAL29wZXJhdGlvbnMvYXBpLm9wZXJhdGlvbidcbmltcG9ydCB7IE5hdmlnYXRpb24gfSBmcm9tICdAL3ZpZXdzL05hdmlnYXRpb24nXG5cbmNvbnN0IEFwcDogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgXG4gIGNvbnN0IFtjcmVkcywgc2V0Q3JlZHNdID0gdXNlU3RhdGU8QXBpQ3JlZGVudGlhbHM+KCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdyYWdfYXBpX2NyZWRlbnRpYWxzJylcbiAgICBpZiAoc2F2ZWQpIHtcbiAgICAgIHRyeSB7IHJldHVybiBKU09OLnBhcnNlKHNhdmVkKSB9IGNhdGNoIChlKSB7fVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgc3VwYWJhc2VVcmw6ICcnLFxuICAgICAgc3VwYWJhc2VLZXk6ICcnLFxuICAgICAgb3BlbmFpQXBpS2V5OiAnJyxcbiAgICAgIGZpcmVjcmF3bEFwaUtleTogJycsXG4gICAgICB0YXZpbHlBcGlLZXk6ICcnXG4gICAgfVxuICB9KVxuICBjb25zdCBbY29uZmlnU3RhdHVzLCBzZXRDb25maWdTdGF0dXNdID0gdXNlU3RhdGU8Q29uZmlnU3RhdHVzIHwgbnVsbD4obnVsbClcblxuICBjb25zdCByZWZyZXNoU3RhdHVzID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICAvLyBJbiBhIHJlYWwgYXBwIHdlIG1pZ2h0IHBhc3MgY3JlZHMgaW4gaGVhZGVycyB2aWEgQXhpb3MgaW50ZXJjZXB0b3IsIGJ1dCBoZXJlIHdlIHNldCB0aGVtIGluIGxvY2Fsc3RvcmFnZSBmb3IgdGhlIGJhY2tlbmRcbiAgICAgIGNvbnN0IHN0YXR1cyA9IGF3YWl0IEFwaU9wZXJhdGlvbnMuZmV0Y2hDb25maWdTdGF0dXMoKVxuICAgICAgc2V0Q29uZmlnU3RhdHVzKHN0YXR1cylcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0ZhaWxlZCB0byBmZXRjaCBzdGF0dXM6JywgZSlcbiAgICB9XG4gIH1cblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlZnJlc2hTdGF0dXMoKVxuICB9LCBbY3JlZHNdKVxuXG4gIC8vIERlcml2ZSBhY3RpdmUgdGFiIGZyb20gbG9jYXRpb24gcGF0aG5hbWVcbiAgY29uc3QgYWN0aXZlVGFiOiBUYWJUeXBlID0gKGxvY2F0aW9uLnBhdGhuYW1lLnJlcGxhY2UoJy8nLCAnJykgfHwgJ2NoYXQnKSBhcyBUYWJUeXBlXG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0VGFiID0gKHRhYjogVGFiVHlwZSkgPT4ge1xuICAgIGlmICh0YWIgPT09ICdjaGF0JykgbmF2aWdhdGUoJy8nKVxuICAgIGVsc2UgbmF2aWdhdGUoYC8ke3RhYn1gKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IG1pbkhlaWdodDogJzEwMHZoJywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyB9fT5cbiAgICAgIDxOYXZpZ2F0aW9uXG4gICAgICAgIGFjdGl2ZVRhYj17YWN0aXZlVGFifVxuICAgICAgICBvblNlbGVjdFRhYj17aGFuZGxlU2VsZWN0VGFifVxuICAgICAgICBjb25maWdTdGF0dXM9e2NvbmZpZ1N0YXR1c31cbiAgICAgIC8+XG4gICAgICA8bWFpbiBzdHlsZT17eyBmbGV4OiAxLCBwYWRkaW5nOiAnMCAyNHB4IDMycHgnLCBtYXhXaWR0aDogJzE0MDBweCcsIG1hcmdpbjogJzAgYXV0bycsIHdpZHRoOiAnMTAwJScgfX0+XG4gICAgICAgIDxPdXRsZXQgY29udGV4dD17eyBjcmVkcywgc2V0Q3JlZHMsIGNvbmZpZ1N0YXR1cywgcmVmcmVzaFN0YXR1cyB9fSAvPlxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuXG4iXSwiZmlsZSI6IkM6L25vZGUvbGxtL2NsaWVudC9zcmMvQXBwLnRzeCJ9