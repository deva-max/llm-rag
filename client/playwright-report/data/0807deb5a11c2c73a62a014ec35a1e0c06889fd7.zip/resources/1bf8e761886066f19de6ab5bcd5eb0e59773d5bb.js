import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/TavilyTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/TavilyTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"];
import { ApiOperations } from "/src/operations/api.operation.ts";
import { HttpErrorResponse } from "/src/utils/errors.ts";
import { Search, Sparkles, ExternalLink, ShieldCheck, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
export const TavilyTab = () => {
  _s();
  const [query, setQuery] = useState("FreeAcademy memory and context RAG module");
  const [searchDepth, setSearchDepth] = useState("basic");
  const [maxResults, setMaxResults] = useState(5);
  const [isLoading, setIsLoading] = useState(false);
  const [searchResults, setSearchResults] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim() || isLoading) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const res = await ApiOperations.searchTavily(query, searchDepth, maxResults);
      setSearchResults(res);
    } catch (err) {
      const message = err instanceof HttpErrorResponse ? err.message : "Tavily search failed";
      setErrorMsg(message);
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1200px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "24px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "20px", fontWeight: "700", margin: "0 0 6px 0", display: "flex", alignItems: "center", gap: "10px" }, children: [
        /* @__PURE__ */ jsxDEV(Search, { color: "var(--accent-emerald)" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
          lineNumber: 58,
          columnNumber: 11
        }, this),
        "Tavily AI Web Search Grounding Studio"
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "13px", color: "var(--text-muted)", margin: 0 }, children: "Execute real-time web search tuned for LLMs and RAG agents via **Tavily**. Retrieves search content, citations, and AI syntheses for fresh web facts." }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSearch, style: { marginTop: "20px", display: "flex", flexDirection: "column", gap: "16px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "12px" }, children: [
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              className: "glass-input",
              style: { flex: 1 },
              placeholder: "Search query for live web grounding...",
              value: query,
              onChange: (e) => setQuery(e.target.value),
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 68,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "submit", disabled: isLoading, children: [
            isLoading ? /* @__PURE__ */ jsxDEV(Sparkles, { className: "animate-spin", size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 77,
              columnNumber: 28
            }, this) : /* @__PURE__ */ jsxDEV(Zap, { size: 16 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 77,
              columnNumber: 78
            }, this),
            isLoading ? "Searching Tavily..." : "Execute AI Search"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
            lineNumber: 76,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
          lineNumber: 67,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", gap: "20px", fontSize: "12px", color: "var(--text-muted)" }, children: [
          /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "6px" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Search Depth:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 84,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "glass-input",
                style: { padding: "4px 8px", fontSize: "12px" },
                value: searchDepth,
                onChange: (e) => setSearchDepth(e.target.value),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "basic", children: "Basic (Fast)" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                    lineNumber: 91,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "advanced", children: "Advanced (Deep Crawl)" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                    lineNumber: 92,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                lineNumber: 85,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
            lineNumber: 83,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", alignItems: "center", gap: "6px" }, children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Max Results:" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 97,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                className: "glass-input",
                style: { padding: "4px 8px", fontSize: "12px" },
                value: maxResults,
                onChange: (e) => setMaxResults(Number(e.target.value)),
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: 3, children: "3 Results" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                    lineNumber: 104,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: 5, children: "5 Results" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                    lineNumber: 105,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: 8, children: "8 Results" }, void 0, false, {
                    fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                    lineNumber: 106,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                lineNumber: 98,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
            lineNumber: 96,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
          lineNumber: 82,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    errorMsg && /* @__PURE__ */ jsxDEV("div", { style: { padding: "16px", borderRadius: "12px", background: "rgba(239, 68, 68, 0.15)", border: "1px solid rgba(239, 68, 68, 0.3)", color: "#fca5a5", fontSize: "13px" }, children: [
      "⚠️ ",
      errorMsg
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this),
    searchResults && /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
      searchResults.answer && /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "20px", borderLeft: "4px solid var(--accent-emerald)" }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "14px", color: "#6ee7b7", margin: "0 0 8px 0", display: "flex", alignItems: "center", gap: "6px" }, children: [
          /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 16 }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
            lineNumber: 127,
            columnNumber: 17
          }, this),
          " Tavily AI Synthesized Summary"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
          lineNumber: 126,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "14px", lineHeight: "1.6", margin: 0 }, children: searchResults.answer }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
          lineNumber: 129,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
        lineNumber: 125,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))", gap: "16px" }, children: searchResults.results.map(
        (item, idx) => /* @__PURE__ */ jsxDEV("div", { className: "glass-card animate-fade-in", style: { padding: "18px", display: "flex", flexDirection: "column", justifyContent: "space-between" }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "8px", marginBottom: "8px" }, children: [
              /* @__PURE__ */ jsxDEV(
                "a",
                {
                  href: item.url,
                  target: "_blank",
                  rel: "noreferrer",
                  style: { fontSize: "14px", fontWeight: "700", color: "#67e8f9", textDecoration: "none", display: "flex", alignItems: "center", gap: "6px" },
                  children: [
                    item.title,
                    " ",
                    /* @__PURE__ */ jsxDEV(ExternalLink, { size: 12 }, void 0, false, {
                      fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                      lineNumber: 147,
                      columnNumber: 36
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                  lineNumber: 141,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "badge badge-emerald", children: [
                (item.score * 100).toFixed(0),
                "% Score"
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
                lineNumber: 149,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 140,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "12px", color: "var(--text-muted)", lineHeight: "1.5", margin: 0 }, children: item.content }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
              lineNumber: 151,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
            lineNumber: 139,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: { marginTop: "12px", fontSize: "10px", color: "var(--text-dim)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: item.url }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
            lineNumber: 155,
            columnNumber: 17
          }, this)
        ] }, idx, true, {
          fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
          lineNumber: 138,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
        lineNumber: 136,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/TavilyTab.tsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
};
_s(TavilyTab, "neI8s6q6xY5VdrdnVE0IA40wCDk=");
_c = TavilyTab;
var _c;
$RefreshReg$(_c, "TavilyTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/TavilyTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/TavilyTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRDVixTQUFnQkEsZ0JBQWdCO0FBRWhDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsUUFBZUMsVUFBVUMsY0FBY0MsYUFBYUMsV0FBVztBQUVqRSxhQUFNQyxZQUFzQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWCxTQUFTLDJDQUEyQztBQUM5RSxRQUFNLENBQUNZLGFBQWFDLGNBQWMsSUFBSWIsU0FBK0IsT0FBTztBQUM1RSxRQUFNLENBQUNjLFlBQVlDLGFBQWEsSUFBSWYsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2dCLFdBQVdDLFlBQVksSUFBSWpCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNrQixlQUFlQyxnQkFBZ0IsSUFBSW5CLFNBQWlGLElBQUk7QUFDL0gsUUFBTSxDQUFDb0IsVUFBVUMsV0FBVyxJQUFJckIsU0FBd0IsSUFBSTtBQUU1RCxRQUFNc0IsZUFBZSxPQUFPQyxNQUF1QjtBQUNqREEsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNkLE1BQU1lLEtBQUssS0FBS1QsVUFBVztBQUVoQ0MsaUJBQWEsSUFBSTtBQUNqQkksZ0JBQVksSUFBSTtBQUVoQixRQUFJO0FBQ0YsWUFBTUssTUFBTSxNQUFNekIsY0FBYzBCLGFBQWFqQixPQUFPRSxhQUFhRSxVQUFVO0FBQzNFSyx1QkFBaUJPLEdBQUc7QUFBQSxJQUN0QixTQUFTRSxLQUFLO0FBQ1osWUFBTUMsVUFBVUQsZUFBZTFCLG9CQUFvQjBCLElBQUlDLFVBQVU7QUFDakVSLGtCQUFZUSxPQUFPO0FBQUEsSUFDckIsVUFBQztBQUNDWixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU8sRUFBRWEsVUFBVSxVQUFVQyxRQUFRLFVBQVVDLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FHeEc7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPLEVBQUVDLFNBQVMsT0FBTyxHQUNuRDtBQUFBLDZCQUFDLFFBQUcsT0FBTyxFQUFFQyxVQUFVLFFBQVFDLFlBQVksT0FBT04sUUFBUSxhQUFhQyxTQUFTLFFBQVFNLFlBQVksVUFBVUosS0FBSyxPQUFPLEdBQ3hIO0FBQUEsK0JBQUMsVUFBTyxPQUFNLDJCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQTtBQUFBLFdBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVFLFVBQVUsUUFBUUcsT0FBTyxxQkFBcUJSLFFBQVEsRUFBRSxHQUFFLHFLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUdBLHVCQUFDLFVBQUssVUFBVVQsY0FBYyxPQUFPLEVBQUVrQixXQUFXLFFBQVFSLFNBQVMsUUFBUUMsZUFBZSxVQUFVQyxLQUFLLE9BQU8sR0FDOUc7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRUYsU0FBUyxRQUFRRSxLQUFLLE9BQU8sR0FDekM7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFTyxNQUFNLEVBQUU7QUFBQSxjQUNqQixhQUFZO0FBQUEsY0FDWixPQUFPL0I7QUFBQUEsY0FDUCxVQUFVLENBQUNhLE1BQU1aLFNBQVNZLEVBQUVtQixPQUFPQyxLQUFLO0FBQUEsY0FDeEMsVUFBUTtBQUFBO0FBQUEsWUFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNVTtBQUFBLFVBRVYsdUJBQUMsWUFBTyxXQUFVLGVBQWMsTUFBSyxVQUFTLFVBQVUzQixXQUNyREE7QUFBQUEsd0JBQVksdUJBQUMsWUFBUyxXQUFVLGdCQUFlLE1BQU0sTUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEMsSUFBTSx1QkFBQyxPQUFJLE1BQU0sTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFDNUVBLFlBQVksd0JBQXdCO0FBQUEsZUFGdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRWdCLFNBQVMsUUFBUUUsS0FBSyxRQUFRRSxVQUFVLFFBQVFHLE9BQU8sb0JBQW9CLEdBQ3ZGO0FBQUEsaUNBQUMsV0FBTSxPQUFPLEVBQUVQLFNBQVMsUUFBUU0sWUFBWSxVQUFVSixLQUFLLE1BQU0sR0FDaEU7QUFBQSxtQ0FBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1CO0FBQUEsWUFDbkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFQyxTQUFTLFdBQVdDLFVBQVUsT0FBTztBQUFBLGdCQUM5QyxPQUFPeEI7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDVyxNQUFNVixlQUFlVSxFQUFFbUIsT0FBT0MsS0FBWTtBQUFBLGdCQUVyRDtBQUFBLHlDQUFDLFlBQU8sT0FBTSxTQUFRLDRCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQztBQUFBLGtCQUNsQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyxxQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQTtBQUFBO0FBQUEsY0FQaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFdBQU0sT0FBTyxFQUFFWCxTQUFTLFFBQVFNLFlBQVksVUFBVUosS0FBSyxNQUFNLEdBQ2hFO0FBQUEsbUNBQUMsVUFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQjtBQUFBLFlBQ2xCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRUMsU0FBUyxXQUFXQyxVQUFVLE9BQU87QUFBQSxnQkFDOUMsT0FBT3RCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ1MsTUFBTVIsY0FBYzZCLE9BQU9yQixFQUFFbUIsT0FBT0MsS0FBSyxDQUFDO0FBQUEsZ0JBRXJEO0FBQUEseUNBQUMsWUFBTyxPQUFPLEdBQUcseUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzNCLHVCQUFDLFlBQU8sT0FBTyxHQUFHLHlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBLGtCQUMzQix1QkFBQyxZQUFPLE9BQU8sR0FBRyx5QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQTtBQUFBO0FBQUEsY0FSN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsV0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQTtBQUFBLFNBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REE7QUFBQSxJQUVDdkIsWUFDQyx1QkFBQyxTQUFJLE9BQU8sRUFBRWUsU0FBUyxRQUFRVSxjQUFjLFFBQVFDLFlBQVksMkJBQTJCQyxRQUFRLG9DQUFvQ1IsT0FBTyxXQUFXSCxVQUFVLE9BQU8sR0FBRTtBQUFBO0FBQUEsTUFDdktoQjtBQUFBQSxTQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBSURGLGlCQUNDLHVCQUFDLFNBQUksT0FBTyxFQUFFYyxTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxPQUFPLEdBR2pFaEI7QUFBQUEsb0JBQWM4QixVQUNiLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRWIsU0FBUyxRQUFRYyxZQUFZLGtDQUFrQyxHQUNsRztBQUFBLCtCQUFDLFFBQUcsT0FBTyxFQUFFYixVQUFVLFFBQVFHLE9BQU8sV0FBV1IsUUFBUSxhQUFhQyxTQUFTLFFBQVFNLFlBQVksVUFBVUosS0FBSyxNQUFNLEdBQ3RIO0FBQUEsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsVUFBRztBQUFBLGFBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVFLFVBQVUsUUFBUWMsWUFBWSxPQUFPbkIsUUFBUSxFQUFFLEdBQ3hEYix3QkFBYzhCLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFJRix1QkFBQyxTQUFJLE9BQU8sRUFBRWhCLFNBQVMsUUFBUW1CLHFCQUFxQix3Q0FBd0NqQixLQUFLLE9BQU8sR0FDckdoQix3QkFBY2tDLFFBQVFDO0FBQUFBLFFBQUksQ0FBQ0MsTUFBTUMsUUFDaEMsdUJBQUMsU0FBYyxXQUFVLDhCQUE2QixPQUFPLEVBQUVwQixTQUFTLFFBQVFILFNBQVMsUUFBUUMsZUFBZSxVQUFVdUIsZ0JBQWdCLGdCQUFnQixHQUN4SjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRXhCLFNBQVMsUUFBUXdCLGdCQUFnQixpQkFBaUJsQixZQUFZLGNBQWNKLEtBQUssT0FBT3VCLGNBQWMsTUFBTSxHQUN4SDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU1ILEtBQUtJO0FBQUFBLGtCQUNYLFFBQU87QUFBQSxrQkFDUCxLQUFJO0FBQUEsa0JBQ0osT0FBTyxFQUFFdEIsVUFBVSxRQUFRQyxZQUFZLE9BQU9FLE9BQU8sV0FBV29CLGdCQUFnQixRQUFRM0IsU0FBUyxRQUFRTSxZQUFZLFVBQVVKLEtBQUssTUFBTTtBQUFBLGtCQUV6SW9CO0FBQUFBLHlCQUFLTTtBQUFBQSxvQkFBTTtBQUFBLG9CQUFDLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUI7QUFBQTtBQUFBO0FBQUEsZ0JBTnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsdUJBQXdCTjtBQUFBQSxzQkFBS08sUUFBUSxLQUFLQyxRQUFRLENBQUM7QUFBQSxnQkFBRTtBQUFBLG1CQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBLGlCQVQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLE9BQU8sRUFBRTFCLFVBQVUsUUFBUUcsT0FBTyxxQkFBcUJXLFlBQVksT0FBT25CLFFBQVEsRUFBRSxHQUNwRnVCLGVBQUtTLFdBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV2QixXQUFXLFFBQVFKLFVBQVUsUUFBUUcsT0FBTyxtQkFBbUJ5QixVQUFVLFVBQVVDLGNBQWMsWUFBWUMsWUFBWSxTQUFTLEdBQzdJWixlQUFLSSxPQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQW5CUUgsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsTUFDRCxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsU0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlDQTtBQUFBLE9BN0dKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnSEE7QUFFSjtBQUFDOUMsR0E3SVlELFdBQW1CO0FBQUEsS0FBbkJBO0FBQW1CLElBQUEyRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkFwaU9wZXJhdGlvbnMiLCJIdHRwRXJyb3JSZXNwb25zZSIsIlNlYXJjaCIsIlNwYXJrbGVzIiwiRXh0ZXJuYWxMaW5rIiwiU2hpZWxkQ2hlY2siLCJaYXAiLCJUYXZpbHlUYWIiLCJfcyIsInF1ZXJ5Iiwic2V0UXVlcnkiLCJzZWFyY2hEZXB0aCIsInNldFNlYXJjaERlcHRoIiwibWF4UmVzdWx0cyIsInNldE1heFJlc3VsdHMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWFyY2hSZXN1bHRzIiwic2V0U2VhcmNoUmVzdWx0cyIsImVycm9yTXNnIiwic2V0RXJyb3JNc2ciLCJoYW5kbGVTZWFyY2giLCJlIiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwicmVzIiwic2VhcmNoVGF2aWx5IiwiZXJyIiwibWVzc2FnZSIsIm1heFdpZHRoIiwibWFyZ2luIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJnYXAiLCJwYWRkaW5nIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiYWxpZ25JdGVtcyIsImNvbG9yIiwibWFyZ2luVG9wIiwiZmxleCIsInRhcmdldCIsInZhbHVlIiwiTnVtYmVyIiwiYm9yZGVyUmFkaXVzIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImFuc3dlciIsImJvcmRlckxlZnQiLCJsaW5lSGVpZ2h0IiwiZ3JpZFRlbXBsYXRlQ29sdW1ucyIsInJlc3VsdHMiLCJtYXAiLCJpdGVtIiwiaWR4IiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5Cb3R0b20iLCJ1cmwiLCJ0ZXh0RGVjb3JhdGlvbiIsInRpdGxlIiwic2NvcmUiLCJ0b0ZpeGVkIiwiY29udGVudCIsIm92ZXJmbG93IiwidGV4dE92ZXJmbG93Iiwid2hpdGVTcGFjZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRhdmlseVRhYi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBBcGlDcmVkZW50aWFscywgVGF2aWx5UmVzdWx0SXRlbSB9IGZyb20gJ0AvdHlwZXMnXG5pbXBvcnQgeyBBcGlPcGVyYXRpb25zIH0gZnJvbSAnQC9vcGVyYXRpb25zL2FwaS5vcGVyYXRpb24nXG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0AvdXRpbHMvZXJyb3JzJ1xuaW1wb3J0IHsgU2VhcmNoLCBHbG9iZSwgU3BhcmtsZXMsIEV4dGVybmFsTGluaywgU2hpZWxkQ2hlY2ssIFphcCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcblxuZXhwb3J0IGNvbnN0IFRhdmlseVRhYjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoJ0ZyZWVBY2FkZW15IG1lbW9yeSBhbmQgY29udGV4dCBSQUcgbW9kdWxlJylcbiAgY29uc3QgW3NlYXJjaERlcHRoLCBzZXRTZWFyY2hEZXB0aF0gPSB1c2VTdGF0ZTwnYmFzaWMnIHwgJ2FkdmFuY2VkJz4oJ2Jhc2ljJylcbiAgY29uc3QgW21heFJlc3VsdHMsIHNldE1heFJlc3VsdHNdID0gdXNlU3RhdGUoNSlcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc2VhcmNoUmVzdWx0cywgc2V0U2VhcmNoUmVzdWx0c10gPSB1c2VTdGF0ZTx7IHF1ZXJ5OiBzdHJpbmc7IGFuc3dlcj86IHN0cmluZzsgcmVzdWx0czogVGF2aWx5UmVzdWx0SXRlbVtdIH0gfCBudWxsPihudWxsKVxuICBjb25zdCBbZXJyb3JNc2csIHNldEVycm9yTXNnXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXG5cbiAgY29uc3QgaGFuZGxlU2VhcmNoID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIGlmICghcXVlcnkudHJpbSgpIHx8IGlzTG9hZGluZykgcmV0dXJuXG5cbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSlcbiAgICBzZXRFcnJvck1zZyhudWxsKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFwaU9wZXJhdGlvbnMuc2VhcmNoVGF2aWx5KHF1ZXJ5LCBzZWFyY2hEZXB0aCwgbWF4UmVzdWx0cylcbiAgICAgIHNldFNlYXJjaFJlc3VsdHMocmVzKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IGVyciBpbnN0YW5jZW9mIEh0dHBFcnJvclJlc3BvbnNlID8gZXJyLm1lc3NhZ2UgOiAnVGF2aWx5IHNlYXJjaCBmYWlsZWQnXG4gICAgICBzZXRFcnJvck1zZyhtZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IG1heFdpZHRoOiAnMTIwMHB4JywgbWFyZ2luOiAnMCBhdXRvJywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMjRweCcgfX0+XG4gICAgICBcbiAgICAgIHsvKiBUb3AgQmFubmVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbGFzcy1jYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnIH19PlxuICAgICAgICA8aDIgc3R5bGU9e3sgZm9udFNpemU6ICcyMHB4JywgZm9udFdlaWdodDogJzcwMCcsIG1hcmdpbjogJzAgMCA2cHggMCcsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzEwcHgnIH19PlxuICAgICAgICAgIDxTZWFyY2ggY29sb3I9XCJ2YXIoLS1hY2NlbnQtZW1lcmFsZClcIiAvPlxuICAgICAgICAgIFRhdmlseSBBSSBXZWIgU2VhcmNoIEdyb3VuZGluZyBTdHVkaW9cbiAgICAgICAgPC9oMj5cbiAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxM3B4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScsIG1hcmdpbjogMCB9fT5cbiAgICAgICAgICBFeGVjdXRlIHJlYWwtdGltZSB3ZWIgc2VhcmNoIHR1bmVkIGZvciBMTE1zIGFuZCBSQUcgYWdlbnRzIHZpYSAqKlRhdmlseSoqLiBSZXRyaWV2ZXMgc2VhcmNoIGNvbnRlbnQsIGNpdGF0aW9ucywgYW5kIEFJIHN5bnRoZXNlcyBmb3IgZnJlc2ggd2ViIGZhY3RzLlxuICAgICAgICA8L3A+XG5cbiAgICAgICAgey8qIFNlYXJjaCBGb3JtICovfVxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VhcmNofSBzdHlsZT17eyBtYXJnaW5Ub3A6ICcyMHB4JywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzEycHgnIH19PlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWlucHV0XCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgZmxleDogMSB9fVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBxdWVyeSBmb3IgbGl2ZSB3ZWIgZ3JvdW5kaW5nLi4uXCJcbiAgICAgICAgICAgICAgdmFsdWU9e3F1ZXJ5fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtpc0xvYWRpbmd9PlxuICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gPFNwYXJrbGVzIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpblwiIHNpemU9ezE2fSAvPiA6IDxaYXAgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gJ1NlYXJjaGluZyBUYXZpbHkuLi4nIDogJ0V4ZWN1dGUgQUkgU2VhcmNoJ31cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzIwcHgnLCBmb250U2l6ZTogJzEycHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJyB9fT5cbiAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc2cHgnIH19PlxuICAgICAgICAgICAgICA8c3Bhbj5TZWFyY2ggRGVwdGg6PC9zcGFuPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6ICc0cHggOHB4JywgZm9udFNpemU6ICcxMnB4JyB9fVxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hEZXB0aH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaERlcHRoKGUudGFyZ2V0LnZhbHVlIGFzIGFueSl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYmFzaWNcIj5CYXNpYyAoRmFzdCk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWR2YW5jZWRcIj5BZHZhbmNlZCAoRGVlcCBDcmF3bCk8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgPHNwYW4+TWF4IFJlc3VsdHM6PC9zcGFuPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6ICc0cHggOHB4JywgZm9udFNpemU6ICcxMnB4JyB9fVxuICAgICAgICAgICAgICAgIHZhbHVlPXttYXhSZXN1bHRzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWF4UmVzdWx0cyhOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezN9PjMgUmVzdWx0czwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezV9PjUgUmVzdWx0czwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezh9PjggUmVzdWx0czwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3JNc2cgJiYgKFxuICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcxNnB4JywgYm9yZGVyUmFkaXVzOiAnMTJweCcsIGJhY2tncm91bmQ6ICdyZ2JhKDIzOSwgNjgsIDY4LCAwLjE1KScsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDIzOSwgNjgsIDY4LCAwLjMpJywgY29sb3I6ICcjZmNhNWE1JywgZm9udFNpemU6ICcxM3B4JyB9fT5cbiAgICAgICAgICDimqDvuI8ge2Vycm9yTXNnfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBSZXN1bHRzIFZpZXcgKi99XG4gICAgICB7c2VhcmNoUmVzdWx0cyAmJiAoXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAnMTZweCcgfX0+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIEFJIFNlYXJjaCBTeW50aGVzaXplZCBBbnN3ZXIgKi99XG4gICAgICAgICAge3NlYXJjaFJlc3VsdHMuYW5zd2VyICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcyMHB4JywgYm9yZGVyTGVmdDogJzRweCBzb2xpZCB2YXIoLS1hY2NlbnQtZW1lcmFsZCknIH19PlxuICAgICAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6ICcxNHB4JywgY29sb3I6ICcjNmVlN2I3JywgbWFyZ2luOiAnMCAwIDhweCAwJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgc2l6ZT17MTZ9IC8+IFRhdmlseSBBSSBTeW50aGVzaXplZCBTdW1tYXJ5XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxwIHN0eWxlPXt7IGZvbnRTaXplOiAnMTRweCcsIGxpbmVIZWlnaHQ6ICcxLjYnLCBtYXJnaW46IDAgfX0+XG4gICAgICAgICAgICAgICAge3NlYXJjaFJlc3VsdHMuYW5zd2VyfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIEluZGl2aWR1YWwgU2VhcmNoIFJlc3VsdHMgKi99XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZ3JpZCcsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6ICdyZXBlYXQoYXV0by1maXQsIG1pbm1heCgzNDBweCwgMWZyKSknLCBnYXA6ICcxNnB4JyB9fT5cbiAgICAgICAgICAgIHtzZWFyY2hSZXN1bHRzLnJlc3VsdHMubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCBhbmltYXRlLWZhZGUtaW5cIiBzdHlsZT17eyBwYWRkaW5nOiAnMThweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgfX0+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCcsIGdhcDogJzhweCcsIG1hcmdpbkJvdHRvbTogJzhweCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17aXRlbS51cmx9XG4gICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogJzE0cHgnLCBmb250V2VpZ2h0OiAnNzAwJywgY29sb3I6ICcjNjdlOGY5JywgdGV4dERlY29yYXRpb246ICdub25lJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnNnB4JyB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9IDxFeHRlcm5hbExpbmsgc2l6ZT17MTJ9IC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmFkZ2UgYmFkZ2UtZW1lcmFsZFwiPnsoaXRlbS5zY29yZSAqIDEwMCkudG9GaXhlZCgwKX0lIFNjb3JlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEycHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJywgbGluZUhlaWdodDogJzEuNScsIG1hcmdpbjogMCB9fT5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uY29udGVudH1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogJzEycHgnLCBmb250U2l6ZTogJzEwcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtZGltKScsIG92ZXJmbG93OiAnaGlkZGVuJywgdGV4dE92ZXJmbG93OiAnZWxsaXBzaXMnLCB3aGl0ZVNwYWNlOiAnbm93cmFwJyB9fT5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnVybH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl0sImZpbGUiOiJDOi9ub2RlL2xsbS9jbGllbnQvc3JjL3ZpZXdzL1RhdmlseVRhYi50c3gifQ==