import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/SettingsTab.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ec9d0266"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/node/llm/client/src/views/SettingsTab.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=ec9d0266"; const useState = __vite__cjsImport3_react["useState"];
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=90a7bf15";
import { ApiOperations } from "/src/operations/api.operation.ts";
import { HttpErrorResponse } from "/src/utils/errors.ts";
import { Settings, Key, Database, Globe, Search, Copy, Check } from "/node_modules/.vite/deps/lucide-react.js?v=6d6cae42";
export const SettingsTab = () => {
  _s();
  const { creds, setCreds, configStatus, refreshStatus } = useOutletContext();
  const [formState, setFormState] = useState(creds);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);
  const handleSave = async (e) => {
    e.preventDefault();
    setCreds(formState);
    localStorage.setItem("rag_api_credentials", JSON.stringify(formState));
    try {
      await ApiOperations.updateConfig(formState);
      setSaveSuccess(true);
      refreshStatus();
      setTimeout(() => setSaveSuccess(false), 3e3);
    } catch (e2) {
      const message = e2 instanceof HttpErrorResponse ? e2.message : "Unknown error";
      alert(`Failed to save config: ${message}`);
    }
  };
  const supabaseSqlScript = `-- Enable Vector Extension in Supabase PostgreSQL
CREATE EXTENSION IF NOT EXISTS vector;

-- 1. Create Documents Table
CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT gen_random_policy(),
  title TEXT NOT NULL,
  source_url TEXT,
  content TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Create Document Chunks Table with Vector Embeddings (1536 dimension)
CREATE TABLE IF NOT EXISTS document_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_policy(),
  document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  embedding vector(1536),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Create Long-Term Memories Table
CREATE TABLE IF NOT EXISTS memories (
  id UUID PRIMARY KEY DEFAULT gen_random_policy(),
  content TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  confidence FLOAT DEFAULT 1.0,
  embedding vector(1536),
  source TEXT DEFAULT 'chat_extraction',
  metadata JSONB DEFAULT '{}'::jsonb,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Vector Similarity Search Function for Document Chunks
CREATE OR REPLACE FUNCTION match_document_chunks (
  query_embedding vector(1536),
  match_threshold float DEFAULT 0.3,
  match_count int DEFAULT 5
)
RETURNS TABLE (
  id UUID,
  document_id UUID,
  content TEXT,
  metadata JSONB,
  similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    dc.id,
    dc.document_id,
    dc.content,
    dc.metadata,
    1 - (dc.embedding <=> query_embedding) AS similarity
  FROM document_chunks dc
  WHERE 1 - (dc.embedding <=> query_embedding) > match_threshold
  ORDER BY dc.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;

-- 5. Vector Similarity Search Function for Memories
CREATE OR REPLACE FUNCTION match_memories (
  query_embedding vector(1536),
  match_threshold float DEFAULT 0.3,
  match_count int DEFAULT 5
)
RETURNS TABLE (
  id UUID,
  content TEXT,
  category TEXT,
  confidence FLOAT,
  similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT
    m.id,
    m.content,
    m.category,
    m.confidence,
    1 - (m.embedding <=> query_embedding) AS similarity
  FROM memories m
  WHERE 1 - (m.embedding <=> query_embedding) > match_threshold
  ORDER BY m.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;`;
  const copySql = () => {
    navigator.clipboard.writeText(supabaseSqlScript);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 3e3);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: { maxWidth: "1200px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "24px" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px" }, children: [
      /* @__PURE__ */ jsxDEV("h2", { style: { fontSize: "20px", fontWeight: "700", margin: "0 0 6px 0", display: "flex", alignItems: "center", gap: "10px" }, children: [
        /* @__PURE__ */ jsxDEV(Settings, { color: "var(--primary)" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        "API Credentials & Supabase Configuration"
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "13px", color: "var(--text-muted)", margin: 0 }, children: "Manage your personal free-tier **Supabase**, **OpenAI**, **Firecrawl**, and **Tavily** credentials. Credentials can be saved locally or configured in `.env`." }, void 0, false, {
        fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
        lineNumber: 165,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 500px", gap: "24px" }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px" }, children: [
        /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "16px", fontWeight: "700", marginBottom: "16px", display: "flex", alignItems: "center", gap: "8px" }, children: [
          /* @__PURE__ */ jsxDEV(Key, { size: 18, color: "var(--accent-cyan)" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 175,
            columnNumber: 13
          }, this),
          "API Key Manager"
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 174,
          columnNumber: 11
        }, this),
        saveSuccess && /* @__PURE__ */ jsxDEV("div", { style: { padding: "12px", borderRadius: "8px", background: "rgba(16, 185, 129, 0.15)", border: "1px solid rgba(16, 185, 129, 0.3)", color: "#6ee7b7", fontSize: "13px", marginBottom: "16px" }, children: "✓ Credentials updated and synced with server!" }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 180,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSave, style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", justifyContent: "space-between", fontSize: "13px", fontWeight: "600", marginBottom: "6px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV(Database, { size: 14, color: "#67e8f9" }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                  lineNumber: 190,
                  columnNumber: 85
                }, this),
                " Supabase URL"
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 190,
                columnNumber: 17
              }, this),
              configStatus?.supabaseConfigured ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#6ee7b7", fontSize: "11px" }, children: "✓ Configured" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 191,
                columnNumber: 53
              }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "#fcd34d", fontSize: "11px" }, children: "Using In-Memory Fallback" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 191,
                columnNumber: 128
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 189,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "url",
                placeholder: "https://your-project.supabase.co",
                value: formState.supabaseUrl,
                onChange: (e) => setFormState({ ...formState, supabaseUrl: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 193,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 188,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "block", fontSize: "13px", fontWeight: "600", marginBottom: "6px" }, children: "Supabase Anon / Service Key" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 205,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "password",
                placeholder: "ey...",
                value: formState.supabaseKey,
                onChange: (e) => setFormState({ ...formState, supabaseKey: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 208,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 204,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", justifyContent: "space-between", fontSize: "13px", fontWeight: "600", marginBottom: "6px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { children: "OpenAI API Key (for GPT completion & Embeddings)" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 221,
                columnNumber: 17
              }, this),
              configStatus?.openaiConfigured ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#6ee7b7", fontSize: "11px" }, children: "✓ Configured" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 222,
                columnNumber: 51
              }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "#fcd34d", fontSize: "11px" }, children: "Using Local Vector Fallback" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 222,
                columnNumber: 126
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 220,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "password",
                placeholder: "sk-...",
                value: formState.openaiApiKey,
                onChange: (e) => setFormState({ ...formState, openaiApiKey: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 224,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 219,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", justifyContent: "space-between", fontSize: "13px", fontWeight: "600", marginBottom: "6px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV(Globe, { size: 14, color: "#a5b4fc" }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                  lineNumber: 237,
                  columnNumber: 85
                }, this),
                " Firecrawl API Key"
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 237,
                columnNumber: 17
              }, this),
              configStatus?.firecrawlConfigured ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#6ee7b7", fontSize: "11px" }, children: "✓ Configured" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 238,
                columnNumber: 54
              }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "#fcd34d", fontSize: "11px" }, children: "Using HTTP Fallback" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 238,
                columnNumber: 129
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 236,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "password",
                placeholder: "fc-...",
                value: formState.firecrawlApiKey,
                onChange: (e) => setFormState({ ...formState, firecrawlApiKey: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 240,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 235,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { style: { display: "flex", justifyContent: "space-between", fontSize: "13px", fontWeight: "600", marginBottom: "6px" }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: { display: "flex", alignItems: "center", gap: "6px" }, children: [
                /* @__PURE__ */ jsxDEV(Search, { size: 14, color: "#6ee7b7" }, void 0, false, {
                  fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                  lineNumber: 253,
                  columnNumber: 85
                }, this),
                " Tavily AI Search API Key"
              ] }, void 0, true, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 253,
                columnNumber: 17
              }, this),
              configStatus?.tavilyConfigured ? /* @__PURE__ */ jsxDEV("span", { style: { color: "#6ee7b7", fontSize: "11px" }, children: "✓ Configured" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 254,
                columnNumber: 51
              }, this) : /* @__PURE__ */ jsxDEV("span", { style: { color: "#fcd34d", fontSize: "11px" }, children: "Using Demo Grounding" }, void 0, false, {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 254,
                columnNumber: 126
              }, this)
            ] }, void 0, true, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 252,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                className: "glass-input",
                style: { width: "100%" },
                type: "password",
                placeholder: "tvly-...",
                value: formState.tavilyApiKey,
                onChange: (e) => setFormState({ ...formState, tavilyApiKey: e.target.value })
              },
              void 0,
              false,
              {
                fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
                lineNumber: 256,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 251,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-primary", type: "submit", style: { marginTop: "10px" }, children: "Save Credentials & Update Server" }, void 0, false, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 266,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 185,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
        lineNumber: 173,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "glass-card", style: { padding: "24px", display: "flex", flexDirection: "column", gap: "14px" }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV("h3", { style: { fontSize: "16px", fontWeight: "700", margin: 0, display: "flex", alignItems: "center", gap: "8px" }, children: [
            /* @__PURE__ */ jsxDEV(Database, { size: 18, color: "var(--primary)" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 277,
              columnNumber: 15
            }, this),
            "Supabase SQL Migration Script"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 276,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-secondary", onClick: copySql, style: { padding: "6px 12px", fontSize: "12px" }, children: [
            copiedSql ? /* @__PURE__ */ jsxDEV(Check, { size: 14, color: "#6ee7b7" }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 281,
              columnNumber: 28
            }, this) : /* @__PURE__ */ jsxDEV(Copy, { size: 14 }, void 0, false, {
              fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
              lineNumber: 281,
              columnNumber: 66
            }, this),
            copiedSql ? "Copied to Clipboard!" : "Copy SQL Script"
          ] }, void 0, true, {
            fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
            lineNumber: 280,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 275,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: { fontSize: "12px", color: "var(--text-muted)", margin: 0 }, children: "Paste this SQL script into your **Supabase SQL Editor** to create the vector extension, `documents`, `document_chunks`, `memories` tables, and cosine RPC match functions." }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 286,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("pre", { style: {
          background: "rgba(13, 21, 39, 0.95)",
          border: "1px solid var(--border-color)",
          borderRadius: "10px",
          padding: "14px",
          fontSize: "11px",
          fontFamily: "var(--font-mono)",
          color: "#a5b4fc",
          overflowX: "auto",
          maxHeight: "340px",
          whiteSpace: "pre"
        }, children: supabaseSqlScript }, void 0, false, {
          fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
          lineNumber: 290,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
        lineNumber: 274,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
      lineNumber: 170,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/node/llm/client/src/views/SettingsTab.tsx",
    lineNumber: 157,
    columnNumber: 5
  }, this);
};
_s(SettingsTab, "cx7T9ZljUYdhDYz9Gn3CqEi549w=", false, function() {
  return [useOutletContext];
});
_c = SettingsTab;
var _c;
$RefreshReg$(_c, "SettingsTab");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/node/llm/client/src/views/SettingsTab.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/node/llm/client/src/views/SettingsTab.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOElVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlJVixTQUFnQkEsZ0JBQWdCO0FBQ2hDLFNBQVNDLHdCQUF3QjtBQUVqQyxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLFVBQVVDLEtBQUtDLFVBQVVDLE9BQU9DLFFBQW1DQyxNQUFNQyxhQUFhO0FBRXhGLGFBQU1DLGNBQXdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDekMsUUFBTSxFQUFFQyxPQUFPQyxVQUFVQyxjQUFjQyxjQUFjLElBQUlmLGlCQUt0RDtBQUNILFFBQU0sQ0FBQ2dCLFdBQVdDLFlBQVksSUFBSWxCLFNBQXlCYSxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ00sYUFBYUMsY0FBYyxJQUFJcEIsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ3FCLFdBQVdDLFlBQVksSUFBSXRCLFNBQVMsS0FBSztBQUVoRCxRQUFNdUIsYUFBYSxPQUFPQyxNQUF1QjtBQUMvQ0EsTUFBRUMsZUFBZTtBQUNqQlgsYUFBU0csU0FBUztBQUNsQlMsaUJBQWFDLFFBQVEsdUJBQXVCQyxLQUFLQyxVQUFVWixTQUFTLENBQUM7QUFDckUsUUFBSTtBQUNGLFlBQU1mLGNBQWM0QixhQUFhYixTQUFTO0FBQzFDRyxxQkFBZSxJQUFJO0FBQ25CSixvQkFBYztBQUNkZSxpQkFBVyxNQUFNWCxlQUFlLEtBQUssR0FBRyxHQUFJO0FBQUEsSUFDOUMsU0FBU0ksSUFBRztBQUNWLFlBQU1RLFVBQVVSLGNBQWFyQixvQkFBb0JxQixHQUFFUSxVQUFVO0FBQzdEQyxZQUFNLDBCQUEwQkQsT0FBTyxFQUFFO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBRUEsUUFBTUUsb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWlHMUIsUUFBTUMsVUFBVUEsTUFBTTtBQUNwQkMsY0FBVUMsVUFBVUMsVUFBVUosaUJBQWlCO0FBQy9DWixpQkFBYSxJQUFJO0FBQ2pCUyxlQUFXLE1BQU1ULGFBQWEsS0FBSyxHQUFHLEdBQUk7QUFBQSxFQUM1QztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVpQixVQUFVLFVBQVVDLFFBQVEsVUFBVUMsU0FBUyxRQUFRQyxlQUFlLFVBQVVDLEtBQUssT0FBTyxHQUd4RztBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRUMsU0FBUyxPQUFPLEdBQ25EO0FBQUEsNkJBQUMsUUFBRyxPQUFPLEVBQUVDLFVBQVUsUUFBUUMsWUFBWSxPQUFPTixRQUFRLGFBQWFDLFNBQVMsUUFBUU0sWUFBWSxVQUFVSixLQUFLLE9BQU8sR0FDeEg7QUFBQSwrQkFBQyxZQUFTLE9BQU0sb0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQTtBQUFBLFdBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxPQUFPLEVBQUVFLFVBQVUsUUFBUUcsT0FBTyxxQkFBcUJSLFFBQVEsRUFBRSxHQUFFLDZLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPLEVBQUVDLFNBQVMsUUFBUVEscUJBQXFCLGFBQWFOLEtBQUssT0FBTyxHQUczRTtBQUFBLDZCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRUMsU0FBUyxPQUFPLEdBQ25EO0FBQUEsK0JBQUMsUUFBRyxPQUFPLEVBQUVDLFVBQVUsUUFBUUMsWUFBWSxPQUFPSSxjQUFjLFFBQVFULFNBQVMsUUFBUU0sWUFBWSxVQUFVSixLQUFLLE1BQU0sR0FDeEg7QUFBQSxpQ0FBQyxPQUFJLE1BQU0sSUFBSSxPQUFNLHdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBO0FBQUEsYUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQ3hCLGVBQ0MsdUJBQUMsU0FBSSxPQUFPLEVBQUV5QixTQUFTLFFBQVFPLGNBQWMsT0FBT0MsWUFBWSw0QkFBNEJDLFFBQVEscUNBQXFDTCxPQUFPLFdBQVdILFVBQVUsUUFBUUssY0FBYyxPQUFPLEdBQUUsNkRBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0YsdUJBQUMsVUFBSyxVQUFVM0IsWUFBWSxPQUFPLEVBQUVrQixTQUFTLFFBQVFDLGVBQWUsVUFBVUMsS0FBSyxPQUFPLEdBR3pGO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFRixTQUFTLFFBQVFhLGdCQUFnQixpQkFBaUJULFVBQVUsUUFBUUMsWUFBWSxPQUFPSSxjQUFjLE1BQU0sR0FDekg7QUFBQSxxQ0FBQyxVQUFLLE9BQU8sRUFBRVQsU0FBUyxRQUFRTSxZQUFZLFVBQVVKLEtBQUssTUFBTSxHQUFHO0FBQUEsdUNBQUMsWUFBUyxNQUFNLElBQUksT0FBTSxhQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUFHO0FBQUEsbUJBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVIO0FBQUEsY0FDdEg1QixjQUFjd0MscUJBQXFCLHVCQUFDLFVBQUssT0FBTyxFQUFFUCxPQUFPLFdBQVdILFVBQVUsT0FBTyxHQUFHLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRSxJQUFVLHVCQUFDLFVBQUssT0FBTyxFQUFFRyxPQUFPLFdBQVdILFVBQVUsT0FBTyxHQUFHLHdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGlCQUY5TDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVXLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU92QyxVQUFVd0M7QUFBQUEsZ0JBQ2pCLFVBQVUsQ0FBQ2pDLE1BQU1OLGFBQWEsRUFBRSxHQUFHRCxXQUFXd0MsYUFBYWpDLEVBQUVrQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGNBTjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU0rRTtBQUFBLGVBWGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLE9BQU8sRUFBRWxCLFNBQVMsU0FBU0ksVUFBVSxRQUFRQyxZQUFZLE9BQU9JLGNBQWMsTUFBTSxHQUFFLDJDQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVNLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU92QyxVQUFVMkM7QUFBQUEsZ0JBQ2pCLFVBQVUsQ0FBQ3BDLE1BQU1OLGFBQWEsRUFBRSxHQUFHRCxXQUFXMkMsYUFBYXBDLEVBQUVrQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGNBTjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU0rRTtBQUFBLGVBVmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLE9BQU8sRUFBRWxCLFNBQVMsUUFBUWEsZ0JBQWdCLGlCQUFpQlQsVUFBVSxRQUFRQyxZQUFZLE9BQU9JLGNBQWMsTUFBTSxHQUN6SDtBQUFBLHFDQUFDLFVBQUssZ0VBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUNyRG5DLGNBQWM4QyxtQkFBbUIsdUJBQUMsVUFBSyxPQUFPLEVBQUViLE9BQU8sV0FBV0gsVUFBVSxPQUFPLEdBQUcsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFLElBQVUsdUJBQUMsVUFBSyxPQUFPLEVBQUVHLE9BQU8sV0FBV0gsVUFBVSxPQUFPLEdBQUcsMkNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGO0FBQUEsaUJBRi9MO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRVcsT0FBTyxPQUFPO0FBQUEsZ0JBQ3ZCLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT3ZDLFVBQVU2QztBQUFBQSxnQkFDakIsVUFBVSxDQUFDdEMsTUFBTU4sYUFBYSxFQUFFLEdBQUdELFdBQVc2QyxjQUFjdEMsRUFBRWtDLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsY0FOOUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTWdGO0FBQUEsZUFYbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sT0FBTyxFQUFFbEIsU0FBUyxRQUFRYSxnQkFBZ0IsaUJBQWlCVCxVQUFVLFFBQVFDLFlBQVksT0FBT0ksY0FBYyxNQUFNLEdBQ3pIO0FBQUEscUNBQUMsVUFBSyxPQUFPLEVBQUVULFNBQVMsUUFBUU0sWUFBWSxVQUFVSixLQUFLLE1BQU0sR0FBRztBQUFBLHVDQUFDLFNBQU0sTUFBTSxJQUFJLE9BQU0sYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFBRztBQUFBLG1CQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5SDtBQUFBLGNBQ3hINUIsY0FBY2dELHNCQUFzQix1QkFBQyxVQUFLLE9BQU8sRUFBRWYsT0FBTyxXQUFXSCxVQUFVLE9BQU8sR0FBRyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUUsSUFBVSx1QkFBQyxVQUFLLE9BQU8sRUFBRUcsT0FBTyxXQUFXSCxVQUFVLE9BQU8sR0FBRyxtQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxpQkFGMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFVyxPQUFPLE9BQU87QUFBQSxnQkFDdkIsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixPQUFPdkMsVUFBVStDO0FBQUFBLGdCQUNqQixVQUFVLENBQUN4QyxNQUFNTixhQUFhLEVBQUUsR0FBR0QsV0FBVytDLGlCQUFpQnhDLEVBQUVrQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGNBTmpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1tRjtBQUFBLGVBWHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLE9BQU8sRUFBRWxCLFNBQVMsUUFBUWEsZ0JBQWdCLGlCQUFpQlQsVUFBVSxRQUFRQyxZQUFZLE9BQU9JLGNBQWMsTUFBTSxHQUN6SDtBQUFBLHFDQUFDLFVBQUssT0FBTyxFQUFFVCxTQUFTLFFBQVFNLFlBQVksVUFBVUosS0FBSyxNQUFNLEdBQUc7QUFBQSx1Q0FBQyxVQUFPLE1BQU0sSUFBSSxPQUFNLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQUc7QUFBQSxtQkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUk7QUFBQSxjQUNoSTVCLGNBQWNrRCxtQkFBbUIsdUJBQUMsVUFBSyxPQUFPLEVBQUVqQixPQUFPLFdBQVdILFVBQVUsT0FBTyxHQUFHLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRSxJQUFVLHVCQUFDLFVBQUssT0FBTyxFQUFFRyxPQUFPLFdBQVdILFVBQVUsT0FBTyxHQUFHLG9DQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGlCQUZ4TDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPLEVBQUVXLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU92QyxVQUFVaUQ7QUFBQUEsZ0JBQ2pCLFVBQVUsQ0FBQzFDLE1BQU1OLGFBQWEsRUFBRSxHQUFHRCxXQUFXaUQsY0FBYzFDLEVBQUVrQyxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGNBTjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1nRjtBQUFBLGVBWGxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLFlBQU8sV0FBVSxlQUFjLE1BQUssVUFBUyxPQUFPLEVBQUVRLFdBQVcsT0FBTyxHQUFFLGdEQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9GQTtBQUFBLFdBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrR0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxjQUFhLE9BQU8sRUFBRXZCLFNBQVMsUUFBUUgsU0FBUyxRQUFRQyxlQUFlLFVBQVVDLEtBQUssT0FBTyxHQUMxRztBQUFBLCtCQUFDLFNBQUksT0FBTyxFQUFFRixTQUFTLFFBQVFhLGdCQUFnQixpQkFBaUJQLFlBQVksU0FBUyxHQUNuRjtBQUFBLGlDQUFDLFFBQUcsT0FBTyxFQUFFRixVQUFVLFFBQVFDLFlBQVksT0FBT04sUUFBUSxHQUFHQyxTQUFTLFFBQVFNLFlBQVksVUFBVUosS0FBSyxNQUFNLEdBQzdHO0FBQUEsbUNBQUMsWUFBUyxNQUFNLElBQUksT0FBTSxvQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQTtBQUFBLGVBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsU0FBU1IsU0FBUyxPQUFPLEVBQUVTLFNBQVMsWUFBWUMsVUFBVSxPQUFPLEdBQ2hHeEI7QUFBQUEsd0JBQVksdUJBQUMsU0FBTSxNQUFNLElBQUksT0FBTSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQyxJQUFNLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUNqRUEsWUFBWSx5QkFBeUI7QUFBQSxlQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLE9BQUUsT0FBTyxFQUFFd0IsVUFBVSxRQUFRRyxPQUFPLHFCQUFxQlIsUUFBUSxFQUFFLEdBQUUsMExBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFDVlksWUFBWTtBQUFBLFVBQ1pDLFFBQVE7QUFBQSxVQUNSRixjQUFjO0FBQUEsVUFDZFAsU0FBUztBQUFBLFVBQ1RDLFVBQVU7QUFBQSxVQUNWdUIsWUFBWTtBQUFBLFVBQ1pwQixPQUFPO0FBQUEsVUFDUHFCLFdBQVc7QUFBQSxVQUNYQyxXQUFXO0FBQUEsVUFDWEMsWUFBWTtBQUFBLFFBQ2QsR0FDR3JDLCtCQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxTQXRJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0lBO0FBQUEsT0FySkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVKQTtBQUVKO0FBQUN0QixHQTNSWUQsYUFBcUI7QUFBQSxVQUN5QlYsZ0JBQWdCO0FBQUE7QUFBQSxLQUQ5RFU7QUFBcUIsSUFBQTZEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlT3V0bGV0Q29udGV4dCIsIkFwaU9wZXJhdGlvbnMiLCJIdHRwRXJyb3JSZXNwb25zZSIsIlNldHRpbmdzIiwiS2V5IiwiRGF0YWJhc2UiLCJHbG9iZSIsIlNlYXJjaCIsIkNvcHkiLCJDaGVjayIsIlNldHRpbmdzVGFiIiwiX3MiLCJjcmVkcyIsInNldENyZWRzIiwiY29uZmlnU3RhdHVzIiwicmVmcmVzaFN0YXR1cyIsImZvcm1TdGF0ZSIsInNldEZvcm1TdGF0ZSIsInNhdmVTdWNjZXNzIiwic2V0U2F2ZVN1Y2Nlc3MiLCJjb3BpZWRTcWwiLCJzZXRDb3BpZWRTcWwiLCJoYW5kbGVTYXZlIiwiZSIsInByZXZlbnREZWZhdWx0IiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ1cGRhdGVDb25maWciLCJzZXRUaW1lb3V0IiwibWVzc2FnZSIsImFsZXJ0Iiwic3VwYWJhc2VTcWxTY3JpcHQiLCJjb3B5U3FsIiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0IiwibWF4V2lkdGgiLCJtYXJnaW4iLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsInBhZGRpbmciLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJhbGlnbkl0ZW1zIiwiY29sb3IiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwibWFyZ2luQm90dG9tIiwiYm9yZGVyUmFkaXVzIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImp1c3RpZnlDb250ZW50Iiwic3VwYWJhc2VDb25maWd1cmVkIiwid2lkdGgiLCJzdXBhYmFzZVVybCIsInRhcmdldCIsInZhbHVlIiwic3VwYWJhc2VLZXkiLCJvcGVuYWlDb25maWd1cmVkIiwib3BlbmFpQXBpS2V5IiwiZmlyZWNyYXdsQ29uZmlndXJlZCIsImZpcmVjcmF3bEFwaUtleSIsInRhdmlseUNvbmZpZ3VyZWQiLCJ0YXZpbHlBcGlLZXkiLCJtYXJnaW5Ub3AiLCJmb250RmFtaWx5Iiwib3ZlcmZsb3dYIiwibWF4SGVpZ2h0Iiwid2hpdGVTcGFjZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNldHRpbmdzVGFiLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQXBpQ3JlZGVudGlhbHMsIENvbmZpZ1N0YXR1cyB9IGZyb20gJ0AvdHlwZXMnXG5pbXBvcnQgeyBBcGlPcGVyYXRpb25zIH0gZnJvbSAnQC9vcGVyYXRpb25zL2FwaS5vcGVyYXRpb24nXG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0AvdXRpbHMvZXJyb3JzJ1xuaW1wb3J0IHsgU2V0dGluZ3MsIEtleSwgRGF0YWJhc2UsIEdsb2JlLCBTZWFyY2gsIENoZWNrQ2lyY2xlMiwgQWxlcnRDaXJjbGUsIENvcHksIENoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG5leHBvcnQgY29uc3QgU2V0dGluZ3NUYWI6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IGNyZWRzLCBzZXRDcmVkcywgY29uZmlnU3RhdHVzLCByZWZyZXNoU3RhdHVzIH0gPSB1c2VPdXRsZXRDb250ZXh0PHtcbiAgICBjcmVkczogQXBpQ3JlZGVudGlhbHNcbiAgICBzZXRDcmVkczogKGNyZWRzOiBBcGlDcmVkZW50aWFscykgPT4gdm9pZFxuICAgIGNvbmZpZ1N0YXR1czogQ29uZmlnU3RhdHVzIHwgbnVsbFxuICAgIHJlZnJlc2hTdGF0dXM6ICgpID0+IHZvaWRcbiAgfT4oKVxuICBjb25zdCBbZm9ybVN0YXRlLCBzZXRGb3JtU3RhdGVdID0gdXNlU3RhdGU8QXBpQ3JlZGVudGlhbHM+KGNyZWRzKVxuICBjb25zdCBbc2F2ZVN1Y2Nlc3MsIHNldFNhdmVTdWNjZXNzXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbY29waWVkU3FsLCBzZXRDb3BpZWRTcWxdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBzZXRDcmVkcyhmb3JtU3RhdGUpXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3JhZ19hcGlfY3JlZGVudGlhbHMnLCBKU09OLnN0cmluZ2lmeShmb3JtU3RhdGUpKVxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBBcGlPcGVyYXRpb25zLnVwZGF0ZUNvbmZpZyhmb3JtU3RhdGUpXG4gICAgICBzZXRTYXZlU3VjY2Vzcyh0cnVlKVxuICAgICAgcmVmcmVzaFN0YXR1cygpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNhdmVTdWNjZXNzKGZhbHNlKSwgMzAwMClcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0gZSBpbnN0YW5jZW9mIEh0dHBFcnJvclJlc3BvbnNlID8gZS5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InXG4gICAgICBhbGVydChgRmFpbGVkIHRvIHNhdmUgY29uZmlnOiAke21lc3NhZ2V9YClcbiAgICB9XG4gIH1cblxuICBjb25zdCBzdXBhYmFzZVNxbFNjcmlwdCA9IGAtLSBFbmFibGUgVmVjdG9yIEV4dGVuc2lvbiBpbiBTdXBhYmFzZSBQb3N0Z3JlU1FMXG5DUkVBVEUgRVhURU5TSU9OIElGIE5PVCBFWElTVFMgdmVjdG9yO1xuXG4tLSAxLiBDcmVhdGUgRG9jdW1lbnRzIFRhYmxlXG5DUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyBkb2N1bWVudHMgKFxuICBpZCBVVUlEIFBSSU1BUlkgS0VZIERFRkFVTFQgZ2VuX3JhbmRvbV9wb2xpY3koKSxcbiAgdGl0bGUgVEVYVCBOT1QgTlVMTCxcbiAgc291cmNlX3VybCBURVhULFxuICBjb250ZW50IFRFWFQgTk9UIE5VTEwsXG4gIG1ldGFkYXRhIEpTT05CIERFRkFVTFQgJ3t9Jzo6anNvbmIsXG4gIGNyZWF0ZWRfYXQgVElNRVNUQU1QIFdJVEggVElNRSBaT05FIERFRkFVTFQgdGltZXpvbmUoJ3V0Yyc6OnRleHQsIG5vdygpKSBOT1QgTlVMTFxuKTtcblxuLS0gMi4gQ3JlYXRlIERvY3VtZW50IENodW5rcyBUYWJsZSB3aXRoIFZlY3RvciBFbWJlZGRpbmdzICgxNTM2IGRpbWVuc2lvbilcbkNSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIGRvY3VtZW50X2NodW5rcyAoXG4gIGlkIFVVSUQgUFJJTUFSWSBLRVkgREVGQVVMVCBnZW5fcmFuZG9tX3BvbGljeSgpLFxuICBkb2N1bWVudF9pZCBVVUlEIFJFRkVSRU5DRVMgZG9jdW1lbnRzKGlkKSBPTiBERUxFVEUgQ0FTQ0FERSxcbiAgY29udGVudCBURVhUIE5PVCBOVUxMLFxuICBjaHVua19pbmRleCBJTlRFR0VSIE5PVCBOVUxMLFxuICBlbWJlZGRpbmcgdmVjdG9yKDE1MzYpLFxuICBtZXRhZGF0YSBKU09OQiBERUZBVUxUICd7fSc6Ompzb25iLFxuICBjcmVhdGVkX2F0IFRJTUVTVEFNUCBXSVRIIFRJTUUgWk9ORSBERUZBVUxUIHRpbWV6b25lKCd1dGMnOjp0ZXh0LCBub3coKSkgTk9UIE5VTExcbik7XG5cbi0tIDMuIENyZWF0ZSBMb25nLVRlcm0gTWVtb3JpZXMgVGFibGVcbkNSRUFURSBUQUJMRSBJRiBOT1QgRVhJU1RTIG1lbW9yaWVzIChcbiAgaWQgVVVJRCBQUklNQVJZIEtFWSBERUZBVUxUIGdlbl9yYW5kb21fcG9saWN5KCksXG4gIGNvbnRlbnQgVEVYVCBOT1QgTlVMTCxcbiAgY2F0ZWdvcnkgVEVYVCBERUZBVUxUICdnZW5lcmFsJyxcbiAgY29uZmlkZW5jZSBGTE9BVCBERUZBVUxUIDEuMCxcbiAgZW1iZWRkaW5nIHZlY3RvcigxNTM2KSxcbiAgc291cmNlIFRFWFQgREVGQVVMVCAnY2hhdF9leHRyYWN0aW9uJyxcbiAgbWV0YWRhdGEgSlNPTkIgREVGQVVMVCAne30nOjpqc29uYixcbiAgdXBkYXRlZF9hdCBUSU1FU1RBTVAgV0lUSCBUSU1FIFpPTkUgREVGQVVMVCB0aW1lem9uZSgndXRjJzo6dGV4dCwgbm93KCkpIE5PVCBOVUxMLFxuICBjcmVhdGVkX2F0IFRJTUVTVEFNUCBXSVRIIFRJTUUgWk9ORSBERUZBVUxUIHRpbWV6b25lKCd1dGMnOjp0ZXh0LCBub3coKSkgTk9UIE5VTExcbik7XG5cbi0tIDQuIFZlY3RvciBTaW1pbGFyaXR5IFNlYXJjaCBGdW5jdGlvbiBmb3IgRG9jdW1lbnQgQ2h1bmtzXG5DUkVBVEUgT1IgUkVQTEFDRSBGVU5DVElPTiBtYXRjaF9kb2N1bWVudF9jaHVua3MgKFxuICBxdWVyeV9lbWJlZGRpbmcgdmVjdG9yKDE1MzYpLFxuICBtYXRjaF90aHJlc2hvbGQgZmxvYXQgREVGQVVMVCAwLjMsXG4gIG1hdGNoX2NvdW50IGludCBERUZBVUxUIDVcbilcblJFVFVSTlMgVEFCTEUgKFxuICBpZCBVVUlELFxuICBkb2N1bWVudF9pZCBVVUlELFxuICBjb250ZW50IFRFWFQsXG4gIG1ldGFkYXRhIEpTT05CLFxuICBzaW1pbGFyaXR5IGZsb2F0XG4pXG5MQU5HVUFHRSBwbHBnc3FsXG5BUyAkJFxuQkVHSU5cbiAgUkVUVVJOIFFVRVJZXG4gIFNFTEVDVFxuICAgIGRjLmlkLFxuICAgIGRjLmRvY3VtZW50X2lkLFxuICAgIGRjLmNvbnRlbnQsXG4gICAgZGMubWV0YWRhdGEsXG4gICAgMSAtIChkYy5lbWJlZGRpbmcgPD0+IHF1ZXJ5X2VtYmVkZGluZykgQVMgc2ltaWxhcml0eVxuICBGUk9NIGRvY3VtZW50X2NodW5rcyBkY1xuICBXSEVSRSAxIC0gKGRjLmVtYmVkZGluZyA8PT4gcXVlcnlfZW1iZWRkaW5nKSA+IG1hdGNoX3RocmVzaG9sZFxuICBPUkRFUiBCWSBkYy5lbWJlZGRpbmcgPD0+IHF1ZXJ5X2VtYmVkZGluZ1xuICBMSU1JVCBtYXRjaF9jb3VudDtcbkVORDtcbiQkO1xuXG4tLSA1LiBWZWN0b3IgU2ltaWxhcml0eSBTZWFyY2ggRnVuY3Rpb24gZm9yIE1lbW9yaWVzXG5DUkVBVEUgT1IgUkVQTEFDRSBGVU5DVElPTiBtYXRjaF9tZW1vcmllcyAoXG4gIHF1ZXJ5X2VtYmVkZGluZyB2ZWN0b3IoMTUzNiksXG4gIG1hdGNoX3RocmVzaG9sZCBmbG9hdCBERUZBVUxUIDAuMyxcbiAgbWF0Y2hfY291bnQgaW50IERFRkFVTFQgNVxuKVxuUkVUVVJOUyBUQUJMRSAoXG4gIGlkIFVVSUQsXG4gIGNvbnRlbnQgVEVYVCxcbiAgY2F0ZWdvcnkgVEVYVCxcbiAgY29uZmlkZW5jZSBGTE9BVCxcbiAgc2ltaWxhcml0eSBmbG9hdFxuKVxuTEFOR1VBR0UgcGxwZ3NxbFxuQVMgJCRcbkJFR0lOXG4gIFJFVFVSTiBRVUVSWVxuICBTRUxFQ1RcbiAgICBtLmlkLFxuICAgIG0uY29udGVudCxcbiAgICBtLmNhdGVnb3J5LFxuICAgIG0uY29uZmlkZW5jZSxcbiAgICAxIC0gKG0uZW1iZWRkaW5nIDw9PiBxdWVyeV9lbWJlZGRpbmcpIEFTIHNpbWlsYXJpdHlcbiAgRlJPTSBtZW1vcmllcyBtXG4gIFdIRVJFIDEgLSAobS5lbWJlZGRpbmcgPD0+IHF1ZXJ5X2VtYmVkZGluZykgPiBtYXRjaF90aHJlc2hvbGRcbiAgT1JERVIgQlkgbS5lbWJlZGRpbmcgPD0+IHF1ZXJ5X2VtYmVkZGluZ1xuICBMSU1JVCBtYXRjaF9jb3VudDtcbkVORDtcbiQkO2BcblxuICBjb25zdCBjb3B5U3FsID0gKCkgPT4ge1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHN1cGFiYXNlU3FsU2NyaXB0KVxuICAgIHNldENvcGllZFNxbCh0cnVlKVxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkU3FsKGZhbHNlKSwgMzAwMClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBtYXhXaWR0aDogJzEyMDBweCcsIG1hcmdpbjogJzAgYXV0bycsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzI0cHgnIH19PlxuICAgICAgXG4gICAgICB7LyogSGVhZGVyIEJhbm5lciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcyNHB4JyB9fT5cbiAgICAgICAgPGgyIHN0eWxlPXt7IGZvbnRTaXplOiAnMjBweCcsIGZvbnRXZWlnaHQ6ICc3MDAnLCBtYXJnaW46ICcwIDAgNnB4IDAnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcxMHB4JyB9fT5cbiAgICAgICAgICA8U2V0dGluZ3MgY29sb3I9XCJ2YXIoLS1wcmltYXJ5KVwiIC8+XG4gICAgICAgICAgQVBJIENyZWRlbnRpYWxzICYgU3VwYWJhc2UgQ29uZmlndXJhdGlvblxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJ3ZhcigtLXRleHQtbXV0ZWQpJywgbWFyZ2luOiAwIH19PlxuICAgICAgICAgIE1hbmFnZSB5b3VyIHBlcnNvbmFsIGZyZWUtdGllciAqKlN1cGFiYXNlKiosICoqT3BlbkFJKiosICoqRmlyZWNyYXdsKiosIGFuZCAqKlRhdmlseSoqIGNyZWRlbnRpYWxzLiBDcmVkZW50aWFscyBjYW4gYmUgc2F2ZWQgbG9jYWxseSBvciBjb25maWd1cmVkIGluIGAuZW52YC5cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2dyaWQnLCBncmlkVGVtcGxhdGVDb2x1bW5zOiAnMWZyIDUwMHB4JywgZ2FwOiAnMjRweCcgfX0+XG4gICAgICAgIFxuICAgICAgICB7LyogQVBJIENyZWRlbnRpYWxzIEZvcm0gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcyNHB4JyB9fT5cbiAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6ICcxNnB4JywgZm9udFdlaWdodDogJzcwMCcsIG1hcmdpbkJvdHRvbTogJzE2cHgnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxuICAgICAgICAgICAgPEtleSBzaXplPXsxOH0gY29sb3I9XCJ2YXIoLS1hY2NlbnQtY3lhbilcIiAvPlxuICAgICAgICAgICAgQVBJIEtleSBNYW5hZ2VyXG4gICAgICAgICAgPC9oMz5cblxuICAgICAgICAgIHtzYXZlU3VjY2VzcyAmJiAoXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcxMnB4JywgYm9yZGVyUmFkaXVzOiAnOHB4JywgYmFja2dyb3VuZDogJ3JnYmEoMTYsIDE4NSwgMTI5LCAwLjE1KScsIGJvcmRlcjogJzFweCBzb2xpZCByZ2JhKDE2LCAxODUsIDEyOSwgMC4zKScsIGNvbG9yOiAnIzZlZTdiNycsIGZvbnRTaXplOiAnMTNweCcsIG1hcmdpbkJvdHRvbTogJzE2cHgnIH19PlxuICAgICAgICAgICAgICDinJMgQ3JlZGVudGlhbHMgdXBkYXRlZCBhbmQgc3luY2VkIHdpdGggc2VydmVyIVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlfSBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxNnB4JyB9fT5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIFN1cGFiYXNlIFVSTCAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGZvbnRTaXplOiAnMTNweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBtYXJnaW5Cb3R0b206ICc2cHgnIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzZweCcgfX0+PERhdGFiYXNlIHNpemU9ezE0fSBjb2xvcj1cIiM2N2U4ZjlcIiAvPiBTdXBhYmFzZSBVUkw8L3NwYW4+XG4gICAgICAgICAgICAgICAge2NvbmZpZ1N0YXR1cz8uc3VwYWJhc2VDb25maWd1cmVkID8gPHNwYW4gc3R5bGU9e3sgY29sb3I6ICcjNmVlN2I3JywgZm9udFNpemU6ICcxMXB4JyB9fT7inJMgQ29uZmlndXJlZDwvc3Bhbj4gOiA8c3BhbiBzdHlsZT17eyBjb2xvcjogJyNmY2QzNGQnLCBmb250U2l6ZTogJzExcHgnIH19PlVzaW5nIEluLU1lbW9yeSBGYWxsYmFjazwvc3Bhbj59XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWlucHV0XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XG4gICAgICAgICAgICAgICAgdHlwZT1cInVybFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL3lvdXItcHJvamVjdC5zdXBhYmFzZS5jb1wiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1TdGF0ZS5zdXBhYmFzZVVybH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1TdGF0ZSh7IC4uLmZvcm1TdGF0ZSwgc3VwYWJhc2VVcmw6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTdXBhYmFzZSBLZXkgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgZm9udFNpemU6ICcxM3B4JywgZm9udFdlaWdodDogJzYwMCcsIG1hcmdpbkJvdHRvbTogJzZweCcgfX0+XG4gICAgICAgICAgICAgICAgU3VwYWJhc2UgQW5vbiAvIFNlcnZpY2UgS2V5XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWlucHV0XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19XG4gICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV5Li4uXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybVN0YXRlLnN1cGFiYXNlS2V5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybVN0YXRlKHsgLi4uZm9ybVN0YXRlLCBzdXBhYmFzZUtleTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE9wZW5BSSBBUEkgS2V5ICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgZm9udFNpemU6ICcxM3B4JywgZm9udFdlaWdodDogJzYwMCcsIG1hcmdpbkJvdHRvbTogJzZweCcgfX0+XG4gICAgICAgICAgICAgICAgPHNwYW4+T3BlbkFJIEFQSSBLZXkgKGZvciBHUFQgY29tcGxldGlvbiAmIEVtYmVkZGluZ3MpPC9zcGFuPlxuICAgICAgICAgICAgICAgIHtjb25maWdTdGF0dXM/Lm9wZW5haUNvbmZpZ3VyZWQgPyA8c3BhbiBzdHlsZT17eyBjb2xvcjogJyM2ZWU3YjcnLCBmb250U2l6ZTogJzExcHgnIH19PuKckyBDb25maWd1cmVkPC9zcGFuPiA6IDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAnI2ZjZDM0ZCcsIGZvbnRTaXplOiAnMTFweCcgfX0+VXNpbmcgTG9jYWwgVmVjdG9yIEZhbGxiYWNrPC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cbiAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwic2stLi4uXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybVN0YXRlLm9wZW5haUFwaUtleX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1TdGF0ZSh7IC4uLmZvcm1TdGF0ZSwgb3BlbmFpQXBpS2V5OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRmlyZWNyYXdsIEFQSSBLZXkgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBmb250U2l6ZTogJzEzcHgnLCBmb250V2VpZ2h0OiAnNjAwJywgbWFyZ2luQm90dG9tOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc2cHgnIH19PjxHbG9iZSBzaXplPXsxNH0gY29sb3I9XCIjYTViNGZjXCIgLz4gRmlyZWNyYXdsIEFQSSBLZXk8L3NwYW4+XG4gICAgICAgICAgICAgICAge2NvbmZpZ1N0YXR1cz8uZmlyZWNyYXdsQ29uZmlndXJlZCA/IDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAnIzZlZTdiNycsIGZvbnRTaXplOiAnMTFweCcgfX0+4pyTIENvbmZpZ3VyZWQ8L3NwYW4+IDogPHNwYW4gc3R5bGU9e3sgY29sb3I6ICcjZmNkMzRkJywgZm9udFNpemU6ICcxMXB4JyB9fT5Vc2luZyBIVFRQIEZhbGxiYWNrPC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cbiAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZmMtLi4uXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybVN0YXRlLmZpcmVjcmF3bEFwaUtleX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1TdGF0ZSh7IC4uLmZvcm1TdGF0ZSwgZmlyZWNyYXdsQXBpS2V5OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogVGF2aWx5IEFQSSBLZXkgKi99XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLCBmb250U2l6ZTogJzEzcHgnLCBmb250V2VpZ2h0OiAnNjAwJywgbWFyZ2luQm90dG9tOiAnNnB4JyB9fT5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc2cHgnIH19PjxTZWFyY2ggc2l6ZT17MTR9IGNvbG9yPVwiIzZlZTdiN1wiIC8+IFRhdmlseSBBSSBTZWFyY2ggQVBJIEtleTwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7Y29uZmlnU3RhdHVzPy50YXZpbHlDb25maWd1cmVkID8gPHNwYW4gc3R5bGU9e3sgY29sb3I6ICcjNmVlN2I3JywgZm9udFNpemU6ICcxMXB4JyB9fT7inJMgQ29uZmlndXJlZDwvc3Bhbj4gOiA8c3BhbiBzdHlsZT17eyBjb2xvcjogJyNmY2QzNGQnLCBmb250U2l6ZTogJzExcHgnIH19PlVzaW5nIERlbW8gR3JvdW5kaW5nPC9zcGFuPn1cbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtaW5wdXRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX1cbiAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwidHZseS0uLi5cIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtU3RhdGUudGF2aWx5QXBpS2V5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybVN0YXRlKHsgLi4uZm9ybVN0YXRlLCB0YXZpbHlBcGlLZXk6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIiB0eXBlPVwic3VibWl0XCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMTBweCcgfX0+XG4gICAgICAgICAgICAgIFNhdmUgQ3JlZGVudGlhbHMgJiBVcGRhdGUgU2VydmVyXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFN1cGFiYXNlIFNjaGVtYSBTUUwgVmlld2VyIFdpZGdldCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbGFzcy1jYXJkXCIgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxNHB4JyB9fT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICAgICAgICA8aDMgc3R5bGU9e3sgZm9udFNpemU6ICcxNnB4JywgZm9udFdlaWdodDogJzcwMCcsIG1hcmdpbjogMCwgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cbiAgICAgICAgICAgICAgPERhdGFiYXNlIHNpemU9ezE4fSBjb2xvcj1cInZhcigtLXByaW1hcnkpXCIgLz5cbiAgICAgICAgICAgICAgU3VwYWJhc2UgU1FMIE1pZ3JhdGlvbiBTY3JpcHRcbiAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXtjb3B5U3FsfSBzdHlsZT17eyBwYWRkaW5nOiAnNnB4IDEycHgnLCBmb250U2l6ZTogJzEycHgnIH19PlxuICAgICAgICAgICAgICB7Y29waWVkU3FsID8gPENoZWNrIHNpemU9ezE0fSBjb2xvcj1cIiM2ZWU3YjdcIiAvPiA6IDxDb3B5IHNpemU9ezE0fSAvPn1cbiAgICAgICAgICAgICAge2NvcGllZFNxbCA/ICdDb3BpZWQgdG8gQ2xpcGJvYXJkIScgOiAnQ29weSBTUUwgU2NyaXB0J31cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxMnB4JywgY29sb3I6ICd2YXIoLS10ZXh0LW11dGVkKScsIG1hcmdpbjogMCB9fT5cbiAgICAgICAgICAgIFBhc3RlIHRoaXMgU1FMIHNjcmlwdCBpbnRvIHlvdXIgKipTdXBhYmFzZSBTUUwgRWRpdG9yKiogdG8gY3JlYXRlIHRoZSB2ZWN0b3IgZXh0ZW5zaW9uLCBgZG9jdW1lbnRzYCwgYGRvY3VtZW50X2NodW5rc2AsIGBtZW1vcmllc2AgdGFibGVzLCBhbmQgY29zaW5lIFJQQyBtYXRjaCBmdW5jdGlvbnMuXG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPHByZSBzdHlsZT17e1xuICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMTMsIDIxLCAzOSwgMC45NSknLFxuICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWJvcmRlci1jb2xvciknLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTBweCcsXG4gICAgICAgICAgICBwYWRkaW5nOiAnMTRweCcsXG4gICAgICAgICAgICBmb250U2l6ZTogJzExcHgnLFxuICAgICAgICAgICAgZm9udEZhbWlseTogJ3ZhcigtLWZvbnQtbW9ubyknLFxuICAgICAgICAgICAgY29sb3I6ICcjYTViNGZjJyxcbiAgICAgICAgICAgIG92ZXJmbG93WDogJ2F1dG8nLFxuICAgICAgICAgICAgbWF4SGVpZ2h0OiAnMzQwcHgnLFxuICAgICAgICAgICAgd2hpdGVTcGFjZTogJ3ByZSdcbiAgICAgICAgICB9fT5cbiAgICAgICAgICAgIHtzdXBhYmFzZVNxbFNjcmlwdH1cbiAgICAgICAgICA8L3ByZT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiQzovbm9kZS9sbG0vY2xpZW50L3NyYy92aWV3cy9TZXR0aW5nc1RhYi50c3gifQ==